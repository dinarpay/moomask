var popup =
webpackJsonp_name_([0],{

/***/ 131:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _classCallCheck2 = __webpack_require__(574);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(575);

var _createClass3 = _interopRequireDefault(_createClass2);

var _web = __webpack_require__(34);

var _web2 = _interopRequireDefault(_web);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var APIClient = function () {
    function APIClient() {
        (0, _classCallCheck3.default)(this, APIClient);
    }

    (0, _createClass3.default)(APIClient, [{
        key: 'client',
        set: function set(client) {
            this._client = client;
        },
        get: function get() {
            return this._client;
        }
    }]);
    return APIClient;
}();

var apiClient = new APIClient();

exports.default = apiClient;

/***/ }),

/***/ 132:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.transferToAddresss = exports.loadSingle = exports.ABI = undefined;

var _extends2 = __webpack_require__(244);

var _extends3 = _interopRequireDefault(_extends2);

var _slicedToArray2 = __webpack_require__(589);

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

var _regenerator = __webpack_require__(50);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(51);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _vuex = __webpack_require__(11);

var _utils = __webpack_require__(63);

var _all_tokens = __webpack_require__(249);

var _all_tokens2 = _interopRequireDefault(_all_tokens);

var _token = __webpack_require__(250);

var _token2 = _interopRequireDefault(_token);

var _web = __webpack_require__(34);

var _web2 = _interopRequireDefault(_web);

var _network = __webpack_require__(137);

var _network2 = _interopRequireDefault(_network);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var ABI = exports.ABI = [{
    "constant": true,
    "inputs": [],
    "name": "name",
    "outputs": [{
        "name": "",
        "type": "string"
    }],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
}, {
    "constant": false,
    "inputs": [{
        "name": "_spender",
        "type": "address"
    }, {
        "name": "_value",
        "type": "uint256"
    }],
    "name": "approve",
    "outputs": [{
        "name": "",
        "type": "bool"
    }],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
}, {
    "constant": true,
    "inputs": [],
    "name": "totalSupply",
    "outputs": [{
        "name": "",
        "type": "uint256"
    }],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
}, {
    "constant": false,
    "inputs": [{
        "name": "_from",
        "type": "address"
    }, {
        "name": "_to",
        "type": "address"
    }, {
        "name": "_value",
        "type": "uint256"
    }],
    "name": "transferFrom",
    "outputs": [{
        "name": "",
        "type": "bool"
    }],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
}, {
    "constant": true,
    "inputs": [],
    "name": "decimals",
    "outputs": [{
        "name": "",
        "type": "uint8"
    }],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
}, {
    "constant": true,
    "inputs": [{
        "name": "_owner",
        "type": "address"
    }],
    "name": "balanceOf",
    "outputs": [{
        "name": "balance",
        "type": "uint256"
    }],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
}, {
    "constant": true,
    "inputs": [],
    "name": "symbol",
    "outputs": [{
        "name": "",
        "type": "string"
    }],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
}, {
    "constant": false,
    "inputs": [{
        "name": "_to",
        "type": "address"
    }, {
        "name": "_value",
        "type": "uint256"
    }],
    "name": "transfer",
    "outputs": [{
        "name": "",
        "type": "bool"
    }],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
}, {
    "constant": true,
    "inputs": [{
        "name": "_owner",
        "type": "address"
    }, {
        "name": "_spender",
        "type": "address"
    }],
    "name": "allowance",
    "outputs": [{
        "name": "",
        "type": "uint256"
    }],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
}, {
    "payable": true,
    "stateMutability": "payable",
    "type": "fallback"
}, {
    "anonymous": false,
    "inputs": [{
        "indexed": true,
        "name": "owner",
        "type": "address"
    }, {
        "indexed": true,
        "name": "spender",
        "type": "address"
    }, {
        "indexed": false,
        "name": "value",
        "type": "uint256"
    }],
    "name": "Approval",
    "type": "event"
}, {
    "anonymous": false,
    "inputs": [{
        "indexed": true,
        "name": "from",
        "type": "address"
    }, {
        "indexed": true,
        "name": "to",
        "type": "address"
    }, {
        "indexed": false,
        "name": "value",
        "type": "uint256"
    }],
    "name": "Transfer",
    "type": "event"
}];

var loadSingle = exports.loadSingle = function () {
    var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(network, contractAddress, ownAddress) {
        var provider, contract, balResult;
        return _regenerator2.default.wrap(function _callee$(_context) {
            while (1) {
                switch (_context.prev = _context.next) {
                    case 0:
                        provider = new _web2.default(new _web2.default.providers.HttpProvider(network.main));
                        contract = new provider.eth.Contract(ABI, contractAddress);
                        _context.next = 4;
                        return contract.methods.balanceOf(ownAddress).call();

                    case 4:
                        balResult = _context.sent;
                        return _context.abrupt('return', balResult);

                    case 6:
                    case 'end':
                        return _context.stop();
                }
            }
        }, _callee, undefined);
    }));

    return function loadSingle(_x, _x2, _x3) {
        return _ref.apply(this, arguments);
    };
}();

var transferToAddresss = exports.transferToAddresss = function () {
    var _ref2 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(network, wallet, contractAddress, ownAddress, destAddress, amount) {
        var provider, contract, nonceCount, balance, gasPrice, transferAmount, rawTransaction, myAccount, signedTransaction, result;
        return _regenerator2.default.wrap(function _callee2$(_context2) {
            while (1) {
                switch (_context2.prev = _context2.next) {
                    case 0:
                        provider = new _web2.default(new _web2.default.providers.HttpProvider(network.main));
                        contract = new provider.eth.Contract(ABI, contractAddress);
                        _context2.next = 4;
                        return provider.eth.getTransactionCount(ownAddress);

                    case 4:
                        nonceCount = _context2.sent;

                        console.log('None count ' + nonceCount);
                        _context2.next = 8;
                        return contract.methods.balanceOf(ownAddress).call();

                    case 8:
                        balance = _context2.sent;
                        _context2.next = 11;
                        return provider.eth.getGasPrice();

                    case 11:
                        gasPrice = _context2.sent;

                        console.log('Balance before send: ' + balance);
                        _context2.prev = 13;

                        if (!(balance > amount)) {
                            _context2.next = 26;
                            break;
                        }

                        console.log('send possible');
                        transferAmount = "0x" + amount.toString(16);
                        rawTransaction = {
                            "from": ownAddress,
                            "nonce": "0x" + nonceCount.toString(16),
                            "gasPrice": gasPrice,
                            "gasLimit": "0x250CA",
                            "to": contractAddress,
                            "value": "0x0",
                            "data": contract.methods.transfer(destAddress, transferAmount).encodeABI()
                        };
                        myAccount = provider.eth.accounts.privateKeyToAccount(wallet.privateKey);
                        _context2.next = 21;
                        return myAccount.signTransaction(rawTransaction);

                    case 21:
                        signedTransaction = _context2.sent;
                        _context2.next = 24;
                        return provider.eth.sendSignedTransaction(signedTransaction.rawTransaction);

                    case 24:
                        result = _context2.sent;
                        return _context2.abrupt('return', result);

                    case 26:
                        return _context2.abrupt('return', { status: false });

                    case 29:
                        _context2.prev = 29;
                        _context2.t0 = _context2['catch'](13);

                        console.error(_context2.t0);

                    case 32:
                        return _context2.abrupt('return', { status: false });

                    case 33:
                    case 'end':
                        return _context2.stop();
                }
            }
        }, _callee2, undefined, [[13, 29]]);
    }));

    return function transferToAddresss(_x4, _x5, _x6, _x7, _x8, _x9) {
        return _ref2.apply(this, arguments);
    };
}();

exports.default = {
    mixins: [_token2.default],

    computed: (0, _vuex.mapState)({
        account: function account(state) {
            return state.account;
        },
        address: function address(state) {
            return state.wallet.address;
        },
        network: function network(state) {
            return state.network;
        }
    }),

    methods: {
        do20TokenTransfer: function do20TokenTransfer(wallet, tokenId, toAddress, amount) {
            var _this = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee3() {
                var nwork, toUseTokens, _toUseTokens, single, contractAddress;

                return _regenerator2.default.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                nwork = _this.network;
                                toUseTokens = _all_tokens2.default.filter(function (item) {
                                    return item.id == tokenId && item.contract && item.contract[nwork.id];
                                });
                                _toUseTokens = (0, _slicedToArray3.default)(toUseTokens, 1), single = _toUseTokens[0];
                                contractAddress = single.contract[nwork.id];
                                _context3.next = 6;
                                return transferToAddresss(nwork, wallet, contractAddress, _this.address, toAddress, amount);

                            case 6:
                                return _context3.abrupt('return', _context3.sent);

                            case 7:
                            case 'end':
                                return _context3.stop();
                        }
                    }
                }, _callee3, _this);
            }))();
        },
        loadAccount: function loadAccount() {
            var _this2 = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee4() {
                var web3, balance, account, tokens;
                return _regenerator2.default.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                web3 = new _web2.default(new _web2.default.providers.HttpProvider(_this2.network.main));
                                _context4.next = 3;
                                return web3.eth.getBalance(_this2.address);

                            case 3:
                                balance = _context4.sent;
                                account = {};

                                account.balance = (0, _utils.getTokenAmount)(balance, 18);

                                tokens = { '1': { name: '1', precision: 18, balance: balance } };
                                _context4.next = 9;
                                return _this2.loadOtherTokens(_this2.network, tokens, _this2.address);

                            case 9:

                                _this2.$store.commit('account/change', account);
                                _this2.$store.commit('account/tokens', tokens);

                                _context4.next = 13;
                                return _this2.loadTokenData();

                            case 13:
                            case 'end':
                                return _context4.stop();
                        }
                    }
                }, _callee4, _this2);
            }))();
        },
        refreshAccount: function refreshAccount() {
            var _this3 = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee5() {
                return _regenerator2.default.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _this3.$store.commit('loading', true);
                                _context5.next = 3;
                                return _this3.loadAccount();

                            case 3:
                                _this3.$store.commit('loading', false);

                            case 4:
                            case 'end':
                                return _context5.stop();
                        }
                    }
                }, _callee5, _this3);
            }))();
        },
        loadOtherTokens: function loadOtherTokens(network, defaultToken, address) {
            var _this4 = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee6() {
                var toUseTokens, i, balance;
                return _regenerator2.default.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                toUseTokens = _all_tokens2.default.filter(function (item) {
                                    return item.contract && item.contract[network.id];
                                });


                                toUseTokens = toUseTokens.map(function (item) {
                                    var cr = item.contract[network.id];
                                    return (0, _extends3.default)({}, item, { contract: cr });
                                });

                                i = 0;

                            case 3:
                                if (!(i < toUseTokens.length)) {
                                    _context6.next = 17;
                                    break;
                                }

                                _context6.prev = 4;
                                _context6.next = 7;
                                return loadSingle(network, toUseTokens[i].contract, address);

                            case 7:
                                balance = _context6.sent;

                                defaultToken[toUseTokens[i].id] = { name: toUseTokens[i].id.toString(), precision: toUseTokens[i].decimals, balance: balance };

                                _context6.next = 14;
                                break;

                            case 11:
                                _context6.prev = 11;
                                _context6.t0 = _context6['catch'](4);

                                console.error(_context6.t0);

                            case 14:
                                i++;
                                _context6.next = 3;
                                break;

                            case 17:
                            case 'end':
                                return _context6.stop();
                        }
                    }
                }, _callee6, _this4, [[4, 11]]);
            }))();
        }
    }
};

/***/ }),

/***/ 135:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ExternalLink_vue__ = __webpack_require__(254);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ExternalLink_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ExternalLink_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ExternalLink_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ExternalLink_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_0dc33c1c_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_ExternalLink_vue__ = __webpack_require__(634);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ExternalLink_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_0dc33c1c_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_ExternalLink_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_0dc33c1c_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_ExternalLink_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/components/ExternalLink.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-0dc33c1c", Component.options)
  } else {
    hotAPI.reload("data-v-0dc33c1c", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 136:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vuex = __webpack_require__(11);

exports.default = {
    computed: (0, _vuex.mapState)({
        loading: function loading(state) {
            return state.loading;
        }
    })
}; //
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 137:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    namespaced: true,

    state: {
        id: 1,
        name: 'Mainnet',
        main: 'https://bsc-dataseed1.binance.org:443',
        scan: 'https://api.bscscan.com/api',
        type: 'mainnet',
        explore: 'https://bscscan.com',
        apiKey: ''
    },

    mutations: {
        change: function change(state, network) {
            state.id = network.id;
            state.name = network.name;
            state.main = network.main;
            state.type = network.type;
            state.scan = network.scan;
            state.apiKey = network.apiKey;
            state.explore = network.explore;
        }
    }
};

/***/ }),

/***/ 148:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _tokens2 = __webpack_require__(291);

var _tokens3 = _interopRequireDefault(_tokens2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    namespaced: true,

    state: {
        tokens: _tokens3.default
    },

    mutations: {
        tokens: function tokens(state, _tokens) {
            state.tokens = _tokens;
        }
    }
};

/***/ }),

/***/ 149:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vuex = __webpack_require__(11);

var _keystore = __webpack_require__(43);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    data: function data() {
        return {
            password: '',
            error: {
                show: false,
                message: ''
            }
        };
    },

    computed: (0, _vuex.mapState)({
        address: function address(state) {
            return state.wallet.address;
        },
        keystore: function keystore(state) {
            return state.wallet.keystore;
        }
    }),

    methods: {
        submitForm: function submitForm(e) {
            e.preventDefault();

            var wallet = (0, _keystore.decryptKeyStore)(this.password, this.keystore);

            if (!wallet) {
                this.error.show = true;
                this.error.message = 'Password is incorrect';

                return false;
            }

            this.$store.commit('wallet/address', wallet.address);
            this.$store.commit('wallet/keypass', this.password);
            this.$router.push('/');
        }
    }
};

/***/ }),

/***/ 208:
/***/ (function(module, exports) {

module.exports = {"sha224WithRSAEncryption":{"sign":"rsa","hash":"sha224","id":"302d300d06096086480165030402040500041c"},"RSA-SHA224":{"sign":"ecdsa/rsa","hash":"sha224","id":"302d300d06096086480165030402040500041c"},"sha256WithRSAEncryption":{"sign":"rsa","hash":"sha256","id":"3031300d060960864801650304020105000420"},"RSA-SHA256":{"sign":"ecdsa/rsa","hash":"sha256","id":"3031300d060960864801650304020105000420"},"sha384WithRSAEncryption":{"sign":"rsa","hash":"sha384","id":"3041300d060960864801650304020205000430"},"RSA-SHA384":{"sign":"ecdsa/rsa","hash":"sha384","id":"3041300d060960864801650304020205000430"},"sha512WithRSAEncryption":{"sign":"rsa","hash":"sha512","id":"3051300d060960864801650304020305000440"},"RSA-SHA512":{"sign":"ecdsa/rsa","hash":"sha512","id":"3051300d060960864801650304020305000440"},"RSA-SHA1":{"sign":"rsa","hash":"sha1","id":"3021300906052b0e03021a05000414"},"ecdsa-with-SHA1":{"sign":"ecdsa","hash":"sha1","id":""},"sha256":{"sign":"ecdsa","hash":"sha256","id":""},"sha224":{"sign":"ecdsa","hash":"sha224","id":""},"sha384":{"sign":"ecdsa","hash":"sha384","id":""},"sha512":{"sign":"ecdsa","hash":"sha512","id":""},"DSA-SHA":{"sign":"dsa","hash":"sha1","id":""},"DSA-SHA1":{"sign":"dsa","hash":"sha1","id":""},"DSA":{"sign":"dsa","hash":"sha1","id":""},"DSA-WITH-SHA224":{"sign":"dsa","hash":"sha224","id":""},"DSA-SHA224":{"sign":"dsa","hash":"sha224","id":""},"DSA-WITH-SHA256":{"sign":"dsa","hash":"sha256","id":""},"DSA-SHA256":{"sign":"dsa","hash":"sha256","id":""},"DSA-WITH-SHA384":{"sign":"dsa","hash":"sha384","id":""},"DSA-SHA384":{"sign":"dsa","hash":"sha384","id":""},"DSA-WITH-SHA512":{"sign":"dsa","hash":"sha512","id":""},"DSA-SHA512":{"sign":"dsa","hash":"sha512","id":""},"DSA-RIPEMD160":{"sign":"dsa","hash":"rmd160","id":""},"ripemd160WithRSA":{"sign":"rsa","hash":"rmd160","id":"3021300906052b2403020105000414"},"RSA-RIPEMD160":{"sign":"rsa","hash":"rmd160","id":"3021300906052b2403020105000414"},"md5WithRSAEncryption":{"sign":"rsa","hash":"md5","id":"3020300c06082a864886f70d020505000410"},"RSA-MD5":{"sign":"rsa","hash":"md5","id":"3020300c06082a864886f70d020505000410"}}

/***/ }),

/***/ 213:
/***/ (function(module, exports) {

module.exports = {"aes-128-ecb":{"cipher":"AES","key":128,"iv":0,"mode":"ECB","type":"block"},"aes-192-ecb":{"cipher":"AES","key":192,"iv":0,"mode":"ECB","type":"block"},"aes-256-ecb":{"cipher":"AES","key":256,"iv":0,"mode":"ECB","type":"block"},"aes-128-cbc":{"cipher":"AES","key":128,"iv":16,"mode":"CBC","type":"block"},"aes-192-cbc":{"cipher":"AES","key":192,"iv":16,"mode":"CBC","type":"block"},"aes-256-cbc":{"cipher":"AES","key":256,"iv":16,"mode":"CBC","type":"block"},"aes128":{"cipher":"AES","key":128,"iv":16,"mode":"CBC","type":"block"},"aes192":{"cipher":"AES","key":192,"iv":16,"mode":"CBC","type":"block"},"aes256":{"cipher":"AES","key":256,"iv":16,"mode":"CBC","type":"block"},"aes-128-cfb":{"cipher":"AES","key":128,"iv":16,"mode":"CFB","type":"stream"},"aes-192-cfb":{"cipher":"AES","key":192,"iv":16,"mode":"CFB","type":"stream"},"aes-256-cfb":{"cipher":"AES","key":256,"iv":16,"mode":"CFB","type":"stream"},"aes-128-cfb8":{"cipher":"AES","key":128,"iv":16,"mode":"CFB8","type":"stream"},"aes-192-cfb8":{"cipher":"AES","key":192,"iv":16,"mode":"CFB8","type":"stream"},"aes-256-cfb8":{"cipher":"AES","key":256,"iv":16,"mode":"CFB8","type":"stream"},"aes-128-cfb1":{"cipher":"AES","key":128,"iv":16,"mode":"CFB1","type":"stream"},"aes-192-cfb1":{"cipher":"AES","key":192,"iv":16,"mode":"CFB1","type":"stream"},"aes-256-cfb1":{"cipher":"AES","key":256,"iv":16,"mode":"CFB1","type":"stream"},"aes-128-ofb":{"cipher":"AES","key":128,"iv":16,"mode":"OFB","type":"stream"},"aes-192-ofb":{"cipher":"AES","key":192,"iv":16,"mode":"OFB","type":"stream"},"aes-256-ofb":{"cipher":"AES","key":256,"iv":16,"mode":"OFB","type":"stream"},"aes-128-ctr":{"cipher":"AES","key":128,"iv":16,"mode":"CTR","type":"stream"},"aes-192-ctr":{"cipher":"AES","key":192,"iv":16,"mode":"CTR","type":"stream"},"aes-256-ctr":{"cipher":"AES","key":256,"iv":16,"mode":"CTR","type":"stream"},"aes-128-gcm":{"cipher":"AES","key":128,"iv":12,"mode":"GCM","type":"auth"},"aes-192-gcm":{"cipher":"AES","key":192,"iv":12,"mode":"GCM","type":"auth"},"aes-256-gcm":{"cipher":"AES","key":256,"iv":12,"mode":"GCM","type":"auth"}}

/***/ }),

/***/ 226:
/***/ (function(module, exports) {

module.exports = {"1.3.132.0.10":"secp256k1","1.3.132.0.33":"p224","1.2.840.10045.3.1.1":"p192","1.2.840.10045.3.1.7":"p256","1.3.132.0.34":"p384","1.3.132.0.35":"p521"}

/***/ }),

/***/ 240:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vuex = __webpack_require__(11);

var _keystore = __webpack_require__(43);

var _config = __webpack_require__(241);

var _config2 = _interopRequireDefault(_config);

var _api = __webpack_require__(131);

var _api2 = _interopRequireDefault(_api);

var _web = __webpack_require__(34);

var _web2 = _interopRequireDefault(_web);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    data: function data() {
        return {
            password: '',
            wallet: false,
            error: {
                show: false,
                message: ''
            },
            showDropdownMenu: false,
            showNetworkDropdown: false,
            selectedNetwork: '',
            networks: []
        };
    },

    mounted: function mounted() {
        this.networks = _config2.default.networks;
    },


    computed: (0, _vuex.mapState)({
        address: function address(state) {
            return state.wallet.address;
        },
        keystore: function keystore(state) {
            return state.wallet.keystore;
        },
        currentNetwork: function currentNetwork(state) {
            return state.network;
        }
    }),

    methods: {
        toggleDropdownMenu: function toggleDropdownMenu() {
            this.showDropdownMenu = this.showDropdownMenu ? false : true;
        },
        hideDropdownMenu: function hideDropdownMenu() {
            this.showDropdownMenu = false;
        },
        toggleNetworkDropdown: function toggleNetworkDropdown() {
            this.showNetworkDropdown = this.showNetworkDropdown ? false : true;
        },
        hideNetworkDropdown: function hideNetworkDropdown() {
            this.showNetworkDropdown = false;
        },
        changeNetwork: function changeNetwork(network) {
            this.showNetworkDropdown = false;
            this.selectedNetwork = network;
            this.$store.commit('network/change', network);
        },
        submitForm: function submitForm(e) {
            e.preventDefault();

            if (this.password.length < 8) {
                this.error.show = true;
                this.error.message = 'Password is not long enough';
                return false;
            }

            var web3 = new _web2.default(new _web2.default.providers.HttpProvider(this.selectedNetwork.main));

            _api2.default.client = web3;

            this.wallet = web3.eth.accounts.create();
        },
        savePrivateKey: function savePrivateKey(e) {
            e.preventDefault();

            var keystore = (0, _keystore.encryptKeyStore)(this.password, this.wallet.privateKey, this.wallet.address);

            this.$store.commit('wallet/address', this.wallet.address);
            this.$store.commit('wallet/keypass', this.password);
            this.$store.commit('wallet/keystore', keystore);
            this.$router.push('/');
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 241:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    networks: [{
        id: 1,
        name: 'Mainnet',
        main: 'https://bsc-dataseed1.binance.org:443',
        scan: 'https://api.bscscan.com/api',
        explore: 'https://bscscan.com/',
        type: 'mainnet',
        apiKey: 'NJJ3NK3UTG95N68PAVP31AQA7EBWNY5FDJ'
    }, {
        id: 2,
        name: 'Testnet',
        main: 'https://data-seed-prebsc-1-s1.binance.org:8545',
        scan: 'https://api-testnet.bscscan.com/api',
        explore: 'https://testnet.bscscan.com/',
        type: 'testnet',
        apiKey: 'NJJ3NK3UTG95N68PAVP31AQA7EBWNY5FDJ'
    }]
};

/***/ }),

/***/ 242:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vuex = __webpack_require__(11);

var _keystore = __webpack_require__(43);

var _web = __webpack_require__(34);

var _web2 = _interopRequireDefault(_web);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    data: function data() {
        return {
            password: '',
            privateKey: '',
            error: {
                show: false,
                message: ''
            },
            showDropdownMenu: false,
            showNetworkDropdown: false,
            selectedNetwork: '',
            networks: []
        };
    },

    computed: (0, _vuex.mapState)({
        address: function address(state) {
            return state.wallet.address;
        },
        keystore: function keystore(state) {
            return state.wallet.keystore;
        },
        currentNetwork: function currentNetwork(state) {
            return state.network;
        }
    }),

    methods: {
        toggleDropdownMenu: function toggleDropdownMenu() {
            this.showDropdownMenu = this.showDropdownMenu ? false : true;
        },
        hideDropdownMenu: function hideDropdownMenu() {
            this.showDropdownMenu = false;
        },
        toggleNetworkDropdown: function toggleNetworkDropdown() {
            this.showNetworkDropdown = this.showNetworkDropdown ? false : true;
        },
        hideNetworkDropdown: function hideNetworkDropdown() {
            this.showNetworkDropdown = false;
        },
        changeNetwork: function changeNetwork(network) {
            this.showNetworkDropdown = false;
            this.selectedNetwork = network;
            this.$store.commit('network/change', network);
        },
        submitForm: function submitForm(e) {
            e.preventDefault();

            if (this.password.length < 8) {
                this.error.show = true;
                this.error.message = 'Password is not long enough';

                return false;
            }

            var web3 = new _web2.default(new _web2.default.providers.HttpProvider(this.selectedNetwork.main));

            var account = web3.eth.accounts.privateKeyToAccount(this.privateKey);

            var keystore = (0, _keystore.encryptKeyStore)(this.password, this.privateKey, account.address);

            this.$store.commit('wallet/address', account.address);
            this.$store.commit('wallet/keypass', this.password);
            this.$store.commit('wallet/keystore', keystore);
            this.$router.push('/');
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 243:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _account = __webpack_require__(132);

var _account2 = _interopRequireDefault(_account);

var _AppHeader = __webpack_require__(29);

var _AppHeader2 = _interopRequireDefault(_AppHeader);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    mixins: [_account2.default],

    components: {
        AppHeader: _AppHeader2.default
    },

    mounted: function mounted() {
        this.loadAccount();
    }
};

/***/ }),

/***/ 249:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var BTCB = __webpack_require__(614);
var BURGER = __webpack_require__(615);
var BUSD = __webpack_require__(616);
var ETH = __webpack_require__(617);
var LTC = __webpack_require__(618);
var PROM = __webpack_require__(619);
var VENUS = __webpack_require__(620);
var WBNB = __webpack_require__(621);
var XRP = __webpack_require__(622);

var ALL_TOKENS = [BTCB, BURGER, BUSD, ETH, LTC, PROM, VENUS, WBNB, XRP];
exports.default = ALL_TOKENS;

/***/ }),

/***/ 250:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _regenerator = __webpack_require__(50);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(51);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _vuex = __webpack_require__(11);

var _utils = __webpack_require__(63);

var _all_tokens = __webpack_require__(249);

var _all_tokens2 = _interopRequireDefault(_all_tokens);

var _token = __webpack_require__(148);

var _token2 = _interopRequireDefault(_token);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    computed: (0, _vuex.mapState)({
        token: function token(state) {
            return state.token.tokens;
        }
    }),

    methods: {
        getTokenAmount: _utils.getTokenAmount,

        loadTokenData: function loadTokenData() {
            var _this = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
                var token;
                return _regenerator2.default.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _this.getTokenData();

                            case 2:
                                token = _context.sent;

                                _this.$store.commit('token/tokens', token);

                            case 4:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, _this);
            }))();
        },
        getTokenData: function getTokenData() {
            var _this2 = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2() {
                var tokens, single, i, at;
                return _regenerator2.default.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                tokens = {};
                                single = 'BNB;BNB;18';

                                tokens['1'] = single;

                                for (i = 0; i < _all_tokens2.default.length; i++) {
                                    at = _all_tokens2.default[i];

                                    tokens[at.id.toString()] = at.code + ';' + at.code + ';' + at.decimals;
                                }
                                return _context2.abrupt('return', tokens);

                            case 5:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, _this2);
            }))();
        },
        getTokenDetails: function getTokenDetails(tokenId) {
            if (this.token[tokenId] == undefined) {
                return ['TOKEN', 'TOKEN', '0'];
            }
            return this.token[tokenId].split(';');
        }
    }
};

/***/ }),

/***/ 251:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vuex = __webpack_require__(11);

var _config = __webpack_require__(241);

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    props: {
        subtitle: {
            default: false
        }
    },

    data: function data() {
        return {
            showDropdownMenu: false,
            showNetworkDropdown: false,
            networks: []
        };
    },

    computed: (0, _vuex.mapState)({
        route: function route(state) {
            return state.route;
        },
        currentNetwork: function currentNetwork(state) {
            return state.network;
        }
    }),

    mounted: function mounted() {
        this.networks = _config2.default.networks;
    },


    methods: {
        toggleDropdownMenu: function toggleDropdownMenu() {
            this.showDropdownMenu = this.showDropdownMenu ? false : true;
        },
        hideDropdownMenu: function hideDropdownMenu() {
            this.showDropdownMenu = false;
        },
        toggleNetworkDropdown: function toggleNetworkDropdown() {
            this.showNetworkDropdown = this.showNetworkDropdown ? false : true;
        },
        hideNetworkDropdown: function hideNetworkDropdown() {
            this.showNetworkDropdown = false;
        },
        changeNetwork: function changeNetwork(network) {
            this.showNetworkDropdown = false;
            this.$store.commit('network/change', network);
            this.refreshData();
        },
        refreshData: function refreshData() {
            this.$emit('refresh');
            this.showDropdownMenu = false;
        },
        logout: function logout() {
            this.$store.commit('wallet/address', false);
            this.$store.commit('wallet/keypass', false);
            this.$router.push('/signin');
        }
    }
};

/***/ }),

/***/ 252:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _account = __webpack_require__(132);

var _account2 = _interopRequireDefault(_account);

var _AppHeader = __webpack_require__(29);

var _AppHeader2 = _interopRequireDefault(_AppHeader);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    mixins: [_account2.default],

    components: {
        AppHeader: _AppHeader2.default
    },

    mounted: function mounted() {
        if (this.account.tokens.length === 0) {
            this.loadAccount();
        }
    }
};

/***/ }),

/***/ 253:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _regenerator = __webpack_require__(50);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(51);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _vuex = __webpack_require__(11);

var _utils = __webpack_require__(63);

var _api = __webpack_require__(131);

var _api2 = _interopRequireDefault(_api);

var _AppHeader = __webpack_require__(29);

var _AppHeader2 = _interopRequireDefault(_AppHeader);

var _ExternalLink = __webpack_require__(135);

var _ExternalLink2 = _interopRequireDefault(_ExternalLink);

var _token = __webpack_require__(250);

var _token2 = _interopRequireDefault(_token);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    mixins: [_token2.default],

    components: {
        AppHeader: _AppHeader2.default,
        ExternalLink: _ExternalLink2.default
    },

    data: function data() {
        return {
            start: 0,
            limit: 30,
            page: 1,
            lastPage: 1,
            loadMoreLoading: false
        };
    },

    computed: (0, _vuex.mapState)({
        address: function address(state) {
            return state.wallet.address;
        },
        keystore: function keystore(state) {
            return state.wallet.keystore;
        },
        transfers: function transfers(state) {
            return state.account.transfers;
        }
    }),

    mounted: function mounted() {
        this.loadTransfers();
    },


    methods: {
        loadTransfers: function loadTransfers() {
            var _this = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
                var transfersData;
                return _regenerator2.default.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _this.page = 1;
                                _this.start = 0;

                                _context.next = 4;
                                return (0, _api2.default)().getTransfers({ address: _this.address, start: _this.start, limit: _this.limit });

                            case 4:
                                transfersData = _context.sent;

                                _this.lastPage = Math.ceil(transfersData.total / _this.limit);

                                _this.$store.commit('account/transfers', transfersData.transfers);
                                _this.$store.commit('loading', false);

                                _context.next = 10;
                                return _this.loadTokenData();

                            case 10:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, _this);
            }))();
        },
        loadMore: function loadMore(e) {
            var _this2 = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2() {
                var transfersData;
                return _regenerator2.default.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                e.preventDefault();
                                _this2.loadMoreLoading = true;

                                _this2.start += _this2.limit;
                                _context2.next = 5;
                                return (0, _api2.default)().getTransfers({ address: _this2.address, start: _this2.start, limit: _this2.limit });

                            case 5:
                                transfersData = _context2.sent;


                                _this2.page += 1;
                                _this2.$store.commit('account/pushTransfers', transfersData.transfers);
                                _this2.loadMoreLoading = false;

                            case 9:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, _this2);
            }))();
        },
        refreshTransfers: function refreshTransfers() {
            this.$store.commit('loading', true);
            this.loadTransfers();
        },
        getTransferLink: function getTransferLink(hash) {
            var path = 'transaction/' + hash;

            return (0, _utils.getScanLink)(path);
        },
        isOutgoingTransfer: function isOutgoingTransfer(transfer) {
            return transfer.transferFromAddress === this.address;
        },
        formatTokenAmount: function formatTokenAmount(transfer) {
            var tokenDetails = ['BNB', 'BNB', '18'];

            if (transfer.tokenName !== '_') {
                tokenDetails = this.getTokenDetails(transfer.tokenName);
            }

            var tokenAmount = this.$formatNumber(this.getTokenAmount(transfer.amount, tokenDetails[2]), { maximumSignificantDigits: parseInt(tokenDetails[2]) + 1 });

            return tokenAmount + ' ' + tokenDetails[1];
        },
        theTokenName: function theTokenName(transfer) {
            if (transfer.tokenName === '_') {
                return 'TRX';
            }

            return transfer.tokenName;
        },
        compressAddress: function compressAddress(address) {
            return address.substr(0, 10) + '...' + address.substr(address.length - 5, address.length);
        }
    }
};

/***/ }),

/***/ 254:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//

exports.default = {
    props: ['url'],

    methods: {
        clicked: function clicked(e) {
            e.preventDefault();

            chrome.tabs.create({ url: this.url });
        }
    }
};

/***/ }),

/***/ 255:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _regenerator = __webpack_require__(50);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(51);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _vuex = __webpack_require__(11);

var _utils = __webpack_require__(63);

var _keystore = __webpack_require__(43);

var _AppHeader = __webpack_require__(29);

var _AppHeader2 = _interopRequireDefault(_AppHeader);

var _ExternalLink = __webpack_require__(135);

var _ExternalLink2 = _interopRequireDefault(_ExternalLink);

var _transactions = __webpack_require__(639);

var _transactions2 = _interopRequireDefault(_transactions);

var _web = __webpack_require__(34);

var _web2 = _interopRequireDefault(_web);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: {
        AppHeader: _AppHeader2.default,
        ExternalLink: _ExternalLink2.default
    },

    data: function data() {
        return {
            start: 0,
            limit: 30,
            page: 1,
            lastPage: 1,
            loadMoreLoading: false
        };
    },

    computed: (0, _vuex.mapState)({
        wallet: function wallet(state) {
            return state.wallet;
        },
        address: function address(state) {
            return state.wallet.address;
        },
        keystore: function keystore(state) {
            return state.wallet.keystore;
        },
        transactions: function transactions(state) {
            return state.account.transactions;
        },
        network: function network(state) {
            return state.network;
        }
    }),

    mounted: function mounted() {
        this.loadTransactions();
    },


    methods: {
        loadTransactions: function loadTransactions() {
            var _this = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
                var transactionsData;
                return _regenerator2.default.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _this.page = 1;
                                _this.start = 0;

                                _context.next = 4;
                                return (0, _transactions2.default)(_this.network, _this.address);

                            case 4:
                                transactionsData = _context.sent;


                                _this.$store.commit('account/transactions', transactionsData);
                                _this.$store.commit('loading', false);

                            case 7:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, _this);
            }))();
        },
        loadMore: function loadMore(e) {
            var _this2 = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2() {
                return _regenerator2.default.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                e.preventDefault();
                                _this2.loadMoreLoading = false;

                            case 2:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, _this2);
            }))();
        },
        refreshTransactions: function refreshTransactions() {
            this.$store.commit('loading', true);
            this.loadTransactions();
        },
        getContractName: function getContractName(contractType) {
            return _utils.CONTRACT_TYPES[contractType];
        },
        getTransactionLink: function getTransactionLink(hash) {
            return (0, _utils.getScanlink)(hash) + 'tx/' + hash;
        },
        formatStamp: function formatStamp(stamp, opts) {
            var dt = new Date(stamp * 1000);
            return dt.toLocaleString();
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 256:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _regenerator = __webpack_require__(50);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(51);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _extends2 = __webpack_require__(244);

var _extends3 = _interopRequireDefault(_extends2);

var _vuex = __webpack_require__(11);

var _keystore = __webpack_require__(43);

var _utils = __webpack_require__(63);

var _api = __webpack_require__(131);

var _api2 = _interopRequireDefault(_api);

var _account = __webpack_require__(132);

var _account2 = _interopRequireDefault(_account);

var _AppHeader = __webpack_require__(29);

var _AppHeader2 = _interopRequireDefault(_AppHeader);

var _ConfirmDialog = __webpack_require__(642);

var _ConfirmDialog2 = _interopRequireDefault(_ConfirmDialog);

var _web = __webpack_require__(34);

var _web2 = _interopRequireDefault(_web);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    mixins: [_account2.default],

    components: {
        AppHeader: _AppHeader2.default,
        ConfirmDialog: _ConfirmDialog2.default
    },

    data: function data() {
        return {
            amount: 0,
            receipient: '',
            selectedToken: false,
            message: {
                show: false,
                type: 'error',
                text: ''
            }
        };
    },

    computed: (0, _extends3.default)({
        confirmDialogText: function confirmDialogText() {
            return '\n                Are you sure you want to transfer\n                <div><strong>' + this.amount + ' ' + this.getTokenName(this.selectedToken) + '</strong></div>\n                <div>to</div>\n                <div><strong>' + this.receipient + '</strong> ?</div>\n            ';
        }
    }, (0, _vuex.mapState)({
        wallet: function wallet(state) {
            return state.wallet;
        },
        network: function network(state) {
            return state.network;
        },
        transactions: function transactions(state) {
            return state.account.transactions;
        }
    })),

    mounted: function mounted() {
        this.setSelectedToken();
        if (this.account.tokens.length === 0) {
            this.loadTokens();
        }
    },


    methods: {
        setSelectedToken: function setSelectedToken() {
            if (this.account.tokens.length > 0) {
                this.selectedToken = this.account.tokens[0];
            }
        },
        loadTokens: function loadTokens() {
            var _this = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
                return _regenerator2.default.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _this.loadAccount();

                            case 2:
                                _this.setSelectedToken();
                                _this.$store.commit('loading', false);

                            case 4:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, _this);
            }))();
        },
        sendPayment: function sendPayment() {
            var _this2 = this;

            return (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2() {
                var wallet, amount, web3, pAccount, result, gasPrice;
                return _regenerator2.default.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                wallet = (0, _keystore.decryptKeyStore)(_this2.wallet.keypass, _this2.wallet.keystore);

                                if (wallet) {
                                    _context2.next = 6;
                                    break;
                                }

                                _this2.message.show = true;
                                _this2.message.type = 'error';
                                _this2.message.text = 'Something went wrong while trying to send the payment';

                                return _context2.abrupt('return', false);

                            case 6:

                                _this2.$store.commit('loading', true);

                                amount = _this2.amount;


                                if (_this2.selectedToken.name === "_") {
                                    amount = (0, _utils.getTokenRawAmount)(_this2.amount);
                                } else {
                                    amount = (0, _utils.getTokenRawAmount)(_this2.amount, _this2.getTokenDetails(_this2.selectedToken.name)[2]);
                                }

                                console.log(_this2.selectedToken);
                                console.log(_this2.getTokenDetails(_this2.selectedToken.name));

                                _context2.prev = 11;
                                web3 = new _web2.default(new _web2.default.providers.HttpProvider(_this2.network.main));
                                pAccount = web3.eth.accounts.privateKeyToAccount(wallet.privateKey);


                                web3.eth.accounts.wallet.add(pAccount);

                                result = {};

                                if (!(_this2.selectedToken.name !== "1")) {
                                    _context2.next = 22;
                                    break;
                                }

                                _context2.next = 19;
                                return _this2.do20TokenTransfer(wallet, _this2.selectedToken.name, _this2.receipient, amount);

                            case 19:
                                result = _context2.sent;
                                _context2.next = 28;
                                break;

                            case 22:
                                _context2.next = 24;
                                return web3.eth.getGasPrice();

                            case 24:
                                gasPrice = _context2.sent;
                                _context2.next = 27;
                                return web3.eth.sendTransaction({ from: wallet.address,
                                    to: _this2.receipient,
                                    value: amount,
                                    gas: 2000000,
                                    gasPrice: gasPrice });

                            case 27:
                                result = _context2.sent;

                            case 28:

                                _this2.$store.commit('loading', false);

                                _this2.message.show = true;

                                if (result.status) {
                                    _this2.message.type = 'success';
                                    _this2.message.text = 'Payment has been successfully sent';
                                } else {
                                    _this2.message.type = 'error';
                                    _this2.message.text = result.message;
                                }

                                _this2.loadTokens();
                                _this2.receipient = '';
                                _this2.amount = 0;
                                _context2.next = 43;
                                break;

                            case 36:
                                _context2.prev = 36;
                                _context2.t0 = _context2['catch'](11);

                                console.error(_context2.t0);
                                _this2.$store.commit('loading', false);

                                _this2.message.show = true;
                                _this2.message.type = 'error';
                                _this2.message.text = 'Something went wrong while trying to send the payment';

                            case 43:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, _this2, [[11, 36]]);
            }))();
        },
        showConfirmDialog: function showConfirmDialog() {
            this.message.show = false;

            if (!_web2.default.utils.isAddress(this.receipient)) {
                this.message.show = true;
                this.message.type = 'error';
                this.message.text = 'Invalid recipient address';

                return false;
            }

            if (!this.selectedToken) {
                this.message.show = true;
                this.message.type = 'error';
                this.message.text = 'Please select token that you want to send';

                return false;
            }

            var precision = 6;

            if (this.selectedToken.name !== '_') {
                precision = parseInt(this.getTokenDetails(this.selectedToken.name)[2]);
            }

            if (this.amount > this.selectedToken.balance) {
                this.message.show = true;
                this.message.type = 'error';
                this.message.text = 'Insufficient funds';

                return false;
            }

            if (this.amount <= 0) {
                this.message.show = true;
                this.message.type = 'error';
                this.message.text = 'Invalid token amount';

                return false;
            }

            this.$refs.confirmDialog.showDialog();
        },
        refreshTokens: function refreshTokens() {
            this.message.show = false;
            this.$store.commit('loading', true);
            this.loadTokens();
        },
        getTokenName: function getTokenName(token) {
            if (token.name === '_') {
                return 'BNB';
            }

            return this.getTokenDetails(token.name)[1];
        },
        getTokenBalance: function getTokenBalance(token) {
            var precision = 6;

            if (token.name !== '_') {
                precision = parseInt(this.getTokenDetails(token.name)[2]);
            }
            //return token.balance;
            return this.$formatNumber(this.getTokenAmount(token.balance, precision), { maximumSignificantDigits: precision + 1 });
        }
    }
};

/***/ }),

/***/ 257:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//

exports.default = {
    props: ['text'],

    methods: {
        showDialog: function showDialog() {
            var _this = this;

            this.$modal.show('dialog', {
                text: this.text,
                buttons: [{
                    title: 'CANCEL',
                    class: 'vue-dialog-button secondary',
                    handler: function handler() {
                        _this.$modal.hide('dialog');
                    }
                }, {
                    title: 'CONFIRM',
                    default: true,
                    class: 'vue-dialog-button primary',
                    handler: function handler() {
                        _this.$modal.hide('dialog');
                        _this.$emit('confirmed');
                    }
                }]
            });
        }
    }
};

/***/ }),

/***/ 258:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vuex = __webpack_require__(11);

var _AppHeader = __webpack_require__(29);

var _AppHeader2 = _interopRequireDefault(_AppHeader);

var _qrcode = __webpack_require__(650);

var _qrcode2 = _interopRequireDefault(_qrcode);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: {
        AppHeader: _AppHeader2.default,
        QrcodeVue: _qrcode2.default
    },

    computed: (0, _vuex.mapState)({
        address: function address(state) {
            return state.wallet.address;
        }
    })
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 259:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vuex = __webpack_require__(11);

var _keystore = __webpack_require__(43);

var _AppHeader = __webpack_require__(29);

var _AppHeader2 = _interopRequireDefault(_AppHeader);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    components: {
        AppHeader: _AppHeader2.default
    },

    data: function data() {
        return {
            password: '',
            wallet: false,
            error: {
                show: false,
                message: ''
            }
        };
    },

    computed: (0, _vuex.mapState)({
        keystore: function keystore(state) {
            return state.wallet.keystore;
        }
    }),

    methods: {
        submitForm: function submitForm() {
            var wallet = (0, _keystore.decryptKeyStore)(this.password, this.keystore);

            if (!wallet) {
                this.error.show = true;
                this.error.message = 'Password is incorrect';

                return false;
            }

            this.wallet = wallet;
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 260:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _AppHeader = __webpack_require__(29);

var _AppHeader2 = _interopRequireDefault(_AppHeader);

var _ExternalLink = __webpack_require__(135);

var _ExternalLink2 = _interopRequireDefault(_ExternalLink);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    components: {
        AppHeader: _AppHeader2.default,
        ExternalLink: _ExternalLink2.default
    }
};

/***/ }),

/***/ 261:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _vue = __webpack_require__(81);

var _vue2 = _interopRequireDefault(_vue);

var _App = __webpack_require__(263);

var _App2 = _interopRequireDefault(_App);

var _store = __webpack_require__(82);

var _store2 = _interopRequireDefault(_store);

var _router = __webpack_require__(292);

var _router2 = _interopRequireDefault(_router);

var _vuexRouterSync = __webpack_require__(658);

var _vueIntl = __webpack_require__(659);

var _vueIntl2 = _interopRequireDefault(_vueIntl);

var _vClickOutside = __webpack_require__(660);

var _vClickOutside2 = _interopRequireDefault(_vClickOutside);

var _vueClipboard = __webpack_require__(661);

var _vueClipboard2 = _interopRequireDefault(_vueClipboard);

var _vueJsModal = __webpack_require__(663);

var _vueJsModal2 = _interopRequireDefault(_vueJsModal);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_vue2.default.config.productionTip = false;

(0, _vuexRouterSync.sync)(_store2.default, _router2.default);

_vue2.default.use(_vueIntl2.default);
_vue2.default.use(_vClickOutside2.default);
_vue2.default.use(_vueClipboard2.default);
_vue2.default.use(_vueJsModal2.default, { dialog: true });

_vue2.default.setLocale('en-US');

new _vue2.default({
    store: _store2.default,
    router: _router2.default,
    render: function render(h) {
        return h(_App2.default);
    }
}).$mount('#app');

/***/ }),

/***/ 263:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_App_vue__ = __webpack_require__(136);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_App_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_App_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_App_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_App_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_3a0a60d6_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_App_vue__ = __webpack_require__(269);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
function injectStyle (context) {
  if (disposed) return
  __webpack_require__(264)
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_App_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_3a0a60d6_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_App_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_3a0a60d6_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_App_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/App.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-3a0a60d6", Component.options)
  } else {
    hotAPI.reload("data-v-3a0a60d6", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 264:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(265);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(22).default
var update = add("96c30158", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js?{\"minimize\":false}!../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./App.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js?{\"minimize\":false}!../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./App.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 265:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports
exports.i(__webpack_require__(266), "");
exports.i(__webpack_require__(267), "");

// module
exports.push([module.i, "\n", ""]);

// exports


/***/ }),

/***/ 266:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports


// module
exports.push([module.i, "/*! normalize.css v8.0.0 | MIT License | github.com/necolas/normalize.css */\n\n/* Document\n========================================================================== */\n\n/**\n * 1. Correct the line height in all browsers.\n * 2. Prevent adjustments of font size after orientation changes in iOS.\n */\n\n html {\n    line-height: 1.15; /* 1 */\n    -webkit-text-size-adjust: 100%; /* 2 */\n}\n\n/* Sections\n========================================================================== */\n\n/**\n * Remove the margin in all browsers.\n */\n\nbody {\n    margin: 0;\n}\n\n/**\n * Correct the font size and margin on `h1` elements within `section` and\n * `article` contexts in Chrome, Firefox, and Safari.\n */\n\nh1 {\n    font-size: 2em;\n    margin: 0.67em 0;\n}\n\n/* Grouping content\n========================================================================== */\n\n/**\n * 1. Add the correct box sizing in Firefox.\n * 2. Show the overflow in Edge and IE.\n */\n\nhr {\n    box-sizing: content-box; /* 1 */\n    height: 0; /* 1 */\n    overflow: visible; /* 2 */\n}\n\n/**\n * 1. Correct the inheritance and scaling of font size in all browsers.\n * 2. Correct the odd `em` font sizing in all browsers.\n */\n\npre {\n    font-family: monospace, monospace; /* 1 */\n    font-size: 1em; /* 2 */\n}\n\n/* Text-level semantics\n========================================================================== */\n\n/**\n * Remove the gray background on active links in IE 10.\n */\n\na {\n    background-color: transparent;\n}\n\n/**\n * 1. Remove the bottom border in Chrome 57-\n * 2. Add the correct text decoration in Chrome, Edge, IE, Opera, and Safari.\n */\n\nabbr[title] {\n    border-bottom: none; /* 1 */\n    text-decoration: underline; /* 2 */\n    text-decoration: underline dotted; /* 2 */\n}\n\n/**\n * Add the correct font weight in Chrome, Edge, and Safari.\n */\n\nb,\nstrong {\n    font-weight: bolder;\n}\n\n/**\n * 1. Correct the inheritance and scaling of font size in all browsers.\n * 2. Correct the odd `em` font sizing in all browsers.\n */\n\ncode,\nkbd,\nsamp {\n    font-family: monospace, monospace; /* 1 */\n    font-size: 1em; /* 2 */\n}\n\n/**\n * Add the correct font size in all browsers.\n */\n\nsmall {\n    font-size: 80%;\n}\n\n/**\n * Prevent `sub` and `sup` elements from affecting the line height in\n * all browsers.\n */\n\nsub,\nsup {\n    font-size: 75%;\n    line-height: 0;\n    position: relative;\n    vertical-align: baseline;\n}\n\nsub {\n    bottom: -0.25em;\n}\n\nsup {\n    top: -0.5em;\n}\n\n/* Embedded content\n========================================================================== */\n\n/**\n * Remove the border on images inside links in IE 10.\n */\n\nimg {\n    border-style: none;\n}\n\n/* Forms\n========================================================================== */\n\n/**\n * 1. Change the font styles in all browsers.\n * 2. Remove the margin in Firefox and Safari.\n */\n\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n    font-family: inherit; /* 1 */\n    font-size: 100%; /* 1 */\n    line-height: 1.15; /* 1 */\n    margin: 0; /* 2 */\n}\n\n/**\n * Show the overflow in IE.\n * 1. Show the overflow in Edge.\n */\n\nbutton,\ninput { /* 1 */\n    overflow: visible;\n}\n\n/**\n * Remove the inheritance of text transform in Edge, Firefox, and IE.\n * 1. Remove the inheritance of text transform in Firefox.\n */\n\nbutton,\nselect { /* 1 */\n    text-transform: none;\n}\n\n/**\n * Correct the inability to style clickable types in iOS and Safari.\n */\n\nbutton,\n[type=\"button\"],\n[type=\"reset\"],\n[type=\"submit\"] {\n    -webkit-appearance: button;\n}\n\n/**\n * Remove the inner border and padding in Firefox.\n */\n\nbutton::-moz-focus-inner,\n[type=\"button\"]::-moz-focus-inner,\n[type=\"reset\"]::-moz-focus-inner,\n[type=\"submit\"]::-moz-focus-inner {\n    border-style: none;\n    padding: 0;\n}\n\n/**\n * Restore the focus styles unset by the previous rule.\n */\n\nbutton:-moz-focusring,\n[type=\"button\"]:-moz-focusring,\n[type=\"reset\"]:-moz-focusring,\n[type=\"submit\"]:-moz-focusring {\n    outline: 1px dotted ButtonText;\n}\n\n/**\n * Correct the padding in Firefox.\n */\n\nfieldset {\n    padding: 0.35em 0.75em 0.625em;\n}\n\n/**\n * 1. Correct the text wrapping in Edge and IE.\n * 2. Correct the color inheritance from `fieldset` elements in IE.\n * 3. Remove the padding so developers are not caught out when they zero out\n *    `fieldset` elements in all browsers.\n */\n\nlegend {\n    box-sizing: border-box; /* 1 */\n    color: inherit; /* 2 */\n    display: table; /* 1 */\n    max-width: 100%; /* 1 */\n    padding: 0; /* 3 */\n    white-space: normal; /* 1 */\n}\n\n/**\n * Add the correct vertical alignment in Chrome, Firefox, and Opera.\n */\n\nprogress {\n    vertical-align: baseline;\n}\n\n/**\n * Remove the default vertical scrollbar in IE 10+.\n */\n\ntextarea {\n    overflow: auto;\n}\n\n/**\n * 1. Add the correct box sizing in IE 10.\n * 2. Remove the padding in IE 10.\n */\n\n[type=\"checkbox\"],\n[type=\"radio\"] {\n    box-sizing: border-box; /* 1 */\n    padding: 0; /* 2 */\n}\n\n/**\n * Correct the cursor style of increment and decrement buttons in Chrome.\n */\n\n[type=\"number\"]::-webkit-inner-spin-button,\n[type=\"number\"]::-webkit-outer-spin-button {\n    height: auto;\n}\n\n/**\n * 1. Correct the odd appearance in Chrome and Safari.\n * 2. Correct the outline style in Safari.\n */\n\n[type=\"search\"] {\n    -webkit-appearance: textfield; /* 1 */\n    outline-offset: -2px; /* 2 */\n}\n\n/**\n * Remove the inner padding in Chrome and Safari on macOS.\n */\n\n[type=\"search\"]::-webkit-search-decoration {\n    -webkit-appearance: none;\n}\n\n/**\n * 1. Correct the inability to style clickable types in iOS and Safari.\n * 2. Change font properties to `inherit` in Safari.\n */\n\n::-webkit-file-upload-button {\n    -webkit-appearance: button; /* 1 */\n    font: inherit; /* 2 */\n}\n\n/* Interactive\n========================================================================== */\n\n/*\n * Add the correct display in Edge, IE 10+, and Firefox.\n */\n\ndetails {\n    display: block;\n}\n\n/*\n * Add the correct display in all browsers.\n */\n\nsummary {\n    display: list-item;\n}\n\n/* Misc\n========================================================================== */\n\n/**\n * Add the correct display in IE 10+.\n */\n\ntemplate {\n    display: none;\n}\n\n/**\n * Add the correct display in IE 10.\n */\n\n[hidden] {\n    display: none;\n}\n", ""]);

// exports


/***/ }),

/***/ 267:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports


// module
exports.push([module.i, "html {\n    box-sizing: border-box;\n}\n\n*, *::before, *::after {\n    box-sizing: inherit;\n}\n\n@-webkit-keyframes spin {\n    0% {\n        -webkit-transform: rotate(0deg);\n                transform: rotate(0deg);\n    }\n    100% {\n        -webkit-transform: rotate(360deg);\n                transform: rotate(360deg);\n    }\n}\n\n@keyframes spin {\n    0% {\n        -webkit-transform: rotate(0deg);\n                transform: rotate(0deg);\n    }\n    100% {\n        -webkit-transform: rotate(360deg);\n                transform: rotate(360deg);\n    }\n}\n\nbody {\n    font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Helvetica Neue\", Arial, sans-serif;\n    background: #FAFAFA;\n    color: #424242;\n    width: 370px;\n    height: 600px;\n    font-size: 1rem;\n    line-height: 1.5;\n    overflow: hidden;\n}\n\n::-moz-selection {\n    background: #FFCDD2;\n}\n::selection {\n    background: #FFCDD2;\n}\n\na {\n    color: #184c82;\n    text-decoration: none;\n    cursor: pointer;\n    outline: 0;\n}\na:hover {\n    color: #184c82;\n}\n\n.icon {\n    display: inline-block;\n    stroke-width: 0;\n    stroke: currentColor;\n    fill: currentColor;\n    width: 1em;\n    height: 1em;\n}\n\n.loading {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    background: rgba(255, 255, 255, 0.8);\n    position: absolute;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    font-size: 40px;\n    color: #616161;\n}\n.loading .icon{\n    -webkit-animation: spin 2s infinite linear;\n            animation: spin 2s infinite linear;\n}\n\n#app {\n    height: 600px;\n    overflow: auto;\n}\n\n.main {\n    padding: 6rem 1rem 1rem;\n}\n\n.auth {\n    clear: both;\n    padding: 1.5rem;\n    text-align: center;\n}\n.auth-logo {\n    margin-top: 1rem;\n}\n.auth-title {\n    font-size: 2rem;\n    margin: 1rem 0;\n    color: #424242;\n}\n.auth-link {\n    font-size: 0.875rem;\n}\n.auth-link:hover,\n.auth-link:focus {\n    text-decoration: underline;\n}\n\n.input-field {\n    display: block;\n    width: 100%;\n    margin: 0.75rem 0;\n    padding: 0.75rem;\n    border-radius: 3px;\n    box-shadow: inset 0 0 3px #EEEEEE;\n    border: 1px solid #D9D9D9;\n    background: #FFFFFF;\n    color: #424242;\n    font-size: 0.75rem;\n    outline: 0;\n    -webkit-appearance: none;\n}\nselect.input-field {\n    height: 39px;\n    background-image: url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' version='1.1' width='32' height='24' viewBox='0 0 32 24'><polygon points='0,0 32,0 16,24' style='fill: rgb%2896, 125, 139%29'></polygon></svg>\");\n    background-origin: content-box;\n    background-position: right 0 center;\n    background-repeat: no-repeat;\n    background-size: 9px 6px;\n    cursor: pointer;\n}\n.input-field.special {\n    padding: 0.5rem;\n    font-size: 0.875rem;\n    line-height: 1.5;\n}\ninput.input-field:read-only,\ntextarea.input-field:read-only,\n.input-field:disabled {\n    background: #EEEEEE;\n}\n.input-field:focus {\n    border-color: #BDBDBD;\n}\n.input-field::placeholder {\n    color: #9E9E9E;\n}\n\n.input-label {\n    display: block;\n    font-size: 0.75rem;\n    margin: 0.75rem 0 1rem;\n    color: #757575;\n    cursor: pointer;\n}\n.input-label .input-field {\n    margin: 0.25rem 0 0;\n}\n\n.button, a.button {\n    display: block;\n    margin: 0.75rem 0;\n    padding: 0.875rem;\n    width: 100%;\n    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15);\n    border: none;\n    border-radius: 5px;\n    background: #FFFFFF;\n    color: #757575;\n    font-size: 0.875rem;\n    line-height: 1;\n    text-align: center;\n    cursor: pointer;\n    outline: 0;\n}\n.button:disabled {\n    opacity: 0.5;\n}\n.button:hover,\n.button:focus {\n    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);\n}\n.button:active {\n    transform: translateY(1px);\n}\n\n.button.brand {\n    background: #184c82;\n    color: #FAFAFA;\n    font-weight: 600;\n}\n.button.brand:hover,\n.button.brand:focus {\n    background: #184c82;\n}\n\n.input-group {\n    display: flex;\n    margin: 0.75rem 0;\n}\n.input-group .input-field {\n    flex: 1;\n    border-right: none;\n    border-top-right-radius: 0;\n    border-bottom-right-radius: 0;\n    margin: 0;\n}\n.input-group .button {\n    width: auto;\n    border-top-left-radius: 0;\n    border-bottom-left-radius: 0;\n    border: 1px solid #D9D9D9;\n    box-shadow: none;\n    font-size: 1rem;\n    margin: 0;\n    padding: 0.5rem 0.75rem;\n}\n.input-group .button:hover,\n.input-group .button:focus {\n    background: #FAFAFA;\n}\n.input-group .button:active {\n    transform: none;\n    background: #F5F5F5;\n}\n\n.form-info {\n    color: #616161;\n    font-size: 0.75rem;\n    text-align: left;\n    margin: 0.75rem 0 1rem;\n}\n.form-info.center {\n    text-align: center;\n}\n\n.message {\n    text-align: left;\n    background: #E0E0E0;\n    border-left: 5px solid #BDBDBD;\n    color: #757575;\n    padding: 0.5rem;\n    font-size: 0.75rem;\n}\n.message.error {\n    background: #FFCDD2;\n    border-left-color: #E57373;\n    color: #E53935;\n}\n.message.success {\n    background: #DCEDC8;\n    border-left-color: #AED581;\n    color: #7CB342;\n}\n\n.line-through {\n    position: relative;\n    margin: 20px 0;\n    color: #9E9E9E;\n    font-size: 0.75rem;\n    line-height: 1;\n}\n.line-through::before {\n    content: \"\";\n    display: block;\n    width: 100%;\n    border-top: 1px solid #CCCCCC;\n    position: absolute;\n    top: 50%;\n    z-index: 1;\n}\n.line-through span {\n    position: relative;\n    background: #FAFAFA;\n    padding: 3px 10px;\n    z-index: 10;\n}\n\n.box {\n    box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);\n    background: #FFFFFF;\n    border-radius: 5px;\n    padding: 1rem;\n    margin-bottom: 1.5rem;\n    overflow: hidden;\n    font-size: 0.875rem;\n    text-align: center;\n}\n.box.highlight {\n    box-shadow: 0 5px 25px rgba(0, 0, 0, 0.1);\n}\n.box.no-padding {\n    padding: 0;\n}\n\n.box-label {\n    font-size: 0.625rem;\n    text-transform: uppercase;\n    color: #BDBDBD;\n    padding: 0 0 1rem;\n}\n\n.box-balance {\n    font-size: 2rem;\n    font-weight: 600;\n    word-wrap: break-word;\n}\n.box-balance-code {\n    color: #9E9E9E;\n    font-size: 1rem;\n    text-transform: uppercase;\n    padding: 0 0 1rem;\n}\n\n.box-text {\n    font-size: 0.75rem;\n    color: #9E9E9E;\n}\n.box-expires {\n    font-weight: 600;\n}\n\n.box-buttons {\n    display: flex;\n    margin: 1rem -1rem -1rem;\n    border-top: 1px solid #EEEEEE;\n}\n.box-buttons a {\n    display: block;\n    flex: 1;\n    margin: 0;\n    padding: 1rem;\n    font-size: 0.75rem;\n    text-align: center;\n    text-transform: uppercase;\n}\n.box-buttons a {\n    border-right: 1px solid #EEEEEE;\n    color: #757575;\n}\n.box-buttons a.red {\n    color: #F44336;\n}\n.box-buttons a.green {\n    color: #8BC34A;\n}\n.box-buttons a.blue {\n    color: #03A9F4;\n}\n.box-buttons a:last-child {\n    border-right: none;\n}\n.box-buttons a:hover,\n.box-buttons a:focus {\n    background: #FAFAFA;\n}\n.box-buttons a:active {\n    box-shadow: inset 0 1px 3px rgba(238, 238, 238, 0.5);\n}\n.box-buttons a:active span {\n    display: block;\n    transform: translateY(1px);\n}\n\n.box-row {\n    display: flex;\n    border-bottom: 1px solid #EEEEEE;\n}\n.box-row:last-child {\n    border-bottom: none;\n}\n.box-column {\n    border-right: 1px solid #EEEEEE;\n    padding: 1rem;\n    flex: 1;\n    width: 50%;\n}\n.box-row:last-child {\n    border-right: none;\n}\n.box-column .box-balance {\n    font-size: 1.125rem;\n}\n.box-column .box-balance-code {\n    font-size: 0.625rem;\n    color: #BDBDBD;\n    margin-top: 5px;\n    padding: 0;\n}\n\n.box-address-label {\n    font-size: 0.625rem;\n    text-transform: uppercase;\n    color: #9E9E9E;\n    margin: 0.5rem 0 0.25rem;\n}\n.box-address {\n    width: 100%;\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    font-size: 0.75rem;\n    font-weight: 600;\n    margin-bottom: 1.5rem;\n}\n\n.message-empty {\n    padding: 0.75rem;\n    font-size: 0.875rem;\n    text-align: center;\n    color: #BDBDBD;\n}\n\n.load-more {\n    display: block;\n    padding: 1rem;\n    font-size: 0.75rem;\n    text-align: center;\n    text-transform: uppercase;\n}\n", ""]);

// exports


/***/ }),

/***/ 269:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "app" } },
    [
      _c(
        "div",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.loading,
              expression: "loading"
            }
          ],
          staticClass: "loading"
        },
        [
          _c(
            "svg",
            {
              staticClass: "icon",
              attrs: {
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 512 512"
              }
            },
            [
              _c("path", {
                attrs: {
                  d:
                    "M304 48c0 26.51-21.49 48-48 48s-48-21.49-48-48 21.49-48 48-48 48 21.49 48 48zm-48 368c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48zm208-208c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48zM96 256c0-26.51-21.49-48-48-48S0 229.49 0 256s21.49 48 48 48 48-21.49 48-48zm12.922 99.078c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48c0-26.509-21.491-48-48-48zm294.156 0c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48c0-26.509-21.49-48-48-48zM108.922 60.922c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.491-48-48-48z"
                }
              })
            ]
          )
        ]
      ),
      _vm._v(" "),
      _c("router-view")
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-3a0a60d6", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 273:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    namespaced: true,

    state: {
        address: false,
        keypass: false,
        keystore: false
    },

    mutations: {
        address: function address(state, _address) {
            state.address = _address;
        },
        keypass: function keypass(state, _keypass) {
            state.keypass = _keypass;
        },
        keystore: function keystore(state, _keystore) {
            state.keystore = _keystore;
        }
    }
};

/***/ }),

/***/ 274:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _toConsumableArray2 = __webpack_require__(275);

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    namespaced: true,

    state: {
        balance: 0,
        bandwidth: 0,
        tokens: [],
        transfers: [],
        transactions: []
    },

    mutations: {
        change: function change(state, account) {
            state.balance = account.balance;
            state.bandwidth = account.bandwidth;
        },
        tokens: function tokens(state, _tokens) {
            state.tokens = _tokens;
        },
        transfers: function transfers(state, _transfers) {
            state.transfers = _transfers;
        },
        pushTransfers: function pushTransfers(state, transfers) {
            var _state$transfers;

            (_state$transfers = state.transfers).push.apply(_state$transfers, (0, _toConsumableArray3.default)(transfers));
        },
        transactions: function transactions(state, _transactions) {
            state.transactions = _transactions;
        },
        pushTransactions: function pushTransactions(state, transactions) {
            var _state$transactions;

            (_state$transactions = state.transactions).push.apply(_state$transactions, (0, _toConsumableArray3.default)(transactions));
        }
    }
};

/***/ }),

/***/ 29:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_AppHeader_vue__ = __webpack_require__(251);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_AppHeader_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_AppHeader_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_AppHeader_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_AppHeader_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_25dae451_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_AppHeader_vue__ = __webpack_require__(625);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
function injectStyle (context) {
  if (disposed) return
  __webpack_require__(623)
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_AppHeader_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_25dae451_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_AppHeader_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_25dae451_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_AppHeader_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/components/AppHeader.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-25dae451", Component.options)
  } else {
    hotAPI.reload("data-v-25dae451", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 291:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    "1000001": "BNB;BNB;0"
};

/***/ }),

/***/ 292:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vue = __webpack_require__(81);

var _vue2 = _interopRequireDefault(_vue);

var _vueRouter = __webpack_require__(293);

var _vueRouter2 = _interopRequireDefault(_vueRouter);

var _SignIn = __webpack_require__(294);

var _SignIn2 = _interopRequireDefault(_SignIn);

var _CreateWallet = __webpack_require__(571);

var _CreateWallet2 = _interopRequireDefault(_CreateWallet);

var _ImportWallet = __webpack_require__(580);

var _ImportWallet2 = _interopRequireDefault(_ImportWallet);

var _Account = __webpack_require__(582);

var _Account2 = _interopRequireDefault(_Account);

var _Tokens = __webpack_require__(627);

var _Tokens2 = _interopRequireDefault(_Tokens);

var _Transfers = __webpack_require__(631);

var _Transfers2 = _interopRequireDefault(_Transfers);

var _Transactions = __webpack_require__(636);

var _Transactions2 = _interopRequireDefault(_Transactions);

var _Send = __webpack_require__(641);

var _Send2 = _interopRequireDefault(_Send);

var _Receive = __webpack_require__(647);

var _Receive2 = _interopRequireDefault(_Receive);

var _PrivateKey = __webpack_require__(652);

var _PrivateKey2 = _interopRequireDefault(_PrivateKey);

var _About = __webpack_require__(654);

var _About2 = _interopRequireDefault(_About);

var _store = __webpack_require__(82);

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_vue2.default.use(_vueRouter2.default);

var router = new _vueRouter2.default({
    routes: [{
        path: '/',
        name: 'account',
        component: _Account2.default,
        meta: {
            requiresAuth: true
        }
    }, {
        path: '/tokens',
        name: 'tokens',
        component: _Tokens2.default,
        meta: {
            requiresAuth: true
        }
    }, {
        path: '/transfers',
        name: 'transfers',
        component: _Transfers2.default,
        meta: {
            requiresAuth: true
        }
    }, {
        path: '/transactions',
        name: 'transactions',
        component: _Transactions2.default,
        meta: {
            requiresAuth: true
        }
    }, {
        path: '/send',
        name: 'send',
        component: _Send2.default,
        meta: {
            requiresAuth: true
        }
    }, {
        path: '/receive',
        name: 'receive',
        component: _Receive2.default,
        meta: {
            requiresAuth: true
        }
    }, {
        path: '/private-key',
        name: 'private-key',
        component: _PrivateKey2.default,
        meta: {
            requiresAuth: true
        }
    }, {
        path: '/about',
        name: 'about',
        component: _About2.default,
        meta: {
            requiresAuth: true
        }
    }, {
        path: '/signin',
        name: 'signin',
        component: _SignIn2.default,
        meta: {
            requiresKeystore: true
        }
    }, {
        path: '/create-wallet',
        name: 'create-wallet',
        component: _CreateWallet2.default
    }, {
        path: '/import-wallet',
        name: 'import-wallet',
        component: _ImportWallet2.default
    }]
});

router.beforeEach(function (to, from, next) {
    if (to.matched.some(function (record) {
        return record.meta.requiresAuth;
    })) {
        if (!_store2.default.state.wallet.address) {
            next({ path: '/signin' });
        } else {
            next();
        }
    } else if (to.matched.some(function (record) {
        return record.meta.requiresKeystore;
    })) {
        if (!_store2.default.state.wallet.keystore) {
            next({ path: '/create-wallet' });
        } else {
            next();
        }
    } else {
        next();
    }
});

exports.default = router;

/***/ }),

/***/ 294:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_SignIn_vue__ = __webpack_require__(149);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_SignIn_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_SignIn_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_SignIn_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_SignIn_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_8d6adeae_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_SignIn_vue__ = __webpack_require__(570);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_SignIn_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_8d6adeae_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_SignIn_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_8d6adeae_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_SignIn_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/SignIn.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-8d6adeae", Component.options)
  } else {
    hotAPI.reload("data-v-8d6adeae", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 300:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 302:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 312:
/***/ (function(module, exports) {

module.exports = {"_from":"web3@1.3.1","_id":"web3@1.3.1","_inBundle":false,"_integrity":"sha512-lDJwOLSRWHYwhPy4h5TNgBRJ/lED7lWXyVOXHCHcEC8ai3coBNdgEXWBu/GGYbZMsS89EoUOJ14j3Ufi4dUkog==","_location":"/web3","_phantomChildren":{},"_requested":{"type":"version","registry":true,"raw":"web3@1.3.1","name":"web3","escapedName":"web3","rawSpec":"1.3.1","saveSpec":null,"fetchSpec":"1.3.1"},"_requiredBy":["/"],"_resolved":"https://registry.npmjs.org/web3/-/web3-1.3.1.tgz","_shasum":"f780138c92ae3c42ea45e1a3c6ae8844e0aa5054","_spec":"web3@1.3.1","_where":"/Users/kamal/Workspace/Nodejs/tronmask","author":{"name":"ethereum.org"},"authors":[{"name":"Fabian Vogelsteller","email":"fabian@ethereum.org","homepage":"http://frozeman.de"},{"name":"Marek Kotewicz","email":"marek@parity.io","url":"https://github.com/debris"},{"name":"Marian Oancea","url":"https://github.com/cubedro"},{"name":"Gav Wood","email":"g@parity.io","homepage":"http://gavwood.com"},{"name":"Jeffery Wilcke","email":"jeffrey.wilcke@ethereum.org","url":"https://github.com/obscuren"}],"bugs":{"url":"https://github.com/ethereum/web3.js/issues"},"bundleDependencies":false,"dependencies":{"web3-bzz":"1.3.1","web3-core":"1.3.1","web3-eth":"1.3.1","web3-eth-personal":"1.3.1","web3-net":"1.3.1","web3-shh":"1.3.1","web3-utils":"1.3.1"},"deprecated":false,"description":"Ethereum JavaScript API","devDependencies":{"@types/node":"^12.12.6","dtslint":"^3.4.1","typescript":"^3.9.5"},"engines":{"node":">=8.0.0"},"gitHead":"1a850aec1d8fa86bfacef1f3ffe71839b87e78e7","homepage":"https://github.com/ethereum/web3.js#readme","keywords":["Ethereum","JavaScript","API"],"license":"LGPL-3.0","main":"lib/index.js","name":"web3","repository":{"type":"git","url":"git+https://github.com/ethereum/web3.js.git"},"scripts":{"dtslint":"dtslint --localTs ../../node_modules/typescript/lib types","tsc":"tsc -b tsconfig.json"},"types":"types/index.d.ts","version":"1.3.1"}

/***/ }),

/***/ 321:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 340:
/***/ (function(module, exports) {

module.exports = {"_from":"websocket@^1.0.32","_id":"websocket@1.0.33","_inBundle":false,"_integrity":"sha512-XwNqM2rN5eh3G2CUQE3OHZj+0xfdH42+OFK6LdC2yqiC0YU8e5UK0nYre220T0IyyN031V/XOvtHvXozvJYFWA==","_location":"/websocket","_phantomChildren":{},"_requested":{"type":"range","registry":true,"raw":"websocket@^1.0.32","name":"websocket","escapedName":"websocket","rawSpec":"^1.0.32","saveSpec":null,"fetchSpec":"^1.0.32"},"_requiredBy":["/web3-providers-ws"],"_resolved":"https://registry.npmjs.org/websocket/-/websocket-1.0.33.tgz","_shasum":"407f763fc58e74a3fa41ca3ae5d78d3f5e3b82a5","_spec":"websocket@^1.0.32","_where":"/Users/kamal/Workspace/Nodejs/tronmask/node_modules/web3-providers-ws","author":{"name":"Brian McKelvey","email":"theturtle32@gmail.com","url":"https://github.com/theturtle32"},"browser":"lib/browser.js","bugs":{"url":"https://github.com/theturtle32/WebSocket-Node/issues"},"bundleDependencies":false,"config":{"verbose":false},"contributors":[{"name":"Iñaki Baz Castillo","email":"ibc@aliax.net","url":"http://dev.sipdoc.net"}],"dependencies":{"bufferutil":"^4.0.1","debug":"^2.2.0","es5-ext":"^0.10.50","typedarray-to-buffer":"^3.1.5","utf-8-validate":"^5.0.2","yaeti":"^0.0.6"},"deprecated":false,"description":"Websocket Client & Server Library implementing the WebSocket protocol as specified in RFC 6455.","devDependencies":{"buffer-equal":"^1.0.0","gulp":"^4.0.2","gulp-jshint":"^2.0.4","jshint":"^2.0.0","jshint-stylish":"^2.2.1","tape":"^4.9.1"},"directories":{"lib":"./lib"},"engines":{"node":">=4.0.0"},"homepage":"https://github.com/theturtle32/WebSocket-Node","keywords":["websocket","websockets","socket","networking","comet","push","RFC-6455","realtime","server","client"],"license":"Apache-2.0","main":"index","name":"websocket","repository":{"type":"git","url":"git+https://github.com/theturtle32/WebSocket-Node.git"},"scripts":{"gulp":"gulp","test":"tape test/unit/*.js"},"version":"1.0.33"}

/***/ }),

/***/ 345:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 347:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 43:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _stringify = __webpack_require__(295);

var _stringify2 = _interopRequireDefault(_stringify);

exports.encryptKey = encryptKey;
exports.encryptString = encryptString;
exports.decryptString = decryptString;
exports.validatePrivateKey = validatePrivateKey;
exports.encryptKeyStore = encryptKeyStore;
exports.decryptKeyStore = decryptKeyStore;

var _pbkdf = __webpack_require__(96);

var _pbkdf2 = _interopRequireDefault(_pbkdf);

var _aesJs = __webpack_require__(311);

var _aesJs2 = _interopRequireDefault(_aesJs);

var _web = __webpack_require__(34);

var _web2 = _interopRequireDefault(_web);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var uuidv4 = __webpack_require__(567);

// Convert a hex string to a byte array
function hexToBytes(hex) {
    for (var bytes = [], c = 0; c < hex.length; c += 2) {
        bytes.push(parseInt(hex.substr(c, 2), 16));
    }return bytes;
}

// Convert a byte array to a hex string
function bytesToHex(bytes) {
    for (var hex = [], i = 0; i < bytes.length; i++) {
        var current = bytes[i] < 0 ? bytes[i] + 256 : bytes[i];
        hex.push((current >>> 4).toString(16));
        hex.push((current & 0xF).toString(16));
    }
    return hex.join("");
}

/**
 * Converts a byte array to string
 *
 * @param {Uint8Array} arr byte array
 * @returns {string}
 */
function bytesToString(arr) {
    if (typeof arr === 'string') {
        return arr;
    }
    var str = '',
        _arr = arr;
    for (var i = 0; i < _arr.length; i++) {
        var one = _arr[i].toString(2),
            v = one.match(/^1+?(?=0)/);
        if (v && one.length === 8) {
            var bytesLength = v[0].length;
            var store = _arr[i].toString(2).slice(7 - bytesLength);
            for (var st = 1; st < bytesLength; st++) {
                store += _arr[st + i].toString(2).slice(2);
            }
            str += String.fromCharCode(parseInt(store, 2));
            i += bytesLength - 1;
        } else {
            str += String.fromCharCode(_arr[i]);
        }
    }
    return str;
}

function stringToBytes(str) {
    var bytes = new Array();
    var len, c;
    len = str.length;
    for (var i = 0; i < len; i++) {
        c = str.charCodeAt(i);
        if (c >= 0x010000 && c <= 0x10FFFF) {
            bytes.push(c >> 18 & 0x07 | 0xF0);
            bytes.push(c >> 12 & 0x3F | 0x80);
            bytes.push(c >> 6 & 0x3F | 0x80);
            bytes.push(c & 0x3F | 0x80);
        } else if (c >= 0x000800 && c <= 0x00FFFF) {
            bytes.push(c >> 12 & 0x0F | 0xE0);
            bytes.push(c >> 6 & 0x3F | 0x80);
            bytes.push(c & 0x3F | 0x80);
        } else if (c >= 0x000080 && c <= 0x0007FF) {
            bytes.push(c >> 6 & 0x1F | 0xC0);
            bytes.push(c & 0x3F | 0x80);
        } else {
            bytes.push(c & 0xFF);
        }
    }
    return bytes;
}

function encryptKey(password, salt) {
    return _pbkdf2.default.pbkdf2Sync(password, salt, 1, 256 / 8, 'sha512');
}

function encryptString(password, hexString) {
    var textBytes = _aesJs2.default.utils.utf8.toBytes(hexString);
    var aesCtr = new _aesJs2.default.ModeOfOperation.ctr(password);
    var encrypted = aesCtr.encrypt(textBytes);

    return {
        bytes: encrypted,
        hex: _aesJs2.default.utils.hex.fromBytes(encrypted)
    };
}

function decryptString(password, salt, hexString) {
    var key = encryptKey(password, salt);
    var encryptedBytes = _aesJs2.default.utils.hex.toBytes(hexString);
    var aesCtr = new _aesJs2.default.ModeOfOperation.ctr(key);
    var decryptedBytes = aesCtr.decrypt(encryptedBytes);

    return _aesJs2.default.utils.utf8.fromBytes(decryptedBytes);
}

function validatePrivateKey(privateKey) {
    try {
        //const address = pkToAddress(privateKey)
        return _web2.default.utils.isAddress(address);
    } catch (e) {
        return false;
    }
}

function encryptKeyStore(password, privateKey, address) {
    var salt = uuidv4();
    var encryptedKey = encryptKey(password, salt);

    var _encryptString = encryptString(encryptedKey, privateKey),
        hex = _encryptString.hex;

    var data = {
        version: 1,
        key: hex,
        address: address,
        salt: salt
    };

    return bytesToHex(stringToBytes((0, _stringify2.default)(data)));
}

function decryptKeyStore(password, keystore) {
    if (!password) {
        return false;
    }

    var _JSON$parse = JSON.parse(bytesToString(hexToBytes(keystore))),
        key = _JSON$parse.key,
        address = _JSON$parse.address,
        salt = _JSON$parse.salt;

    var privateKey = decryptString(password, salt, key);

    return {
        address: address,
        privateKey: privateKey
    };
}

/***/ }),

/***/ 443:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 445:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 469:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 470:
/***/ (function(module, exports) {

module.exports = {"modp1":{"gen":"02","prime":"ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a63a3620ffffffffffffffff"},"modp2":{"gen":"02","prime":"ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece65381ffffffffffffffff"},"modp5":{"gen":"02","prime":"ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca237327ffffffffffffffff"},"modp14":{"gen":"02","prime":"ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aacaa68ffffffffffffffff"},"modp15":{"gen":"02","prime":"ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a93ad2caffffffffffffffff"},"modp16":{"gen":"02","prime":"ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c934063199ffffffffffffffff"},"modp17":{"gen":"02","prime":"ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c93402849236c3fab4d27c7026c1d4dcb2602646dec9751e763dba37bdf8ff9406ad9e530ee5db382f413001aeb06a53ed9027d831179727b0865a8918da3edbebcf9b14ed44ce6cbaced4bb1bdb7f1447e6cc254b332051512bd7af426fb8f401378cd2bf5983ca01c64b92ecf032ea15d1721d03f482d7ce6e74fef6d55e702f46980c82b5a84031900b1c9e59e7c97fbec7e8f323a97a7e36cc88be0f1d45b7ff585ac54bd407b22b4154aacc8f6d7ebf48e1d814cc5ed20f8037e0a79715eef29be32806a1d58bb7c5da76f550aa3d8a1fbff0eb19ccb1a313d55cda56c9ec2ef29632387fe8d76e3c0468043e8f663f4860ee12bf2d5b0b7474d6e694f91e6dcc4024ffffffffffffffff"},"modp18":{"gen":"02","prime":"ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c93402849236c3fab4d27c7026c1d4dcb2602646dec9751e763dba37bdf8ff9406ad9e530ee5db382f413001aeb06a53ed9027d831179727b0865a8918da3edbebcf9b14ed44ce6cbaced4bb1bdb7f1447e6cc254b332051512bd7af426fb8f401378cd2bf5983ca01c64b92ecf032ea15d1721d03f482d7ce6e74fef6d55e702f46980c82b5a84031900b1c9e59e7c97fbec7e8f323a97a7e36cc88be0f1d45b7ff585ac54bd407b22b4154aacc8f6d7ebf48e1d814cc5ed20f8037e0a79715eef29be32806a1d58bb7c5da76f550aa3d8a1fbff0eb19ccb1a313d55cda56c9ec2ef29632387fe8d76e3c0468043e8f663f4860ee12bf2d5b0b7474d6e694f91e6dbe115974a3926f12fee5e438777cb6a932df8cd8bec4d073b931ba3bc832b68d9dd300741fa7bf8afc47ed2576f6936ba424663aab639c5ae4f5683423b4742bf1c978238f16cbe39d652de3fdb8befc848ad922222e04a4037c0713eb57a81a23f0c73473fc646cea306b4bcbc8862f8385ddfa9d4b7fa2c087e879683303ed5bdd3a062b3cf5b3a278a66d2a13f83f44f82ddf310ee074ab6a364597e899a0255dc164f31cc50846851df9ab48195ded7ea1b1d510bd7ee74d73faf36bc31ecfa268359046f4eb879f924009438b481c6cd7889a002ed5ee382bc9190da6fc026e479558e4475677e9aa9e3050e2765694dfc81f56e880b96e7160c980dd98edd3dfffffffffffffffff"}}

/***/ }),

/***/ 475:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 476:
/***/ (function(module, exports) {

module.exports = {"_args":[["elliptic@6.5.3","/Users/kamal/Workspace/Nodejs/tronmask"]],"_development":true,"_from":"elliptic@6.5.3","_id":"elliptic@6.5.3","_inBundle":false,"_integrity":"sha512-IMqzv5wNQf+E6aHeIqATs0tOLeOTwj1QKbRcS3jBbYkl5oLAserA8yJTT7/VyHUYG91PRmPyeQDObKLPpeS4dw==","_location":"/elliptic","_phantomChildren":{},"_requested":{"type":"version","registry":true,"raw":"elliptic@6.5.3","name":"elliptic","escapedName":"elliptic","rawSpec":"6.5.3","saveSpec":null,"fetchSpec":"6.5.3"},"_requiredBy":["/@ethersproject/signing-key","/browserify-sign","/create-ecdh","/eth-lib","/ethereumjs-util","/secp256k1","/web3-eth-accounts/eth-lib","/web3-utils/eth-lib"],"_resolved":"https://registry.npmjs.org/elliptic/-/elliptic-6.5.3.tgz","_spec":"6.5.3","_where":"/Users/kamal/Workspace/Nodejs/tronmask","author":{"name":"Fedor Indutny","email":"fedor@indutny.com"},"bugs":{"url":"https://github.com/indutny/elliptic/issues"},"dependencies":{"bn.js":"^4.4.0","brorand":"^1.0.1","hash.js":"^1.0.0","hmac-drbg":"^1.0.0","inherits":"^2.0.1","minimalistic-assert":"^1.0.0","minimalistic-crypto-utils":"^1.0.0"},"description":"EC cryptography","devDependencies":{"brfs":"^1.4.3","coveralls":"^3.0.8","grunt":"^1.0.4","grunt-browserify":"^5.0.0","grunt-cli":"^1.2.0","grunt-contrib-connect":"^1.0.0","grunt-contrib-copy":"^1.0.0","grunt-contrib-uglify":"^1.0.1","grunt-mocha-istanbul":"^3.0.1","grunt-saucelabs":"^9.0.1","istanbul":"^0.4.2","jscs":"^3.0.7","jshint":"^2.10.3","mocha":"^6.2.2"},"files":["lib"],"homepage":"https://github.com/indutny/elliptic","keywords":["EC","Elliptic","curve","Cryptography"],"license":"MIT","main":"lib/elliptic.js","name":"elliptic","repository":{"type":"git","url":"git+ssh://git@github.com/indutny/elliptic.git"},"scripts":{"jscs":"jscs benchmarks/*.js lib/*.js lib/**/*.js lib/**/**/*.js test/index.js","jshint":"jscs benchmarks/*.js lib/*.js lib/**/*.js lib/**/**/*.js test/index.js","lint":"npm run jscs && npm run jshint","test":"npm run lint && npm run unit","unit":"istanbul test _mocha --reporter=spec test/index.js","version":"grunt dist && git add dist/"},"version":"6.5.3"}

/***/ }),

/***/ 488:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 496:
/***/ (function(module, exports) {

module.exports = {"2.16.840.1.101.3.4.1.1":"aes-128-ecb","2.16.840.1.101.3.4.1.2":"aes-128-cbc","2.16.840.1.101.3.4.1.3":"aes-128-ofb","2.16.840.1.101.3.4.1.4":"aes-128-cfb","2.16.840.1.101.3.4.1.21":"aes-192-ecb","2.16.840.1.101.3.4.1.22":"aes-192-cbc","2.16.840.1.101.3.4.1.23":"aes-192-ofb","2.16.840.1.101.3.4.1.24":"aes-192-cfb","2.16.840.1.101.3.4.1.41":"aes-256-ecb","2.16.840.1.101.3.4.1.42":"aes-256-cbc","2.16.840.1.101.3.4.1.43":"aes-256-ofb","2.16.840.1.101.3.4.1.44":"aes-256-cfb"}

/***/ }),

/***/ 529:
/***/ (function(module, exports) {

module.exports = {"name":"mainnet","chainId":1,"networkId":1,"comment":"The Ethereum main chain","url":"https://ethstats.net/","genesis":{"hash":"0xd4e56740f876aef8c010b86a40d5f56745a118d0906a34e69aec8c0db1cb8fa3","timestamp":null,"gasLimit":5000,"difficulty":17179869184,"nonce":"0x0000000000000042","extraData":"0x11bbe8db4e347b4e8c937c1c8370e4b5ed33adb3db69cbdb7a38e1e50b1b82fa","stateRoot":"0xd7f8974fb5ac78d9ac099b9ad5018bedc2ce0a72dad1827a1709da30580f0544"},"hardforks":[{"name":"chainstart","block":0,"consensus":"pow","finality":null},{"name":"homestead","block":1150000,"consensus":"pow","finality":null},{"name":"dao","block":1920000,"consensus":"pow","finality":null},{"name":"tangerineWhistle","block":2463000,"consensus":"pow","finality":null},{"name":"spuriousDragon","block":2675000,"consensus":"pow","finality":null},{"name":"byzantium","block":4370000,"consensus":"pow","finality":null},{"name":"constantinople","block":7280000,"consensus":"pow","finality":null},{"name":"petersburg","block":7280000,"consensus":"pow","finality":null},{"name":"istanbul","block":9069000,"consensus":"pow","finality":null},{"name":"muirGlacier","block":9200000,"consensus":"pow","finality":null}],"bootstrapNodes":[{"ip":"18.138.108.67","port":30303,"id":"d860a01f9722d78051619d1e2351aba3f43f943f6f00718d1b9baa4101932a1f5011f16bb2b1bb35db20d6fe28fa0bf09636d26a87d31de9ec6203eeedb1f666","location":"ap-southeast-1-001","comment":"bootnode-aws-ap-southeast-1-001"},{"ip":"3.209.45.79","port":30303,"id":"22a8232c3abc76a16ae9d6c3b164f98775fe226f0917b0ca871128a74a8e9630b458460865bab457221f1d448dd9791d24c4e5d88786180ac185df813a68d4de","location":"us-east-1-001","comment":"bootnode-aws-us-east-1-001"},{"ip":"34.255.23.113","port":30303,"id":"ca6de62fce278f96aea6ec5a2daadb877e51651247cb96ee310a318def462913b653963c155a0ef6c7d50048bba6e6cea881130857413d9f50a621546b590758","location":"eu-west-1-001","comment":"bootnode-aws-eu-west-1-001"},{"ip":"35.158.244.151","port":30303,"id":"279944d8dcd428dffaa7436f25ca0ca43ae19e7bcf94a8fb7d1641651f92d121e972ac2e8f381414b80cc8e5555811c2ec6e1a99bb009b3f53c4c69923e11bd8","location":"eu-central-1-001","comment":"bootnode-aws-eu-central-1-001"},{"ip":"52.187.207.27","port":30303,"id":"8499da03c47d637b20eee24eec3c356c9a2e6148d6fe25ca195c7949ab8ec2c03e3556126b0d7ed644675e78c4318b08691b7b57de10e5f0d40d05b09238fa0a","location":"australiaeast-001","comment":"bootnode-azure-australiaeast-001"},{"ip":"191.234.162.198","port":30303,"id":"103858bdb88756c71f15e9b5e09b56dc1be52f0a5021d46301dbbfb7e130029cc9d0d6f73f693bc29b665770fff7da4d34f3c6379fe12721b5d7a0bcb5ca1fc1","location":"brazilsouth-001","comment":"bootnode-azure-brazilsouth-001"},{"ip":"52.231.165.108","port":30303,"id":"715171f50508aba88aecd1250af392a45a330af91d7b90701c436b618c86aaa1589c9184561907bebbb56439b8f8787bc01f49a7c77276c58c1b09822d75e8e8","location":"koreasouth-001","comment":"bootnode-azure-koreasouth-001"},{"ip":"104.42.217.25","port":30303,"id":"5d6d7cd20d6da4bb83a1d28cadb5d409b64edf314c0335df658c1a54e32c7c4a7ab7823d57c39b6a757556e68ff1df17c748b698544a55cb488b52479a92b60f","location":"westus-001","comment":"bootnode-azure-westus-001"}]}

/***/ }),

/***/ 530:
/***/ (function(module, exports) {

module.exports = {"name":"ropsten","chainId":3,"networkId":3,"comment":"PoW test network","url":"https://github.com/ethereum/ropsten","genesis":{"hash":"0x41941023680923e0fe4d74a34bdac8141f2540e3ae90623718e47d66d1ca4a2d","timestamp":null,"gasLimit":16777216,"difficulty":1048576,"nonce":"0x0000000000000042","extraData":"0x3535353535353535353535353535353535353535353535353535353535353535","stateRoot":"0x217b0bbcfb72e2d57e28f33cb361b9983513177755dc3f33ce3e7022ed62b77b"},"hardforks":[{"name":"chainstart","block":0,"consensus":"pow","finality":null},{"name":"homestead","block":0,"consensus":"pow","finality":null},{"name":"dao","block":null,"consensus":"pow","finality":null},{"name":"tangerineWhistle","block":0,"consensus":"pow","finality":null},{"name":"spuriousDragon","block":10,"consensus":"pow","finality":null},{"name":"byzantium","block":1700000,"consensus":"pow","finality":null},{"name":"constantinople","block":4230000,"consensus":"pow","finality":null},{"name":"petersburg","block":4939394,"consensus":"pow","finality":null},{"name":"istanbul","block":6485846,"consensus":"pow","finality":null},{"name":"muirGlacier","block":7117117,"consensus":"pow","finality":null}],"bootstrapNodes":[{"ip":"52.176.7.10","port":30303,"id":"30b7ab30a01c124a6cceca36863ece12c4f5fa68e3ba9b0b51407ccc002eeed3b3102d20a88f1c1d3c3154e2449317b8ef95090e77b312d5cc39354f86d5d606","location":"","comment":"US-Azure geth"},{"ip":"52.176.100.77","port":30303,"id":"865a63255b3bb68023b6bffd5095118fcc13e79dcf014fe4e47e065c350c7cc72af2e53eff895f11ba1bbb6a2b33271c1116ee870f266618eadfc2e78aa7349c","location":"","comment":"US-Azure parity"},{"ip":"52.232.243.152","port":30303,"id":"6332792c4a00e3e4ee0926ed89e0d27ef985424d97b6a45bf0f23e51f0dcb5e66b875777506458aea7af6f9e4ffb69f43f3778ee73c81ed9d34c51c4b16b0b0f","location":"","comment":"Parity"},{"ip":"192.81.208.223","port":30303,"id":"94c15d1b9e2fe7ce56e458b9a3b672ef11894ddedd0c6f247e0f1d3487f52b66208fb4aeb8179fce6e3a749ea93ed147c37976d67af557508d199d9594c35f09","location":"","comment":"@gpip"}]}

/***/ }),

/***/ 531:
/***/ (function(module, exports) {

module.exports = {"name":"rinkeby","chainId":4,"networkId":4,"comment":"PoA test network","url":"https://www.rinkeby.io","genesis":{"hash":"0x6341fd3daf94b748c72ced5a5b26028f2474f5f00d824504e4fa37a75767e177","timestamp":"0x58ee40ba","gasLimit":4700000,"difficulty":1,"nonce":"0x0000000000000000","extraData":"0x52657370656374206d7920617574686f7269746168207e452e436172746d616e42eb768f2244c8811c63729a21a3569731535f067ffc57839b00206d1ad20c69a1981b489f772031b279182d99e65703f0076e4812653aab85fca0f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000","stateRoot":"0x53580584816f617295ea26c0e17641e0120cab2f0a8ffb53a866fd53aa8e8c2d"},"hardforks":[{"name":"chainstart","block":0,"consensus":"poa","finality":null},{"name":"homestead","block":1,"consensus":"poa","finality":null},{"name":"dao","block":null,"consensus":"poa","finality":null},{"name":"tangerineWhistle","block":2,"consensus":"poa","finality":null},{"name":"spuriousDragon","block":3,"consensus":"poa","finality":null},{"name":"byzantium","block":1035301,"consensus":"poa","finality":null},{"name":"constantinople","block":3660663,"consensus":"poa","finality":null},{"name":"petersburg","block":4321234,"consensus":"poa","finality":null},{"name":"istanbul","block":5435345,"consensus":"poa","finality":null}],"bootstrapNodes":[{"ip":"52.169.42.101","port":30303,"id":"a24ac7c5484ef4ed0c5eb2d36620ba4e4aa13b8c84684e1b4aab0cebea2ae45cb4d375b77eab56516d34bfbd3c1a833fc51296ff084b770b94fb9028c4d25ccf","location":"","comment":"IE"},{"ip":"52.3.158.184","port":30303,"id":"343149e4feefa15d882d9fe4ac7d88f885bd05ebb735e547f12e12080a9fa07c8014ca6fd7f373123488102fe5e34111f8509cf0b7de3f5b44339c9f25e87cb8","location":"","comment":"INFURA"},{"ip":"159.89.28.211","port":30303,"id":"b6b28890b006743680c52e64e0d16db57f28124885595fa03a562be1d2bf0f3a1da297d56b13da25fb992888fd556d4c1a27b1f39d531bde7de1921c90061cc6","location":"","comment":"AKASHA"}]}

/***/ }),

/***/ 532:
/***/ (function(module, exports) {

module.exports = {"name":"kovan","chainId":42,"networkId":42,"comment":"Parity PoA test network","url":"https://kovan-testnet.github.io/website/","genesis":{"hash":"0xa3c565fc15c7478862d50ccd6561e3c06b24cc509bf388941c25ea985ce32cb9","timestamp":null,"gasLimit":6000000,"difficulty":131072,"nonce":"0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000","extraData":"0x","stateRoot":"0x2480155b48a1cea17d67dbfdfaafe821c1d19cdd478c5358e8ec56dec24502b2"},"hardforks":[{"name":"chainstart","block":0,"consensus":"poa","finality":null},{"name":"homestead","block":0,"consensus":"poa","finality":null},{"name":"dao","block":0,"consensus":"poa","finality":null},{"name":"tangerineWhistle","block":0,"consensus":"poa","finality":null},{"name":"spuriousDragon","block":0,"consensus":"poa","finality":null},{"name":"byzantium","block":5067000,"consensus":"poa","finality":null},{"name":"constantinople","block":9200000,"consensus":"poa","finality":null},{"name":"petersburg","block":10255201,"consensus":"poa","finality":null},{"name":"istanbul","block":14111141,"consensus":"poa","finality":null}],"bootstrapNodes":[{"ip":"116.203.116.241","port":30303,"id":"16898006ba2cd4fa8bf9a3dfe32684c178fa861df144bfc21fe800dc4838a03e342056951fa9fd533dcb0be1219e306106442ff2cf1f7e9f8faa5f2fc1a3aa45","location":"","comment":"1"},{"ip":"3.217.96.11","port":30303,"id":"2909846f78c37510cc0e306f185323b83bb2209e5ff4fdd279d93c60e3f365e3c6e62ad1d2133ff11f9fd6d23ad9c3dad73bb974d53a22f7d1ac5b7dea79d0b0","location":"","comment":"2"},{"ip":"108.61.170.124","port":30303,"id":"740e1c8ea64e71762c71a463a04e2046070a0c9394fcab5891d41301dc473c0cff00ebab5a9bc87fbcb610ab98ac18225ff897bc8b7b38def5975d5ceb0a7d7c","location":"","comment":"3"},{"ip":"157.230.31.163","port":30303,"id":"2909846f78c37510cc0e306f185323b83bb2209e5ff4fdd279d93c60e3f365e3c6e62ad1d2133ff11f9fd6d23ad9c3dad73bb974d53a22f7d1ac5b7dea79d0b0","location":"","comment":"4"}]}

/***/ }),

/***/ 533:
/***/ (function(module, exports) {

module.exports = {"name":"goerli","chainId":5,"networkId":5,"comment":"Cross-client PoA test network","url":"https://github.com/goerli/testnet","genesis":{"hash":"0xbf7e331f7f7c1dd2e05159666b3bf8bc7a8a3a9eb1d518969eab529dd9b88c1a","timestamp":"0x5c51a607","gasLimit":10485760,"difficulty":1,"nonce":"0x0000000000000000","extraData":"0x22466c6578692069732061207468696e6722202d204166726900000000000000e0a2bd4258d2768837baa26a28fe71dc079f84c70000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000","stateRoot":"0x5d6cded585e73c4e322c30c2f782a336316f17dd85a4863b9d838d2d4b8b3008"},"hardforks":[{"name":"chainstart","block":0,"consensus":"poa","finality":null},{"name":"homestead","block":0,"consensus":"poa","finality":null},{"name":"dao","block":0,"consensus":"poa","finality":null},{"name":"tangerineWhistle","block":0,"consensus":"poa","finality":null},{"name":"spuriousDragon","block":0,"consensus":"poa","finality":null},{"name":"byzantium","block":0,"consensus":"poa","finality":null},{"name":"constantinople","block":0,"consensus":"poa","finality":null},{"name":"petersburg","block":0,"consensus":"poa","finality":null},{"name":"istanbul","block":1561651,"consensus":"poa","finality":null}],"bootstrapNodes":[{"ip":"51.141.78.53","port":30303,"id":"011f758e6552d105183b1761c5e2dea0111bc20fd5f6422bc7f91e0fabbec9a6595caf6239b37feb773dddd3f87240d99d859431891e4a642cf2a0a9e6cbb98a","location":"","comment":"Upstream bootnode 1"},{"ip":"13.93.54.137","port":30303,"id":"176b9417f511d05b6b2cf3e34b756cf0a7096b3094572a8f6ef4cdcb9d1f9d00683bf0f83347eebdf3b81c3521c2332086d9592802230bf528eaf606a1d9677b","location":"","comment":"Upstream bootnode 2"},{"ip":"94.237.54.114","port":30313,"id":"46add44b9f13965f7b9875ac6b85f016f341012d84f975377573800a863526f4da19ae2c620ec73d11591fa9510e992ecc03ad0751f53cc02f7c7ed6d55c7291","location":"","comment":"Upstream bootnode 3"},{"ip":"52.64.155.147","port":30303,"id":"c1f8b7c2ac4453271fa07d8e9ecf9a2e8285aa0bd0c07df0131f47153306b0736fd3db8924e7a9bf0bed6b1d8d4f87362a71b033dc7c64547728d953e43e59b2","location":"","comment":"Upstream bootnode 4"},{"ip":"213.186.16.82","port":30303,"id":"f4a9c6ee28586009fb5a96c8af13a58ed6d8315a9eee4772212c1d4d9cebe5a8b8a78ea4434f318726317d04a3f531a1ef0420cf9752605a562cfe858c46e263","location":"","comment":"Upstream bootnode 5"},{"ip":"3.11.147.67","port":30303,"id":"a61215641fb8714a373c80edbfa0ea8878243193f57c96eeb44d0bc019ef295abd4e044fd619bfc4c59731a73fb79afe84e9ab6da0c743ceb479cbb6d263fa91","location":"","comment":"Ethereum Foundation bootnode"}]}

/***/ }),

/***/ 535:
/***/ (function(module, exports) {

module.exports = {"name":"chainstart","comment":"Start of the Ethereum main chain","eip":{"url":"","status":""},"status":"","gasConfig":{"minGasLimit":{"v":5000,"d":"Minimum the gas limit may ever be"},"gasLimitBoundDivisor":{"v":1024,"d":"The bound divisor of the gas limit, used in update calculations"}},"gasPrices":{"base":{"v":2,"d":"Gas base cost, used e.g. for ChainID opcode (Istanbul)"},"tierStep":{"v":[0,2,3,5,8,10,20],"d":"Once per operation, for a selection of them"},"exp":{"v":10,"d":"Once per EXP instuction"},"expByte":{"v":10,"d":"Times ceil(log256(exponent)) for the EXP instruction"},"sha3":{"v":30,"d":"Once per SHA3 operation"},"sha3Word":{"v":6,"d":"Once per word of the SHA3 operation's data"},"sload":{"v":50,"d":"Once per SLOAD operation"},"sstoreSet":{"v":20000,"d":"Once per SSTORE operation if the zeroness changes from zero"},"sstoreReset":{"v":5000,"d":"Once per SSTORE operation if the zeroness does not change from zero"},"sstoreRefund":{"v":15000,"d":"Once per SSTORE operation if the zeroness changes to zero"},"jumpdest":{"v":1,"d":"Refunded gas, once per SSTORE operation if the zeroness changes to zero"},"log":{"v":375,"d":"Per LOG* operation"},"logData":{"v":8,"d":"Per byte in a LOG* operation's data"},"logTopic":{"v":375,"d":"Multiplied by the * of the LOG*, per LOG transaction. e.g. LOG0 incurs 0 * c_txLogTopicGas, LOG4 incurs 4 * c_txLogTopicGas"},"create":{"v":32000,"d":"Once per CREATE operation & contract-creation transaction"},"call":{"v":40,"d":"Once per CALL operation & message call transaction"},"callStipend":{"v":2300,"d":"Free gas given at beginning of call"},"callValueTransfer":{"v":9000,"d":"Paid for CALL when the value transfor is non-zero"},"callNewAccount":{"v":25000,"d":"Paid for CALL when the destination address didn't exist prior"},"selfdestructRefund":{"v":24000,"d":"Refunded following a selfdestruct operation"},"memory":{"v":3,"d":"Times the address of the (highest referenced byte in memory + 1). NOTE: referencing happens on read, write and in instructions such as RETURN and CALL"},"quadCoeffDiv":{"v":512,"d":"Divisor for the quadratic particle of the memory cost equation"},"createData":{"v":200,"d":""},"tx":{"v":21000,"d":"Per transaction. NOTE: Not payable on data of calls between transactions"},"txCreation":{"v":32000,"d":"The cost of creating a contract via tx"},"txDataZero":{"v":4,"d":"Per byte of data attached to a transaction that equals zero. NOTE: Not payable on data of calls between transactions"},"txDataNonZero":{"v":68,"d":"Per byte of data attached to a transaction that is not equal to zero. NOTE: Not payable on data of calls between transactions"},"copy":{"v":3,"d":"Multiplied by the number of 32-byte words that are copied (round up) for any *COPY operation and added"},"ecRecover":{"v":3000,"d":""},"sha256":{"v":60,"d":""},"sha256Word":{"v":12,"d":""},"ripemd160":{"v":600,"d":""},"ripemd160Word":{"v":120,"d":""},"identity":{"v":15,"d":""},"identityWord":{"v":3,"d":""}},"vm":{"stackLimit":{"v":1024,"d":"Maximum size of VM stack allowed"},"callCreateDepth":{"v":1024,"d":"Maximum depth of call/create stack"},"maxExtraDataSize":{"v":32,"d":"Maximum size extra data may be after Genesis"}},"pow":{"minimumDifficulty":{"v":131072,"d":"The minimum that the difficulty may ever be"},"difficultyBoundDivisor":{"v":2048,"d":"The bound divisor of the difficulty, used in the update calculations"},"durationLimit":{"v":13,"d":"The decision boundary on the blocktime duration used to determine whether difficulty should go up or not"},"epochDuration":{"v":30000,"d":"Duration between proof-of-work epochs"},"timebombPeriod":{"v":100000,"d":"Exponential difficulty timebomb period"},"minerReward":{"v":"5000000000000000000","d":"the amount a miner get rewarded for mining a block"}},"casper":{},"sharding":{}}

/***/ }),

/***/ 536:
/***/ (function(module, exports) {

module.exports = {"name":"homestead","comment":"Homestead hardfork with protocol and network changes","eip":{"url":"https://eips.ethereum.org/EIPS/eip-606","status":"Final"},"gasConfig":{},"gasPrices":{},"vm":{},"pow":{},"casper":{},"sharding":{}}

/***/ }),

/***/ 537:
/***/ (function(module, exports) {

module.exports = {"name":"dao","comment":"DAO rescue hardfork","eip":{"url":"https://eips.ethereum.org/EIPS/eip-779","status":"Final"},"gasConfig":{},"gasPrices":{},"vm":{},"pow":{},"casper":{},"sharding":{}}

/***/ }),

/***/ 538:
/***/ (function(module, exports) {

module.exports = {"name":"tangerineWhistle","comment":"Hardfork with gas cost changes for IO-heavy operations","eip":{"url":"https://eips.ethereum.org/EIPS/eip-608","status":"Final"},"gasConfig":{},"gasPrices":{"sload":{"v":200,"d":"Once per SLOAD operation"},"call":{"v":700,"d":"Once per CALL operation & message call transaction"}},"vm":{},"pow":{},"casper":{},"sharding":{}}

/***/ }),

/***/ 539:
/***/ (function(module, exports) {

module.exports = {"name":"spuriousDragon","comment":"HF with EIPs for simple replay attack protection, EXP cost increase, state trie clearing, contract code size limit","eip":{"url":"https://eips.ethereum.org/EIPS/eip-607","status":"Final"},"gasConfig":{},"gasPrices":{"expByte":{"v":50,"d":"Times ceil(log256(exponent)) for the EXP instruction"}},"vm":{"maxCodeSize":{"v":24576,"d":"Maximum length of contract code"}},"pow":{},"casper":{},"sharding":{}}

/***/ }),

/***/ 540:
/***/ (function(module, exports) {

module.exports = {"name":"byzantium","comment":"Hardfork with new precompiles, instructions and other protocol changes","eip":{"url":"https://eips.ethereum.org/EIPS/eip-609","status":"Final"},"gasConfig":{},"gasPrices":{"modexpGquaddivisor":{"v":20,"d":"Gquaddivisor from modexp precompile for gas calculation"},"ecAdd":{"v":500,"d":"Gas costs for curve addition precompile"},"ecMul":{"v":40000,"d":"Gas costs for curve multiplication precompile"},"ecPairing":{"v":100000,"d":"Base gas costs for curve pairing precompile"},"ecPairingWord":{"v":80000,"d":"Gas costs regarding curve pairing precompile input length"}},"vm":{},"pow":{"minerReward":{"v":"3000000000000000000","d":"the amount a miner get rewarded for mining a block"}},"casper":{},"sharding":{}}

/***/ }),

/***/ 541:
/***/ (function(module, exports) {

module.exports = {"name":"constantinople","comment":"Postponed hardfork including EIP-1283 (SSTORE gas metering changes)","eip":{"url":"https://eips.ethereum.org/EIPS/eip-1013","status":"Final"},"gasConfig":{},"gasPrices":{"netSstoreNoopGas":{"v":200,"d":"Once per SSTORE operation if the value doesn't change"},"netSstoreInitGas":{"v":20000,"d":"Once per SSTORE operation from clean zero"},"netSstoreCleanGas":{"v":5000,"d":"Once per SSTORE operation from clean non-zero"},"netSstoreDirtyGas":{"v":200,"d":"Once per SSTORE operation from dirty"},"netSstoreClearRefund":{"v":15000,"d":"Once per SSTORE operation for clearing an originally existing storage slot"},"netSstoreResetRefund":{"v":4800,"d":"Once per SSTORE operation for resetting to the original non-zero value"},"netSstoreResetClearRefund":{"v":19800,"d":"Once per SSTORE operation for resetting to the original zero value"}},"vm":{},"pow":{"minerReward":{"v":"2000000000000000000","d":"The amount a miner gets rewarded for mining a block"}},"casper":{},"sharding":{}}

/***/ }),

/***/ 542:
/***/ (function(module, exports) {

module.exports = {"name":"petersburg","comment":"Aka constantinopleFix, removes EIP-1283, activate together with or after constantinople","eip":{"url":"https://eips.ethereum.org/EIPS/eip-1716","status":"Draft"},"gasConfig":{},"gasPrices":{"netSstoreNoopGas":{"v":null,"d":"Removed along EIP-1283"},"netSstoreInitGas":{"v":null,"d":"Removed along EIP-1283"},"netSstoreCleanGas":{"v":null,"d":"Removed along EIP-1283"},"netSstoreDirtyGas":{"v":null,"d":"Removed along EIP-1283"},"netSstoreClearRefund":{"v":null,"d":"Removed along EIP-1283"},"netSstoreResetRefund":{"v":null,"d":"Removed along EIP-1283"},"netSstoreResetClearRefund":{"v":null,"d":"Removed along EIP-1283"}},"vm":{},"pow":{},"casper":{},"sharding":{}}

/***/ }),

/***/ 543:
/***/ (function(module, exports) {

module.exports = {"name":"istanbul","comment":"HF targeted for December 2019 following the Constantinople/Petersburg HF","eip":{"url":"https://eips.ethereum.org/EIPS/eip-1679","status":"Draft"},"gasConfig":{},"gasPrices":{"blake2Round":{"v":1,"d":"Gas cost per round for the Blake2 F precompile"},"ecAdd":{"v":150,"d":"Gas costs for curve addition precompile"},"ecMul":{"v":6000,"d":"Gas costs for curve multiplication precompile"},"ecPairing":{"v":45000,"d":"Base gas costs for curve pairing precompile"},"ecPairingWord":{"v":34000,"d":"Gas costs regarding curve pairing precompile input length"},"txDataNonZero":{"v":16,"d":"Per byte of data attached to a transaction that is not equal to zero. NOTE: Not payable on data of calls between transactions"},"sstoreSentryGasEIP2200":{"v":2300,"d":"Minimum gas required to be present for an SSTORE call, not consumed"},"sstoreNoopGasEIP2200":{"v":800,"d":"Once per SSTORE operation if the value doesn't change"},"sstoreDirtyGasEIP2200":{"v":800,"d":"Once per SSTORE operation if a dirty value is changed"},"sstoreInitGasEIP2200":{"v":20000,"d":"Once per SSTORE operation from clean zero to non-zero"},"sstoreInitRefundEIP2200":{"v":19200,"d":"Once per SSTORE operation for resetting to the original zero value"},"sstoreCleanGasEIP2200":{"v":5000,"d":"Once per SSTORE operation from clean non-zero to something else"},"sstoreCleanRefundEIP2200":{"v":4200,"d":"Once per SSTORE operation for resetting to the original non-zero value"},"sstoreClearRefundEIP2200":{"v":15000,"d":"Once per SSTORE operation for clearing an originally existing storage slot"}},"vm":{},"pow":{},"casper":{},"sharding":{}}

/***/ }),

/***/ 544:
/***/ (function(module, exports) {

module.exports = {"name":"muirGlacier","comment":"HF to delay the difficulty bomb","eip":{"url":"https://eips.ethereum.org/EIPS/eip-2384","status":"Last Call"},"gasConfig":{},"gasPrices":{},"vm":{},"pow":{},"casper":{},"sharding":{}}

/***/ }),

/***/ 570:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "auth" }, [
    _vm._m(0),
    _vm._v(" "),
    _c("h1", { staticClass: "auth-title" }, [_vm._v("MOOMASK")]),
    _vm._v(" "),
    _c(
      "div",
      {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.error.show,
            expression: "error.show"
          }
        ],
        staticClass: "message error"
      },
      [_vm._v("\n        " + _vm._s(_vm.error.message) + "\n    ")]
    ),
    _vm._v(" "),
    _c(
      "form",
      {
        staticClass: "auth-form",
        attrs: { action: "", method: "post", autocomplete: "off" },
        on: { submit: _vm.submitForm }
      },
      [
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.password,
              expression: "password"
            }
          ],
          staticClass: "input-field",
          attrs: {
            type: "password",
            name: "password",
            placeholder: "Password"
          },
          domProps: { value: _vm.password },
          on: {
            input: function($event) {
              if ($event.target.composing) {
                return
              }
              _vm.password = $event.target.value
            }
          }
        }),
        _vm._v(" "),
        _c(
          "button",
          { staticClass: "button brand", attrs: { type: "submit" } },
          [_vm._v("Sign In")]
        ),
        _vm._v(" "),
        _vm._m(1),
        _vm._v(" "),
        _c(
          "router-link",
          { staticClass: "button", attrs: { to: "/create-wallet" } },
          [_vm._v("Create New Wallet")]
        ),
        _vm._v(" "),
        _c(
          "router-link",
          { staticClass: "button", attrs: { to: "/import-wallet" } },
          [_vm._v("Import Wallet from Private Key")]
        )
      ],
      1
    )
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "auth-logo" }, [
      _c("img", { attrs: { src: "images/bscpay.png", alt: "MooMask" } })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "line-through" }, [
      _c("span", [_vm._v("or")])
    ])
  }
]
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-8d6adeae", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 571:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_CreateWallet_vue__ = __webpack_require__(240);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_CreateWallet_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_CreateWallet_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_CreateWallet_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_CreateWallet_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_3978003c_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_CreateWallet_vue__ = __webpack_require__(579);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
function injectStyle (context) {
  if (disposed) return
  __webpack_require__(572)
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_CreateWallet_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_3978003c_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_CreateWallet_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_3978003c_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_CreateWallet_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/CreateWallet.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-3978003c", Component.options)
  } else {
    hotAPI.reload("data-v-3978003c", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 572:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(573);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(22).default
var update = add("2bbb3946", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./CreateWallet.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./CreateWallet.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 573:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports


// module
exports.push([module.i, "\n.header {\n    width: 370px;\n    position: fixed;\n    top: 0;\n    left: 0;\n    background: #FFFFFF;\n    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);\n}\n.header-top {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-pack: end;\n        justify-content: flex-end;\n    padding: 0.5rem 0.875rem;\n    line-height: 1;\n    position: relative;\n}\n.header-logo {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-align: center;\n        align-items: center;\n    -ms-flex: 1;\n        flex: 1;\n    font-size: 1rem;\n    font-weight: 600;\n    color: #424242;\n}\n.header-logo img,\n.header-logo span {\n    display: block;\n}\n.header-logo img {\n    margin-right: 5px;\n}\n.network {\n    margin: -0.2rem 0.75rem 0;\n    position: relative;\n}\n.network span {\n    display: block;\n}\na.network-toggle {\n    max-width: 150px;\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-align: center;\n        align-items: center;\n    -ms-flex-pack: justify;\n        justify-content: space-between;\n    font-size: 0.625rem;\n    text-transform: uppercase;\n    padding: 0.4rem;\n    background: #E0E0E0;\n    border-radius: 3px;\n    color: #757575;\n    cursor: pointer;\n}\na.network-toggle:hover {\n    background: #DDDDDD;\n}\n.network-icon {\n    font-size: 0.5rem;\n    padding-top: 2px;\n}\n.network-arrow {\n    padding-top: 2px;\n}\n.network-name {\n    -ms-flex: 1;\n        flex: 1;\n    font-weight: 600;\n    color: #616161;\n    padding: 0.1rem 0.3rem;\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n}\n.network-dropdown {\n    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);\n    background: #FFFFFF;\n    position: absolute;\n    top: 30px;\n    right: 0px;\n    padding: 0.375rem 0;\n    border-radius: 3px;\n    min-width: 100px;\n}\n.network-dropdown a {\n    display: -ms-flexbox;\n    display: flex;\n    padding: 0.375rem 0.75rem;\n    font-size: 0.75rem;\n    line-height: 1.25;\n    color: #757575;\n}\n.network-dropdown a:hover,\n.network-dropdown a:focus {\n    color: #184c82;\n}\n.network-dropdown a span {\n    display: block;\n}\n.network-dropdown-icon {\n    padding: 3px 8px 0 0;\n    font-size: 0.625rem;\n}\n.dropdown-menu-toggle {\n    display: block;\n    font-size: 1.125rem;\n    color: #424242;\n}\n.dropdown-menu {\n    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);\n    background: #FFFFFF;\n    position: absolute;\n    top: 40px;\n    right: 10px;\n    padding: 0.5rem 0;\n    border-radius: 3px;\n    min-width: 125px;\n}\n.dropdown-menu a {\n    display: block;\n    padding: 0.5rem 1rem;\n    font-size: 0.875rem;\n    color: #757575;\n}\n.dropdown-menu a:hover,\n.dropdown-menu a:focus {\n    color: #184c82;\n}\n\n", ""]);

// exports


/***/ }),

/***/ 579:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "auth" }, [
    _c("header", { staticClass: "header" }, [
      _c("div", { staticClass: "header-top" }, [
        _c(
          "div",
          {
            directives: [
              {
                name: "click-outside",
                rawName: "v-click-outside",
                value: _vm.hideNetworkDropdown,
                expression: "hideNetworkDropdown"
              }
            ],
            staticClass: "network"
          },
          [
            _c(
              "a",
              {
                staticClass: "network-toggle",
                attrs: { href: "#" },
                on: {
                  click: function($event) {
                    $event.preventDefault()
                    return _vm.toggleNetworkDropdown($event)
                  }
                }
              },
              [
                _c("span", { staticClass: "network-icon" }, [
                  _c(
                    "svg",
                    {
                      staticClass: "icon",
                      attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20"
                      }
                    },
                    [
                      _c("path", {
                        attrs: {
                          d:
                            "M10 20a10 10 0 1 1 0-20 10 10 0 0 1 0 20zm7.75-8a8.01 8.01 0 0 0 0-4h-3.82a28.81 28.81 0 0 1 0 4h3.82zm-.82 2h-3.22a14.44 14.44 0 0 1-.95 3.51A8.03 8.03 0 0 0 16.93 14zm-8.85-2h3.84a24.61 24.61 0 0 0 0-4H8.08a24.61 24.61 0 0 0 0 4zm.25 2c.41 2.4 1.13 4 1.67 4s1.26-1.6 1.67-4H8.33zm-6.08-2h3.82a28.81 28.81 0 0 1 0-4H2.25a8.01 8.01 0 0 0 0 4zm.82 2a8.03 8.03 0 0 0 4.17 3.51c-.42-.96-.74-2.16-.95-3.51H3.07zm13.86-8a8.03 8.03 0 0 0-4.17-3.51c.42.96.74 2.16.95 3.51h3.22zm-8.6 0h3.34c-.41-2.4-1.13-4-1.67-4S8.74 3.6 8.33 6zM3.07 6h3.22c.2-1.35.53-2.55.95-3.51A8.03 8.03 0 0 0 3.07 6z"
                        }
                      })
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("span", { staticClass: "network-name" }, [
                  _vm._v(_vm._s(_vm.currentNetwork.name))
                ]),
                _vm._v(" "),
                _c("span", { staticClass: "network-arrow" }, [
                  _c(
                    "svg",
                    {
                      staticClass: "icon",
                      attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20"
                      }
                    },
                    [
                      _c("path", {
                        attrs: {
                          d:
                            "M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                        }
                      })
                    ]
                  )
                ])
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.showNetworkDropdown,
                    expression: "showNetworkDropdown"
                  }
                ],
                staticClass: "network-dropdown"
              },
              _vm._l(_vm.networks, function(network) {
                return _c(
                  "a",
                  {
                    key: network.id,
                    attrs: { href: "#" },
                    on: {
                      click: function($event) {
                        $event.preventDefault()
                        return _vm.changeNetwork(network)
                      }
                    }
                  },
                  [
                    _c("span", { staticClass: "network-dropdown-icon" }, [
                      _vm.currentNetwork.id === network.id
                        ? _c(
                            "svg",
                            {
                              staticClass: "icon",
                              attrs: {
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "-2 -1.5 24 24",
                                width: "24",
                                height: "24",
                                preserveAspectRatio: "xMinYMin"
                              }
                            },
                            [
                              _c("path", {
                                attrs: {
                                  d:
                                    "M10 20.565c-5.523 0-10-4.477-10-10s4.477-10 10-10 10 4.477 10 10-4.477 10-10 10z"
                                }
                              })
                            ]
                          )
                        : _c(
                            "svg",
                            {
                              staticClass: "icon",
                              attrs: {
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "-2 -2 24 24",
                                width: "24",
                                height: "24",
                                preserveAspectRatio: "xMinYMin"
                              }
                            },
                            [
                              _c("path", {
                                attrs: {
                                  d:
                                    "M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm0 2C4.477 20 0 15.523 0 10S4.477 0 10 0s10 4.477 10 10-4.477 10-10 10z"
                                }
                              })
                            ]
                          )
                    ]),
                    _vm._v(" "),
                    _c("span", [_vm._v(_vm._s(network.name))])
                  ]
                )
              }),
              0
            )
          ]
        )
      ])
    ]),
    _vm._v(" "),
    _vm._m(0),
    _vm._v(" "),
    _c("h1", { staticClass: "auth-title" }, [_vm._v("MOOMASK")]),
    _vm._v(" "),
    _vm.wallet
      ? _c("div", [
          _c("div", { staticClass: "message error" }, [
            _vm._v("\n            SAVE YOUR PRIVATE KEY\n        ")
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "input-group" }, [
            _c("textarea", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.wallet.privateKey,
                  expression: "wallet.privateKey"
                }
              ],
              staticClass: "input-field special",
              attrs: { type: "text", rows: "3", readonly: "" },
              domProps: { value: _vm.wallet.privateKey },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.$set(_vm.wallet, "privateKey", $event.target.value)
                }
              }
            }),
            _vm._v(" "),
            _c(
              "button",
              {
                directives: [
                  {
                    name: "clipboard",
                    rawName: "v-clipboard:copy",
                    value: _vm.wallet.privateKey,
                    expression: "wallet.privateKey",
                    arg: "copy"
                  }
                ],
                staticClass: "button",
                attrs: { title: "Copy to clipboard" }
              },
              [
                _c(
                  "svg",
                  {
                    staticClass: "icon",
                    attrs: {
                      xmlns: "http://www.w3.org/2000/svg",
                      viewBox: "0 0 20 20"
                    }
                  },
                  [
                    _c("path", {
                      attrs: {
                        d:
                          "M6 6V2c0-1.1.9-2 2-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-4v4a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V8c0-1.1.9-2 2-2h4zm2 0h4a2 2 0 0 1 2 2v4h4V2H8v4zM2 8v10h10V8H2z"
                      }
                    })
                  ]
                )
              ]
            )
          ]),
          _vm._v(" "),
          _vm._m(1),
          _vm._v(" "),
          _c(
            "a",
            { staticClass: "button brand", on: { click: _vm.savePrivateKey } },
            [_vm._v("I've copied it somewhere safe")]
          )
        ])
      : _c("div", [
          _c(
            "div",
            {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: _vm.error.show,
                  expression: "error.show"
                }
              ],
              staticClass: "message error"
            },
            [
              _vm._v(
                "\n            " + _vm._s(_vm.error.message) + "\n        "
              )
            ]
          ),
          _vm._v(" "),
          _c(
            "form",
            {
              staticClass: "auth-form",
              attrs: { action: "", method: "post", autocomplete: "off" },
              on: { submit: _vm.submitForm }
            },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.password,
                    expression: "password"
                  }
                ],
                staticClass: "input-field",
                attrs: {
                  type: "password",
                  name: "password",
                  placeholder: "New Password (min 8 chars)"
                },
                domProps: { value: _vm.password },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.password = $event.target.value
                  }
                }
              }),
              _vm._v(" "),
              _c("div", { staticClass: "form-info" }, [
                _vm._v(
                  "\n                This password encrypts your private key. Make sure to remember this password as you will need it to unlock your wallet.\n            "
                )
              ]),
              _vm._v(" "),
              _c(
                "button",
                { staticClass: "button brand", attrs: { type: "submit" } },
                [_vm._v("Create New Wallet")]
              ),
              _vm._v(" "),
              _vm.keystore
                ? _c("div", [
                    _c(
                      "a",
                      {
                        staticClass: "auth-link",
                        on: {
                          click: function($event) {
                            return _vm.$router.back()
                          }
                        }
                      },
                      [_vm._v("Cancel")]
                    )
                  ])
                : _c(
                    "div",
                    [
                      _vm._m(2),
                      _vm._v(" "),
                      _c(
                        "router-link",
                        {
                          staticClass: "button",
                          attrs: { to: "/import-wallet" }
                        },
                        [_vm._v("Import Wallet from Private Key")]
                      )
                    ],
                    1
                  )
            ]
          )
        ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "auth-logo" }, [
      _c("img", { attrs: { src: "images/bscpay.png", alt: "MooMask" } })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "form-info" }, [
      _c("p", [
        _c("strong", [_vm._v("Do not lose it!")]),
        _vm._v(" It can't be recovered if you lose it.")
      ]),
      _vm._v(" "),
      _c("p", [
        _c("strong", [_vm._v("Do not share it!")]),
        _vm._v(" Your funds will be stolen if you use it on a malicious site.")
      ]),
      _vm._v(" "),
      _c("p", [
        _c("strong", [_vm._v("Make a backup!")]),
        _vm._v(" Just in case your laptop is set on fire.")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "line-through" }, [
      _c("span", [_vm._v("or")])
    ])
  }
]
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-3978003c", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 58:
/***/ (function(module, exports) {

module.exports = {"identity":0,"ip4":4,"tcp":6,"sha1":17,"sha2-256":18,"sha2-512":19,"sha3-512":20,"sha3-384":21,"sha3-256":22,"sha3-224":23,"shake-128":24,"shake-256":25,"keccak-224":26,"keccak-256":27,"keccak-384":28,"keccak-512":29,"blake3":30,"dccp":33,"murmur3-128":34,"murmur3-32":35,"ip6":41,"ip6zone":42,"path":47,"multicodec":48,"multihash":49,"multiaddr":50,"multibase":51,"dns":53,"dns4":54,"dns6":55,"dnsaddr":56,"protobuf":80,"cbor":81,"raw":85,"dbl-sha2-256":86,"rlp":96,"bencode":99,"dag-pb":112,"dag-cbor":113,"libp2p-key":114,"git-raw":120,"torrent-info":123,"torrent-file":124,"leofcoin-block":129,"leofcoin-tx":130,"leofcoin-pr":131,"sctp":132,"dag-jose":133,"dag-cose":134,"eth-block":144,"eth-block-list":145,"eth-tx-trie":146,"eth-tx":147,"eth-tx-receipt-trie":148,"eth-tx-receipt":149,"eth-state-trie":150,"eth-account-snapshot":151,"eth-storage-trie":152,"bitcoin-block":176,"bitcoin-tx":177,"bitcoin-witness-commitment":178,"zcash-block":192,"zcash-tx":193,"stellar-block":208,"stellar-tx":209,"md4":212,"md5":213,"bmt":214,"decred-block":224,"decred-tx":225,"ipld-ns":226,"ipfs-ns":227,"swarm-ns":228,"ipns-ns":229,"zeronet":230,"secp256k1-pub":231,"bls12_381-g1-pub":234,"bls12_381-g2-pub":235,"x25519-pub":236,"ed25519-pub":237,"dash-block":240,"dash-tx":241,"swarm-manifest":250,"swarm-feed":251,"udp":273,"p2p-webrtc-star":275,"p2p-webrtc-direct":276,"p2p-stardust":277,"p2p-circuit":290,"dag-json":297,"udt":301,"utp":302,"unix":400,"p2p":421,"ipfs":421,"https":443,"onion":444,"onion3":445,"garlic64":446,"garlic32":447,"tls":448,"quic":460,"ws":477,"wss":478,"p2p-websocket-star":479,"http":480,"json":512,"messagepack":513,"libp2p-peer-record":769,"sha2-256-trunc254-padded":4114,"ripemd-128":4178,"ripemd-160":4179,"ripemd-256":4180,"ripemd-320":4181,"x11":4352,"sm3-256":21325,"blake2b-8":45569,"blake2b-16":45570,"blake2b-24":45571,"blake2b-32":45572,"blake2b-40":45573,"blake2b-48":45574,"blake2b-56":45575,"blake2b-64":45576,"blake2b-72":45577,"blake2b-80":45578,"blake2b-88":45579,"blake2b-96":45580,"blake2b-104":45581,"blake2b-112":45582,"blake2b-120":45583,"blake2b-128":45584,"blake2b-136":45585,"blake2b-144":45586,"blake2b-152":45587,"blake2b-160":45588,"blake2b-168":45589,"blake2b-176":45590,"blake2b-184":45591,"blake2b-192":45592,"blake2b-200":45593,"blake2b-208":45594,"blake2b-216":45595,"blake2b-224":45596,"blake2b-232":45597,"blake2b-240":45598,"blake2b-248":45599,"blake2b-256":45600,"blake2b-264":45601,"blake2b-272":45602,"blake2b-280":45603,"blake2b-288":45604,"blake2b-296":45605,"blake2b-304":45606,"blake2b-312":45607,"blake2b-320":45608,"blake2b-328":45609,"blake2b-336":45610,"blake2b-344":45611,"blake2b-352":45612,"blake2b-360":45613,"blake2b-368":45614,"blake2b-376":45615,"blake2b-384":45616,"blake2b-392":45617,"blake2b-400":45618,"blake2b-408":45619,"blake2b-416":45620,"blake2b-424":45621,"blake2b-432":45622,"blake2b-440":45623,"blake2b-448":45624,"blake2b-456":45625,"blake2b-464":45626,"blake2b-472":45627,"blake2b-480":45628,"blake2b-488":45629,"blake2b-496":45630,"blake2b-504":45631,"blake2b-512":45632,"blake2s-8":45633,"blake2s-16":45634,"blake2s-24":45635,"blake2s-32":45636,"blake2s-40":45637,"blake2s-48":45638,"blake2s-56":45639,"blake2s-64":45640,"blake2s-72":45641,"blake2s-80":45642,"blake2s-88":45643,"blake2s-96":45644,"blake2s-104":45645,"blake2s-112":45646,"blake2s-120":45647,"blake2s-128":45648,"blake2s-136":45649,"blake2s-144":45650,"blake2s-152":45651,"blake2s-160":45652,"blake2s-168":45653,"blake2s-176":45654,"blake2s-184":45655,"blake2s-192":45656,"blake2s-200":45657,"blake2s-208":45658,"blake2s-216":45659,"blake2s-224":45660,"blake2s-232":45661,"blake2s-240":45662,"blake2s-248":45663,"blake2s-256":45664,"skein256-8":45825,"skein256-16":45826,"skein256-24":45827,"skein256-32":45828,"skein256-40":45829,"skein256-48":45830,"skein256-56":45831,"skein256-64":45832,"skein256-72":45833,"skein256-80":45834,"skein256-88":45835,"skein256-96":45836,"skein256-104":45837,"skein256-112":45838,"skein256-120":45839,"skein256-128":45840,"skein256-136":45841,"skein256-144":45842,"skein256-152":45843,"skein256-160":45844,"skein256-168":45845,"skein256-176":45846,"skein256-184":45847,"skein256-192":45848,"skein256-200":45849,"skein256-208":45850,"skein256-216":45851,"skein256-224":45852,"skein256-232":45853,"skein256-240":45854,"skein256-248":45855,"skein256-256":45856,"skein512-8":45857,"skein512-16":45858,"skein512-24":45859,"skein512-32":45860,"skein512-40":45861,"skein512-48":45862,"skein512-56":45863,"skein512-64":45864,"skein512-72":45865,"skein512-80":45866,"skein512-88":45867,"skein512-96":45868,"skein512-104":45869,"skein512-112":45870,"skein512-120":45871,"skein512-128":45872,"skein512-136":45873,"skein512-144":45874,"skein512-152":45875,"skein512-160":45876,"skein512-168":45877,"skein512-176":45878,"skein512-184":45879,"skein512-192":45880,"skein512-200":45881,"skein512-208":45882,"skein512-216":45883,"skein512-224":45884,"skein512-232":45885,"skein512-240":45886,"skein512-248":45887,"skein512-256":45888,"skein512-264":45889,"skein512-272":45890,"skein512-280":45891,"skein512-288":45892,"skein512-296":45893,"skein512-304":45894,"skein512-312":45895,"skein512-320":45896,"skein512-328":45897,"skein512-336":45898,"skein512-344":45899,"skein512-352":45900,"skein512-360":45901,"skein512-368":45902,"skein512-376":45903,"skein512-384":45904,"skein512-392":45905,"skein512-400":45906,"skein512-408":45907,"skein512-416":45908,"skein512-424":45909,"skein512-432":45910,"skein512-440":45911,"skein512-448":45912,"skein512-456":45913,"skein512-464":45914,"skein512-472":45915,"skein512-480":45916,"skein512-488":45917,"skein512-496":45918,"skein512-504":45919,"skein512-512":45920,"skein1024-8":45921,"skein1024-16":45922,"skein1024-24":45923,"skein1024-32":45924,"skein1024-40":45925,"skein1024-48":45926,"skein1024-56":45927,"skein1024-64":45928,"skein1024-72":45929,"skein1024-80":45930,"skein1024-88":45931,"skein1024-96":45932,"skein1024-104":45933,"skein1024-112":45934,"skein1024-120":45935,"skein1024-128":45936,"skein1024-136":45937,"skein1024-144":45938,"skein1024-152":45939,"skein1024-160":45940,"skein1024-168":45941,"skein1024-176":45942,"skein1024-184":45943,"skein1024-192":45944,"skein1024-200":45945,"skein1024-208":45946,"skein1024-216":45947,"skein1024-224":45948,"skein1024-232":45949,"skein1024-240":45950,"skein1024-248":45951,"skein1024-256":45952,"skein1024-264":45953,"skein1024-272":45954,"skein1024-280":45955,"skein1024-288":45956,"skein1024-296":45957,"skein1024-304":45958,"skein1024-312":45959,"skein1024-320":45960,"skein1024-328":45961,"skein1024-336":45962,"skein1024-344":45963,"skein1024-352":45964,"skein1024-360":45965,"skein1024-368":45966,"skein1024-376":45967,"skein1024-384":45968,"skein1024-392":45969,"skein1024-400":45970,"skein1024-408":45971,"skein1024-416":45972,"skein1024-424":45973,"skein1024-432":45974,"skein1024-440":45975,"skein1024-448":45976,"skein1024-456":45977,"skein1024-464":45978,"skein1024-472":45979,"skein1024-480":45980,"skein1024-488":45981,"skein1024-496":45982,"skein1024-504":45983,"skein1024-512":45984,"skein1024-520":45985,"skein1024-528":45986,"skein1024-536":45987,"skein1024-544":45988,"skein1024-552":45989,"skein1024-560":45990,"skein1024-568":45991,"skein1024-576":45992,"skein1024-584":45993,"skein1024-592":45994,"skein1024-600":45995,"skein1024-608":45996,"skein1024-616":45997,"skein1024-624":45998,"skein1024-632":45999,"skein1024-640":46000,"skein1024-648":46001,"skein1024-656":46002,"skein1024-664":46003,"skein1024-672":46004,"skein1024-680":46005,"skein1024-688":46006,"skein1024-696":46007,"skein1024-704":46008,"skein1024-712":46009,"skein1024-720":46010,"skein1024-728":46011,"skein1024-736":46012,"skein1024-744":46013,"skein1024-752":46014,"skein1024-760":46015,"skein1024-768":46016,"skein1024-776":46017,"skein1024-784":46018,"skein1024-792":46019,"skein1024-800":46020,"skein1024-808":46021,"skein1024-816":46022,"skein1024-824":46023,"skein1024-832":46024,"skein1024-840":46025,"skein1024-848":46026,"skein1024-856":46027,"skein1024-864":46028,"skein1024-872":46029,"skein1024-880":46030,"skein1024-888":46031,"skein1024-896":46032,"skein1024-904":46033,"skein1024-912":46034,"skein1024-920":46035,"skein1024-928":46036,"skein1024-936":46037,"skein1024-944":46038,"skein1024-952":46039,"skein1024-960":46040,"skein1024-968":46041,"skein1024-976":46042,"skein1024-984":46043,"skein1024-992":46044,"skein1024-1000":46045,"skein1024-1008":46046,"skein1024-1016":46047,"skein1024-1024":46048,"poseidon-bls12_381-a2-fc1":46081,"poseidon-bls12_381-a2-fc1-sc":46082,"zeroxcert-imprint-256":52753,"fil-commitment-unsealed":61697,"fil-commitment-sealed":61698,"holochain-adr-v0":8417572,"holochain-adr-v1":8483108,"holochain-key-v0":9728292,"holochain-key-v1":9793828,"holochain-sig-v0":10645796,"holochain-sig-v1":10711332}

/***/ }),

/***/ 580:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ImportWallet_vue__ = __webpack_require__(242);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ImportWallet_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ImportWallet_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ImportWallet_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ImportWallet_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_2b4f53a5_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_ImportWallet_vue__ = __webpack_require__(581);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ImportWallet_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_2b4f53a5_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_ImportWallet_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_2b4f53a5_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_ImportWallet_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/ImportWallet.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-2b4f53a5", Component.options)
  } else {
    hotAPI.reload("data-v-2b4f53a5", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 581:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "auth" }, [
    _c("header", { staticClass: "header" }, [
      _c("div", { staticClass: "header-top" }, [
        _c(
          "div",
          {
            directives: [
              {
                name: "click-outside",
                rawName: "v-click-outside",
                value: _vm.hideNetworkDropdown,
                expression: "hideNetworkDropdown"
              }
            ],
            staticClass: "network"
          },
          [
            _c(
              "a",
              {
                staticClass: "network-toggle",
                attrs: { href: "#" },
                on: {
                  click: function($event) {
                    $event.preventDefault()
                    return _vm.toggleNetworkDropdown($event)
                  }
                }
              },
              [
                _c("span", { staticClass: "network-icon" }, [
                  _c(
                    "svg",
                    {
                      staticClass: "icon",
                      attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20"
                      }
                    },
                    [
                      _c("path", {
                        attrs: {
                          d:
                            "M10 20a10 10 0 1 1 0-20 10 10 0 0 1 0 20zm7.75-8a8.01 8.01 0 0 0 0-4h-3.82a28.81 28.81 0 0 1 0 4h3.82zm-.82 2h-3.22a14.44 14.44 0 0 1-.95 3.51A8.03 8.03 0 0 0 16.93 14zm-8.85-2h3.84a24.61 24.61 0 0 0 0-4H8.08a24.61 24.61 0 0 0 0 4zm.25 2c.41 2.4 1.13 4 1.67 4s1.26-1.6 1.67-4H8.33zm-6.08-2h3.82a28.81 28.81 0 0 1 0-4H2.25a8.01 8.01 0 0 0 0 4zm.82 2a8.03 8.03 0 0 0 4.17 3.51c-.42-.96-.74-2.16-.95-3.51H3.07zm13.86-8a8.03 8.03 0 0 0-4.17-3.51c.42.96.74 2.16.95 3.51h3.22zm-8.6 0h3.34c-.41-2.4-1.13-4-1.67-4S8.74 3.6 8.33 6zM3.07 6h3.22c.2-1.35.53-2.55.95-3.51A8.03 8.03 0 0 0 3.07 6z"
                        }
                      })
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("span", { staticClass: "network-name" }, [
                  _vm._v(_vm._s(_vm.currentNetwork.name))
                ]),
                _vm._v(" "),
                _c("span", { staticClass: "network-arrow" }, [
                  _c(
                    "svg",
                    {
                      staticClass: "icon",
                      attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20"
                      }
                    },
                    [
                      _c("path", {
                        attrs: {
                          d:
                            "M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                        }
                      })
                    ]
                  )
                ])
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.showNetworkDropdown,
                    expression: "showNetworkDropdown"
                  }
                ],
                staticClass: "network-dropdown"
              },
              _vm._l(_vm.networks, function(network) {
                return _c(
                  "a",
                  {
                    key: network.id,
                    attrs: { href: "#" },
                    on: {
                      click: function($event) {
                        $event.preventDefault()
                        return _vm.changeNetwork(network)
                      }
                    }
                  },
                  [
                    _c("span", { staticClass: "network-dropdown-icon" }, [
                      _vm.currentNetwork.id === network.id
                        ? _c(
                            "svg",
                            {
                              staticClass: "icon",
                              attrs: {
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "-2 -1.5 24 24",
                                width: "24",
                                height: "24",
                                preserveAspectRatio: "xMinYMin"
                              }
                            },
                            [
                              _c("path", {
                                attrs: {
                                  d:
                                    "M10 20.565c-5.523 0-10-4.477-10-10s4.477-10 10-10 10 4.477 10 10-4.477 10-10 10z"
                                }
                              })
                            ]
                          )
                        : _c(
                            "svg",
                            {
                              staticClass: "icon",
                              attrs: {
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "-2 -2 24 24",
                                width: "24",
                                height: "24",
                                preserveAspectRatio: "xMinYMin"
                              }
                            },
                            [
                              _c("path", {
                                attrs: {
                                  d:
                                    "M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm0 2C4.477 20 0 15.523 0 10S4.477 0 10 0s10 4.477 10 10-4.477 10-10 10z"
                                }
                              })
                            ]
                          )
                    ]),
                    _vm._v(" "),
                    _c("span", [_vm._v(_vm._s(network.name))])
                  ]
                )
              }),
              0
            )
          ]
        )
      ])
    ]),
    _vm._v(" "),
    _vm._m(0),
    _vm._v(" "),
    _c("h1", { staticClass: "auth-title" }, [_vm._v("MOOMASK")]),
    _vm._v(" "),
    _c(
      "div",
      {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.error.show,
            expression: "error.show"
          }
        ],
        staticClass: "message error"
      },
      [_vm._v("\n        " + _vm._s(_vm.error.message) + "\n    ")]
    ),
    _vm._v(" "),
    _c(
      "form",
      {
        staticClass: "auth-form",
        attrs: { action: "", method: "post", autocomplete: "off" },
        on: { submit: _vm.submitForm }
      },
      [
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.privateKey,
              expression: "privateKey"
            }
          ],
          staticClass: "input-field",
          attrs: { type: "text", placeholder: "Private Key" },
          domProps: { value: _vm.privateKey },
          on: {
            input: function($event) {
              if ($event.target.composing) {
                return
              }
              _vm.privateKey = $event.target.value
            }
          }
        }),
        _vm._v(" "),
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.password,
              expression: "password"
            }
          ],
          staticClass: "input-field",
          attrs: {
            type: "password",
            name: "password",
            placeholder: "New Password (min 8 chars)"
          },
          domProps: { value: _vm.password },
          on: {
            input: function($event) {
              if ($event.target.composing) {
                return
              }
              _vm.password = $event.target.value
            }
          }
        }),
        _vm._v(" "),
        _c("div", { staticClass: "form-info" }, [
          _vm._v(
            "\n            This password encrypts your private key. Make sure to remember this password as you will need it to unlock your wallet.\n        "
          )
        ]),
        _vm._v(" "),
        _c(
          "button",
          { staticClass: "button brand", attrs: { type: "submit" } },
          [_vm._v("Import Wallet from Private Key")]
        ),
        _vm._v(" "),
        _c(
          "a",
          {
            staticClass: "auth-link",
            on: {
              click: function($event) {
                return _vm.$router.back()
              }
            }
          },
          [_vm._v("Cancel")]
        )
      ]
    )
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "auth-logo" }, [
      _c("img", { attrs: { src: "images/bscpay.png", alt: "MooMask" } })
    ])
  }
]
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-2b4f53a5", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 582:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Account_vue__ = __webpack_require__(243);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Account_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Account_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Account_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Account_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_7055a4d6_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Account_vue__ = __webpack_require__(626);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Account_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_7055a4d6_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Account_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_7055a4d6_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Account_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/Account.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-7055a4d6", Component.options)
  } else {
    hotAPI.reload("data-v-7055a4d6", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 614:
/***/ (function(module, exports) {

module.exports = {"title":"Binance-Peg BTC Token","code":"BTCBB","icon":"btcbb.webp","decimals":18,"id":20,"contract":{"1":"0x7130d2a12b9bcbfae4f2634d864a1ee1ce3ead9c","2":"0x6ce8da28e2f864420840cf74474eff5fd80e65b8"}}

/***/ }),

/***/ 615:
/***/ (function(module, exports) {

module.exports = {"title":"Burger Swap","code":"BURGER","icon":"burger.webp","decimals":18,"id":21,"contract":{"1":"0xae9269f27437f0fcbc232d39ec814844a51d6b8f","2":null}}

/***/ }),

/***/ 616:
/***/ (function(module, exports) {

module.exports = {"title":"Binance USD","code":"BUSD","icon":"busd.webp","decimals":18,"id":22,"contract":{"1":"0xed24fc36d5ee211ea25a80239fb8c4cfd80f12ee","2":"0xe9e7cea3dedca5984780bafc599bd69add087d56"}}

/***/ }),

/***/ 617:
/***/ (function(module, exports) {

module.exports = {"title":"Binance-Peg Ethereum Token","code":"ETH","icon":"eth.webp","decimals":18,"id":23,"contract":{"1":"0x2170ed0880ac9a755fd29b2688956bd959f933f8","2":null}}

/***/ }),

/***/ 618:
/***/ (function(module, exports) {

module.exports = {"title":"Binance-Peg Litecoin Token","code":"LTC","icon":"ltc.webp","decimals":18,"id":24,"contract":{"1":"0x4338665cbb7b2485a8855a139b75d5e34ab0db94","2":null}}

/***/ }),

/***/ 619:
/***/ (function(module, exports) {

module.exports = {"title":"Prometeus","code":"PROM","icon":"prom.webp","decimals":18,"id":25,"contract":{"1":"0xaf53d56ff99f1322515e54fdde93ff8b3b7dafd5","2":null}}

/***/ }),

/***/ 620:
/***/ (function(module, exports) {

module.exports = {"title":"Venus","code":"XVS","icon":"xvs.webp","decimals":18,"id":26,"contract":{"1":"0xcf6bb5389c92bdda8a3747ddb454cb7a64626c63","2":"0xb9e0e753630434d7863528cc73cb7ac638a7c8ff"}}

/***/ }),

/***/ 621:
/***/ (function(module, exports) {

module.exports = {"title":"Wrapped BNB","code":"WBNB","icon":"wbnb.webp","decimals":18,"id":27,"contract":{"1":"0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c","2":null}}

/***/ }),

/***/ 622:
/***/ (function(module, exports) {

module.exports = {"title":"Binance-Peg XRP Token","code":"XRP","icon":"xrp.webp","decimals":18,"id":28,"contract":{"1":"0x1d2f0da169ceb9fc7b3144628db156f3f6c60dbe","2":"0xa83575490D7df4E2F47b7D38ef351a2722cA45b9"}}

/***/ }),

/***/ 623:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(624);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(22).default
var update = add("f673ec68", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./AppHeader.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./AppHeader.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 624:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports


// module
exports.push([module.i, "\n.header {\n    width: 370px;\n    position: fixed;\n    top: 0;\n    left: 0;\n    background: #FFFFFF;\n    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);\n}\n.header-top {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-pack: justify;\n        justify-content: space-between;\n    padding: 0.5rem 0.875rem;\n    line-height: 1;\n    position: relative;\n}\n.header-logo {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-align: center;\n        align-items: center;\n    -ms-flex: 1;\n        flex: 1;\n    font-size: 1rem;\n    font-weight: 600;\n    color: #424242;\n}\n.header-logo img,\n.header-logo span {\n    display: block;\n}\n.header-logo img {\n    margin-right: 5px;\n}\n.network {\n    margin: -0.2rem 0.75rem 0;\n    position: relative;\n}\n.network span {\n    display: block;\n}\na.network-toggle {\n    max-width: 150px;\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-align: center;\n        align-items: center;\n    -ms-flex-pack: justify;\n        justify-content: space-between;\n    font-size: 0.625rem;\n    text-transform: uppercase;\n    padding: 0.4rem;\n    background: #E0E0E0;\n    border-radius: 3px;\n    color: #757575;\n    cursor: pointer;\n}\na.network-toggle:hover {\n    background: #DDDDDD;\n}\n.network-icon {\n    font-size: 0.5rem;\n    padding-top: 2px;\n}\n.network-arrow {\n    padding-top: 2px;\n}\n.network-name {\n    -ms-flex: 1;\n        flex: 1;\n    font-weight: 600;\n    color: #616161;\n    padding: 0.1rem 0.3rem;\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n}\n.network-dropdown {\n    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);\n    background: #FFFFFF;\n    position: absolute;\n    top: 30px;\n    right: 0px;\n    padding: 0.375rem 0;\n    border-radius: 3px;\n    min-width: 100px;\n}\n.network-dropdown a {\n    display: -ms-flexbox;\n    display: flex;\n    padding: 0.375rem 0.75rem;\n    font-size: 0.75rem;\n    line-height: 1.25;\n    color: #757575;\n}\n.network-dropdown a:hover,\n.network-dropdown a:focus {\n    color: #184c82;\n}\n.network-dropdown a span {\n    display: block;\n}\n.network-dropdown-icon {\n    padding: 3px 8px 0 0;\n    font-size: 0.625rem;\n}\n.refresh-toggle {\n    padding: 0 0.75rem 0 0;\n}\n.refresh-toggle,\n.dropdown-menu-toggle {\n    display: block;\n    font-size: 1.125rem;\n    color: #424242;\n}\n.dropdown-menu {\n    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);\n    background: #FFFFFF;\n    position: absolute;\n    top: 40px;\n    right: 10px;\n    padding: 0.5rem 0;\n    border-radius: 3px;\n    min-width: 125px;\n}\n.dropdown-menu a {\n    display: block;\n    padding: 0.5rem 1rem;\n    font-size: 0.875rem;\n    color: #757575;\n}\n.dropdown-menu a:hover,\n.dropdown-menu a:focus {\n    color: #184c82;\n}\n.header-tabs {\n    display: -ms-flexbox;\n    display: flex;\n    width: 100%;\n}\n.header-tabs a {\n    display: block;\n    -ms-flex: 1;\n        flex: 1;\n    padding: 0.625rem;\n    color: #757575;\n    font-size: 0.75rem;\n    text-transform: uppercase;\n    text-align: center;\n}\n.header-tabs a.active {\n    color: #184c82;\n    border-bottom: 2px solid #184c82;\n}\n.header-tabs a:hover,\n.header-tabs a:focus {\n    color: #184c82;\n}\n.header-subtitle {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-align: center;\n        align-items: center;\n    padding: 0.625rem;\n    font-size: 0.75rem;\n    text-transform: uppercase;\n    height: 40px;\n}\n.header-subtitle-back {\n    display: block;\n    padding: 5px 8px 0;\n    font-size: 0.87rem;\n    color: #424242;\n}\n.header-subtitle-text {\n    -ms-flex: 1;\n        flex: 1;\n    font-weight: 600;\n    text-align: center;\n    padding-right: 30px;\n}\n", ""]);

// exports


/***/ }),

/***/ 625:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("header", { staticClass: "header" }, [
    _c(
      "div",
      { staticClass: "header-top" },
      [
        _c("router-link", { staticClass: "header-logo", attrs: { to: "/" } }, [
          _c("img", {
            attrs: { src: "images/bscpay-small.png", alt: "MooMask" }
          }),
          _vm._v(" "),
          _c("span", [_vm._v("MOOMASK")])
        ]),
        _vm._v(" "),
        _c(
          "div",
          {
            directives: [
              {
                name: "click-outside",
                rawName: "v-click-outside",
                value: _vm.hideNetworkDropdown,
                expression: "hideNetworkDropdown"
              }
            ],
            staticClass: "network"
          },
          [
            _c(
              "a",
              {
                staticClass: "network-toggle",
                attrs: { href: "#" },
                on: {
                  click: function($event) {
                    $event.preventDefault()
                    return _vm.toggleNetworkDropdown($event)
                  }
                }
              },
              [
                _c("span", { staticClass: "network-icon" }, [
                  _c(
                    "svg",
                    {
                      staticClass: "icon",
                      attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20"
                      }
                    },
                    [
                      _c("path", {
                        attrs: {
                          d:
                            "M10 20a10 10 0 1 1 0-20 10 10 0 0 1 0 20zm7.75-8a8.01 8.01 0 0 0 0-4h-3.82a28.81 28.81 0 0 1 0 4h3.82zm-.82 2h-3.22a14.44 14.44 0 0 1-.95 3.51A8.03 8.03 0 0 0 16.93 14zm-8.85-2h3.84a24.61 24.61 0 0 0 0-4H8.08a24.61 24.61 0 0 0 0 4zm.25 2c.41 2.4 1.13 4 1.67 4s1.26-1.6 1.67-4H8.33zm-6.08-2h3.82a28.81 28.81 0 0 1 0-4H2.25a8.01 8.01 0 0 0 0 4zm.82 2a8.03 8.03 0 0 0 4.17 3.51c-.42-.96-.74-2.16-.95-3.51H3.07zm13.86-8a8.03 8.03 0 0 0-4.17-3.51c.42.96.74 2.16.95 3.51h3.22zm-8.6 0h3.34c-.41-2.4-1.13-4-1.67-4S8.74 3.6 8.33 6zM3.07 6h3.22c.2-1.35.53-2.55.95-3.51A8.03 8.03 0 0 0 3.07 6z"
                        }
                      })
                    ]
                  )
                ]),
                _vm._v(" "),
                _c("span", { staticClass: "network-name" }, [
                  _vm._v(_vm._s(_vm.currentNetwork.name))
                ]),
                _vm._v(" "),
                _c("span", { staticClass: "network-arrow" }, [
                  _c(
                    "svg",
                    {
                      staticClass: "icon",
                      attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20"
                      }
                    },
                    [
                      _c("path", {
                        attrs: {
                          d:
                            "M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                        }
                      })
                    ]
                  )
                ])
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.showNetworkDropdown,
                    expression: "showNetworkDropdown"
                  }
                ],
                staticClass: "network-dropdown"
              },
              _vm._l(_vm.networks, function(network) {
                return _c(
                  "a",
                  {
                    key: network.id,
                    attrs: { href: "#" },
                    on: {
                      click: function($event) {
                        $event.preventDefault()
                        return _vm.changeNetwork(network)
                      }
                    }
                  },
                  [
                    _c("span", { staticClass: "network-dropdown-icon" }, [
                      _vm.currentNetwork.id === network.id
                        ? _c(
                            "svg",
                            {
                              staticClass: "icon",
                              attrs: {
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "-2 -1.5 24 24",
                                width: "24",
                                height: "24",
                                preserveAspectRatio: "xMinYMin"
                              }
                            },
                            [
                              _c("path", {
                                attrs: {
                                  d:
                                    "M10 20.565c-5.523 0-10-4.477-10-10s4.477-10 10-10 10 4.477 10 10-4.477 10-10 10z"
                                }
                              })
                            ]
                          )
                        : _c(
                            "svg",
                            {
                              staticClass: "icon",
                              attrs: {
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "-2 -2 24 24",
                                width: "24",
                                height: "24",
                                preserveAspectRatio: "xMinYMin"
                              }
                            },
                            [
                              _c("path", {
                                attrs: {
                                  d:
                                    "M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm0 2C4.477 20 0 15.523 0 10S4.477 0 10 0s10 4.477 10 10-4.477 10-10 10z"
                                }
                              })
                            ]
                          )
                    ]),
                    _vm._v(" "),
                    _c("span", [_vm._v(_vm._s(network.name))])
                  ]
                )
              }),
              0
            )
          ]
        ),
        _vm._v(" "),
        _c(
          "a",
          {
            staticClass: "refresh-toggle",
            attrs: { href: "#" },
            on: {
              click: function($event) {
                $event.preventDefault()
                return _vm.refreshData($event)
              }
            }
          },
          [
            _c(
              "svg",
              {
                staticClass: "icon",
                attrs: {
                  xmlns: "http://www.w3.org/2000/svg",
                  viewBox: "0 0 20 20"
                }
              },
              [
                _c("path", {
                  attrs: {
                    d:
                      "M14.66 15.66A8 8 0 1 1 17 10h-2a6 6 0 1 0-1.76 4.24l1.42 1.42zM12 10h8l-4 4-4-4z"
                  }
                })
              ]
            )
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          {
            directives: [
              {
                name: "click-outside",
                rawName: "v-click-outside",
                value: _vm.hideDropdownMenu,
                expression: "hideDropdownMenu"
              }
            ]
          },
          [
            _c(
              "a",
              {
                staticClass: "dropdown-menu-toggle",
                attrs: { href: "#" },
                on: {
                  click: function($event) {
                    $event.preventDefault()
                    return _vm.toggleDropdownMenu($event)
                  }
                }
              },
              [
                _c(
                  "svg",
                  {
                    staticClass: "icon",
                    attrs: {
                      xmlns: "http://www.w3.org/2000/svg",
                      viewBox: "0 0 20 20"
                    }
                  },
                  [
                    _c("path", {
                      attrs: {
                        d: "M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z"
                      }
                    })
                  ]
                )
              ]
            ),
            _vm._v(" "),
            _c(
              "nav",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.showDropdownMenu,
                    expression: "showDropdownMenu"
                  }
                ],
                staticClass: "dropdown-menu"
              },
              [
                _c("router-link", { attrs: { to: "/send" } }, [_vm._v("Send")]),
                _vm._v(" "),
                _c("router-link", { attrs: { to: "/receive" } }, [
                  _vm._v("Receive")
                ]),
                _vm._v(" "),
                _c("router-link", { attrs: { to: "/private-key" } }, [
                  _vm._v("Export Private Key")
                ]),
                _vm._v(" "),
                _c("router-link", { attrs: { to: "/about" } }, [
                  _vm._v("About MooMask")
                ]),
                _vm._v(" "),
                _c(
                  "a",
                  {
                    attrs: { href: "#" },
                    on: {
                      click: function($event) {
                        $event.preventDefault()
                        return _vm.logout($event)
                      }
                    }
                  },
                  [_vm._v("Logout")]
                )
              ],
              1
            )
          ]
        )
      ],
      1
    ),
    _vm._v(" "),
    _vm.subtitle
      ? _c(
          "div",
          { staticClass: "header-subtitle" },
          [
            _c(
              "router-link",
              { staticClass: "header-subtitle-back", attrs: { to: "/" } },
              [
                _c(
                  "svg",
                  {
                    staticClass: "icon",
                    attrs: {
                      xmlns: "http://www.w3.org/2000/svg",
                      viewBox: "0 0 20 20"
                    }
                  },
                  [
                    _c("path", {
                      attrs: {
                        d:
                          "M3.828 9l6.071-6.071-1.414-1.414L0 10l.707.707 7.778 7.778 1.414-1.414L3.828 11H20V9H3.828z"
                      }
                    })
                  ]
                )
              ]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "header-subtitle-text" }, [
              _vm._v(_vm._s(_vm.subtitle))
            ])
          ],
          1
        )
      : _c(
          "nav",
          { staticClass: "header-tabs" },
          [
            _c(
              "router-link",
              {
                class: { active: _vm.route.name == "account" },
                attrs: { to: "/" }
              },
              [_vm._v("Account")]
            ),
            _vm._v(" "),
            _c(
              "router-link",
              {
                class: { active: _vm.route.name == "tokens" },
                attrs: { to: "/tokens" }
              },
              [_vm._v("Tokens")]
            ),
            _vm._v(" "),
            _c(
              "router-link",
              {
                class: { active: _vm.route.name == "transactions" },
                attrs: { to: "/transactions" }
              },
              [_vm._v("Transactions")]
            )
          ],
          1
        )
  ])
}
var staticRenderFns = []
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-25dae451", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 626:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("app-header", { on: { refresh: _vm.refreshAccount } }),
      _vm._v(" "),
      _c("main", { staticClass: "main" }, [
        _c("div", { staticClass: "box highlight" }, [
          _c("div", { staticClass: "box-label" }, [_vm._v("Account Balance")]),
          _vm._v(" "),
          _c("div", { staticClass: "box-balance" }, [
            _vm._v(
              _vm._s(
                _vm.$formatNumber(_vm.account.balance, {
                  maximumSignificantDigits: 7
                })
              )
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "box-balance-code" }, [_vm._v("BNB")]),
          _vm._v(" "),
          _c("div", { staticClass: "box-address-label" }, [_vm._v("Address")]),
          _vm._v(" "),
          _c("div", { staticClass: "box-address" }, [
            _vm._v(_vm._s(_vm.address))
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "box-buttons" },
            [
              _c(
                "router-link",
                { staticClass: "green", attrs: { to: "/receive" } },
                [_c("span", [_vm._v("Receive")])]
              ),
              _vm._v(" "),
              _c(
                "router-link",
                { staticClass: "red", attrs: { to: "/send" } },
                [_c("span", [_vm._v("Send")])]
              )
            ],
            1
          )
        ])
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-7055a4d6", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 627:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Tokens_vue__ = __webpack_require__(252);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Tokens_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Tokens_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Tokens_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Tokens_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_2a04fe81_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Tokens_vue__ = __webpack_require__(630);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
function injectStyle (context) {
  if (disposed) return
  __webpack_require__(628)
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Tokens_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_2a04fe81_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Tokens_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_2a04fe81_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Tokens_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/Tokens.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-2a04fe81", Component.options)
  } else {
    hotAPI.reload("data-v-2a04fe81", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 628:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(629);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(22).default
var update = add("1be22e34", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./Tokens.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./Tokens.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 629:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports


// module
exports.push([module.i, "\n.token {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-align: center;\n        align-items: center;\n    -ms-flex-pack: start;\n        justify-content: flex-start;\n    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);\n    background: #FFFFFF;\n    border-radius: 5px;\n    padding: 1rem;\n    margin-bottom: 0.75rem;\n}\n.token img {\n    max-width:32px;\n    margin-right: 8px;\n}\n.token span {\n    display: block;\n}\n.token-name {\n    color: #9E9E9E;\n    font-size: 0.875rem;\n    -ms-flex:1;\n        flex:1;\n}\n.token-balance {\n    font-size: 1rem;\n    font-weight: 600;\n    text-align: right;\n    word-break: break-all;\n    padding-left: 1rem;\n}\n", ""]);

// exports


/***/ }),

/***/ 63:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CONTRACT_TYPES = undefined;
exports.getTokenAmount = getTokenAmount;
exports.getTokenRawAmount = getTokenRawAmount;
exports.getScanlink = getScanlink;

var _store = __webpack_require__(82);

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var contractTypes = {};

var CONTRACT_TYPES = exports.CONTRACT_TYPES = contractTypes;

function getTokenAmount(rawAmount) {
    var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 6;

    return rawAmount / Math.pow(10, precision);
}

function getTokenRawAmount(amount) {
    var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 6;

    return amount * Math.pow(10, precision);
}

function getScanlink() {
    return _store2.default.state.network.explore;
}

/***/ }),

/***/ 630:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("app-header", { on: { refresh: _vm.refreshAccount } }),
      _vm._v(" "),
      _c("main", { staticClass: "main" }, [
        _vm.account.tokens.length === 0
          ? _c("div", { staticClass: "message-empty" }, [
              _vm._v("\n            No tokens found\n        ")
            ])
          : _c(
              "div",
              _vm._l(_vm.account.tokens, function(token) {
                return _c(
                  "div",
                  {
                    directives: [
                      {
                        name: "show",
                        rawName: "v-show",
                        value: token.name !== "_",
                        expression: "token.name !== '_'"
                      }
                    ],
                    key: token.name,
                    staticClass: "token"
                  },
                  [
                    _c("img", {
                      attrs: {
                        src:
                          "tokens/" +
                          _vm.getTokenDetails(token.name)[1].toLowerCase() +
                          ".webp"
                      }
                    }),
                    _vm._v(" "),
                    _c("span", { staticClass: "token-name" }, [
                      _vm._v(_vm._s(_vm.getTokenDetails(token.name)[1]))
                    ]),
                    _vm._v(" "),
                    _c("span", { staticClass: "token-balance" }, [
                      _vm._v(
                        _vm._s(
                          _vm.$formatNumber(
                            _vm.getTokenAmount(
                              token.balance,
                              _vm.getTokenDetails(token.name)[2]
                            ),
                            {
                              maximumSignificantDigits:
                                parseInt(_vm.getTokenDetails(token.name)[2]) + 1
                            }
                          )
                        )
                      )
                    ])
                  ]
                )
              }),
              0
            )
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-2a04fe81", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 631:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transfers_vue__ = __webpack_require__(253);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transfers_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transfers_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transfers_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transfers_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_a582aa5e_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Transfers_vue__ = __webpack_require__(635);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
function injectStyle (context) {
  if (disposed) return
  __webpack_require__(632)
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transfers_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_a582aa5e_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Transfers_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_a582aa5e_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Transfers_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/Transfers.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-a582aa5e", Component.options)
  } else {
    hotAPI.reload("data-v-a582aa5e", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 632:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(633);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(22).default
var update = add("665b3c50", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./Transfers.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./Transfers.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 633:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports


// module
exports.push([module.i, "\n.transfer {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-align: center;\n        align-items: center;\n    -ms-flex-pack: justify;\n        justify-content: space-between;\n    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);\n    transition: box-shadow 0.5s ease;\n    background: #FFFFFF;\n    border-radius: 5px;\n    padding: 0;\n    margin-bottom: 0.75rem;\n    font-size: 0.75rem;\n    color: #424242;\n}\n.transfer:hover,\n.transfer:focus {\n    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);\n}\n.transfer:active {\n    transform: translateY(1px);\n}\n.transfer-content,\n.transfer-address,\n.transfer-date,\n.transfer-amount {\n    display: block;\n}\n.transfer-icon {\n    display: -ms-flexbox;\n    display: flex;\n    font-size: 24px;\n    padding: 8px;\n    width: 40px;\n    color: #F44336;\n}\n.transfer-content {\n    -ms-flex: 1;\n        flex: 1;\n    padding: 0.625rem 0;\n}\n.transfer-address {\n    font-weight: 600;\n    margin-bottom: 3px;\n    color: #424242;\n}\n.transfer-date {\n    color: #BDBDBD;\n    font-size: 0.625rem;\n}\n.transfer-amount {\n    -ms-flex: 1;\n        flex: 1;\n    padding: 0.5rem 0.625rem;\n    font-size: 0.75rem;\n    word-break: break-all;\n    text-align: right;\n}\n.transfer-icon,\n.transfer-amount {\n    color: #F44336;\n}\n.transfer-icon.incoming,\n.transfer-amount.incoming {\n    color: #8BC34A;\n}\n", ""]);

// exports


/***/ }),

/***/ 634:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "a",
    { attrs: { href: _vm.url }, on: { click: _vm.clicked } },
    [_vm._t("default")],
    2
  )
}
var staticRenderFns = []
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-0dc33c1c", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 635:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("app-header", { on: { refresh: _vm.refreshTransfers } }),
      _vm._v(" "),
      _c("main", { staticClass: "main" }, [
        _vm.transfers.length === 0
          ? _c("div", { staticClass: "message-empty" }, [
              _vm._v("\n            No transfers yet\n        ")
            ])
          : _c("div", [
              _c(
                "div",
                _vm._l(_vm.transfers, function(transfer) {
                  return _c(
                    "external-link",
                    {
                      key: transfer.transactionHash,
                      staticClass: "transfer",
                      attrs: {
                        url: _vm.getTransferLink(transfer.transactionHash)
                      }
                    },
                    [
                      _vm.isOutgoingTransfer(transfer)
                        ? _c("span", { staticClass: "transfer-icon" }, [
                            _c(
                              "svg",
                              {
                                staticClass: "icon",
                                attrs: {
                                  xmlns: "http://www.w3.org/2000/svg",
                                  viewBox: "-6 -6.5 24 24",
                                  width: "24",
                                  height: "24",
                                  preserveAspectRatio: "xMinYMin"
                                }
                              },
                              [
                                _c("path", {
                                  attrs: {
                                    d:
                                      "M7.828 2.414H2.243a1 1 0 1 1 0-2h8a.997.997 0 0 1 1 1v8a1 1 0 0 1-2 0V3.828l-6.779 6.779A1 1 0 0 1 1.05 9.192l6.778-6.778z"
                                  }
                                })
                              ]
                            )
                          ])
                        : _c(
                            "span",
                            { staticClass: "transfer-icon incoming" },
                            [
                              _c(
                                "svg",
                                {
                                  staticClass: "icon",
                                  attrs: {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    viewBox: "-6.5 -6.5 24 24",
                                    width: "24",
                                    height: "24",
                                    preserveAspectRatio: "xMinYMin"
                                  }
                                },
                                [
                                  _c("path", {
                                    attrs: {
                                      d:
                                        "M3.828 8.9h5.586a1 1 0 0 1 0 2h-8a.997.997 0 0 1-1-1v-8a1 1 0 1 1 2 0v5.585L9.192.707a1 1 0 1 1 1.415 1.414L3.828 8.9z"
                                    }
                                  })
                                ]
                              )
                            ]
                          ),
                      _vm._v(" "),
                      _c("span", { staticClass: "transfer-content" }, [
                        _vm.isOutgoingTransfer(transfer)
                          ? _c("span", { staticClass: "transfer-address" }, [
                              _vm._v(
                                "\n                            " +
                                  _vm._s(
                                    _vm.compressAddress(
                                      transfer.transferToAddress
                                    )
                                  ) +
                                  "\n                        "
                              )
                            ])
                          : _c("span", { staticClass: "transfer-address" }, [
                              _vm._v(
                                "\n                            " +
                                  _vm._s(
                                    _vm.compressAddress(
                                      transfer.transferFromAddress
                                    )
                                  ) +
                                  "\n                        "
                              )
                            ]),
                        _vm._v(" "),
                        _c("span", { staticClass: "transfer-date" }, [
                          _vm._v(
                            _vm._s(
                              _vm.$formatDate(transfer.timestamp, {
                                day: "numeric",
                                month: "long",
                                year: "numeric"
                              })
                            )
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _vm.isOutgoingTransfer(transfer)
                        ? _c("span", { staticClass: "transfer-amount" }, [
                            _vm._v(
                              "\n                        - " +
                                _vm._s(_vm.formatTokenAmount(transfer)) +
                                "\n                    "
                            )
                          ])
                        : _c(
                            "span",
                            { staticClass: "transfer-amount incoming" },
                            [
                              _vm._v(
                                "\n                        + " +
                                  _vm._s(_vm.formatTokenAmount(transfer)) +
                                  "\n                    "
                              )
                            ]
                          )
                    ]
                  )
                }),
                1
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: _vm.page < _vm.lastPage && !_vm.loadMoreLoading,
                      expression: "page < lastPage && ! loadMoreLoading"
                    }
                  ],
                  staticClass: "load-more",
                  attrs: { href: "#" },
                  on: { click: _vm.loadMore }
                },
                [_vm._v("Load More")]
              )
            ])
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-a582aa5e", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 636:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transactions_vue__ = __webpack_require__(255);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transactions_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transactions_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transactions_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transactions_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_58f5b57c_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Transactions_vue__ = __webpack_require__(640);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
function injectStyle (context) {
  if (disposed) return
  __webpack_require__(637)
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Transactions_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_58f5b57c_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Transactions_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_58f5b57c_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Transactions_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/Transactions.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-58f5b57c", Component.options)
  } else {
    hotAPI.reload("data-v-58f5b57c", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 637:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(638);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(22).default
var update = add("48345d74", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./Transactions.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./Transactions.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 638:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports


// module
exports.push([module.i, "\n.transaction {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-align: center;\n        align-items: center;\n    -ms-flex-pack: justify;\n        justify-content: space-between;\n    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);\n    transition: box-shadow 0.5s ease;\n    background: #FFFFFF;\n    border-radius: 5px;\n    padding: 0.75rem;\n    margin-bottom: 0.75rem;\n    font-size: 0.875rem;\n    color: #424242;\n}\n.transaction:hover,\n.transaction:focus {\n    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);\n}\n.transaction:active {\n    transform: translateY(1px);\n}\n.transaction span {\n    display: block;\n}\n.transaction-content {\n    width: 90%;\n}\n.transaction-contract {\n    font-weight: 600;\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    margin-bottom: 0.25rem;\n}\n.transaction-date {\n    font-size: 0.625rem;\n    color: #9E9E9E;\n}\n.transaction-icon {\n    width: 10%;\n    font-size: 1rem;\n    color: #757575;\n    text-align: right;\n}\n.transaction:hover .transaction-icon,\n.transaction:focus .transaction-icon {\n    color: #184c82;\n}\n", ""]);

// exports


/***/ }),

/***/ 639:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _regenerator = __webpack_require__(50);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(51);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var readBlock = function () {
  var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(eth, blockNumber, address) {
    var block, transactions, i, single;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return eth.getBlock(blockNumber, true);

          case 3:
            block = _context.sent;

            if (block && block.transactions) {
              transactions = block.transactions;

              for (i = 0; i < transactions.length; i++) {
                single = transactions[i];

                if (address == "*" || address == e.from || address == e.to) {
                  console.log('>--------------->');
                  console.log(single);
                }
              }
            }
            _context.next = 10;
            break;

          case 7:
            _context.prev = 7;
            _context.t0 = _context['catch'](0);

            console.error(_context.t0);

          case 10:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 7]]);
  }));

  return function readBlock(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();

var getTransactionsByAccount = function () {
  var _ref3 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(network, address, fromBlockNumber) {
    var startBlock, fetchUrl, resp;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            startBlock = fromBlockNumber ? fromBlockNumber : 0;
            fetchUrl = network.scan + '?module=account&action=txlist&address=' + address + '&startblock=' + startBlock + '&endblock=99999999&apikey=' + network.apiKey;
            _context3.next = 4;
            return loadUrl(fetchUrl);

          case 4:
            resp = _context3.sent;

            if (!(resp.message == 'OK')) {
              _context3.next = 8;
              break;
            }

            console.log(resp.result);
            return _context3.abrupt('return', resp.result);

          case 8:
            return _context3.abrupt('return', []);

          case 9:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function getTransactionsByAccount(_x5, _x6, _x7) {
    return _ref3.apply(this, arguments);
  };
}();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var loadUrl = function () {
  var _ref2 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(url) {
    var response;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return fetch(url, {
              method: 'GET'
            });

          case 3:
            response = _context2.sent;
            return _context2.abrupt('return', response.json());

          case 7:
            _context2.prev = 7;
            _context2.t0 = _context2['catch'](0);
            throw _context2.t0;

          case 10:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, undefined, [[0, 7]]);
  }));

  return function loadUrl(_x4) {
    return _ref2.apply(this, arguments);
  };
}();

exports.default = getTransactionsByAccount;

/***/ }),

/***/ 640:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("app-header", { on: { refresh: _vm.refreshTransactions } }),
      _vm._v(" "),
      _c("main", { staticClass: "main" }, [
        _vm.transactions.length === 0
          ? _c("div", { staticClass: "message-empty" }, [
              _vm._v("\n            No transactions yet\n        ")
            ])
          : _c("div", [
              _c(
                "div",
                _vm._l(_vm.transactions, function(transaction) {
                  return _c(
                    "external-link",
                    {
                      key: transaction.hash,
                      staticClass: "transaction",
                      attrs: { url: _vm.getTransactionLink(transaction.hash) }
                    },
                    [
                      _c("span", { staticClass: "transaction-content" }, [
                        _c("span", { staticClass: "transaction-contract" }, [
                          _vm._v(_vm._s(transaction.value))
                        ]),
                        _vm._v(" "),
                        _c("span", { staticClass: "transaction-date" }, [
                          _vm._v(
                            _vm._s(
                              _vm.formatStamp(transaction.timeStamp, {
                                day: "numeric",
                                month: "long",
                                year: "numeric"
                              })
                            )
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("span", { staticClass: "transaction-icon" }, [
                        _c(
                          "svg",
                          {
                            staticClass: "icon",
                            attrs: {
                              xmlns: "http://www.w3.org/2000/svg",
                              viewBox: "0 0 20 20"
                            }
                          },
                          [
                            _c("path", {
                              attrs: {
                                d:
                                  "M10 0a10 10 0 1 1 0 20 10 10 0 0 1 0-20zM2 10a8 8 0 1 0 16 0 8 8 0 0 0-16 0zm10.54.7L9 14.25l-1.41-1.41L10.4 10 7.6 7.17 9 5.76 13.24 10l-.7.7z"
                              }
                            })
                          ]
                        )
                      ])
                    ]
                  )
                }),
                1
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: _vm.page < _vm.lastPage && !_vm.loadMoreLoading,
                      expression: "page < lastPage && ! loadMoreLoading"
                    }
                  ],
                  staticClass: "load-more",
                  attrs: { href: "#" },
                  on: { click: _vm.loadMore }
                },
                [_vm._v("Load More")]
              )
            ])
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-58f5b57c", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 641:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Send_vue__ = __webpack_require__(256);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Send_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Send_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Send_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Send_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_59c6292f_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Send_vue__ = __webpack_require__(646);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Send_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_59c6292f_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Send_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_59c6292f_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Send_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/Send.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-59c6292f", Component.options)
  } else {
    hotAPI.reload("data-v-59c6292f", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 642:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ConfirmDialog_vue__ = __webpack_require__(257);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ConfirmDialog_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ConfirmDialog_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ConfirmDialog_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ConfirmDialog_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_1a1d4deb_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_ConfirmDialog_vue__ = __webpack_require__(645);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
function injectStyle (context) {
  if (disposed) return
  __webpack_require__(643)
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_ConfirmDialog_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_1a1d4deb_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_ConfirmDialog_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_1a1d4deb_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_ConfirmDialog_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/components/ConfirmDialog.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-1a1d4deb", Component.options)
  } else {
    hotAPI.reload("data-v-1a1d4deb", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 643:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(644);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(22).default
var update = add("18a8f68c", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./ConfirmDialog.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./ConfirmDialog.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 644:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports


// module
exports.push([module.i, "\n.vue-dialog .dialog-content {\n    padding: 1rem 0.625rem;\n    text-align: center;\n}\n.vue-dialog-button.primary {\n    color: #F44336;\n    font-weight: 600;\n}\n.vue-dialog-button.secondary {\n    color: #757575;\n}\n", ""]);

// exports


/***/ }),

/***/ 645:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("v-dialog", { attrs: { width: "350" } })
}
var staticRenderFns = []
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-1a1d4deb", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 646:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("app-header", {
        attrs: { subtitle: "Send Payment" },
        on: { refresh: _vm.refreshTokens }
      }),
      _vm._v(" "),
      _c("main", { staticClass: "main" }, [
        _c(
          "form",
          {
            staticClass: "auth-form",
            attrs: { action: "", method: "post", autocomplete: "off" },
            on: {
              submit: function($event) {
                $event.preventDefault()
                return _vm.showConfirmDialog($event)
              }
            }
          },
          [
            _c(
              "div",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.message.show,
                    expression: "message.show"
                  }
                ],
                staticClass: "message",
                class: [_vm.message.type]
              },
              [
                _vm._v(
                  "\n                " +
                    _vm._s(_vm.message.text) +
                    "\n            "
                )
              ]
            ),
            _vm._v(" "),
            _c("label", { staticClass: "input-label" }, [
              _vm._v("\n                Receipient Address\n                "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.receipient,
                    expression: "receipient"
                  }
                ],
                staticClass: "input-field",
                attrs: { type: "text", name: "address" },
                domProps: { value: _vm.receipient },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.receipient = $event.target.value
                  }
                }
              })
            ]),
            _vm._v(" "),
            _c("label", { staticClass: "input-label" }, [
              _vm._v("\n                Token\n                "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.selectedToken,
                      expression: "selectedToken"
                    }
                  ],
                  staticClass: "input-field",
                  on: {
                    change: function($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function(o) {
                          return o.selected
                        })
                        .map(function(o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.selectedToken = $event.target.multiple
                        ? $$selectedVal
                        : $$selectedVal[0]
                    }
                  }
                },
                _vm._l(_vm.account.tokens, function(token) {
                  return _c(
                    "option",
                    { key: token.name, domProps: { value: token } },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.getTokenName(token)) +
                          " (" +
                          _vm._s(_vm.getTokenBalance(token)) +
                          " available)\n                    "
                      )
                    ]
                  )
                }),
                0
              )
            ]),
            _vm._v(" "),
            _c("label", { staticClass: "input-label" }, [
              _vm._v("\n                Amount\n                "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.amount,
                    expression: "amount"
                  }
                ],
                staticClass: "input-field",
                attrs: { type: "number", name: "amount", step: "any" },
                domProps: { value: _vm.amount },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.amount = $event.target.value
                  }
                }
              })
            ]),
            _vm._v(" "),
            _c(
              "button",
              { staticClass: "button brand", attrs: { type: "submit" } },
              [_vm._v("Send")]
            )
          ]
        )
      ]),
      _vm._v(" "),
      _c("confirm-dialog", {
        ref: "confirmDialog",
        attrs: { text: _vm.confirmDialogText },
        on: { confirmed: _vm.sendPayment }
      })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-59c6292f", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 647:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Receive_vue__ = __webpack_require__(258);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Receive_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Receive_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Receive_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Receive_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_81557ae8_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Receive_vue__ = __webpack_require__(651);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
function injectStyle (context) {
  if (disposed) return
  __webpack_require__(648)
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_Receive_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_81557ae8_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Receive_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_81557ae8_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_Receive_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/Receive.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-81557ae8", Component.options)
  } else {
    hotAPI.reload("data-v-81557ae8", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 648:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(649);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(22).default
var update = add("2ade6746", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./Receive.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./Receive.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 649:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports


// module
exports.push([module.i, "\n.receive-payment {\n    font-size: 0.875rem;\n}\n.receive-payment,\n.receive-payment .input-field {\n    text-align: center;\n}\n", ""]);

// exports


/***/ }),

/***/ 651:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("app-header", { attrs: { subtitle: "Receive Payment" } }),
      _vm._v(" "),
      _c("main", { staticClass: "main" }, [
        _c(
          "div",
          { staticClass: "receive-payment" },
          [
            _c("div", {}, [_vm._v("Send to the following address")]),
            _vm._v(" "),
            _c("div", { staticClass: "input-group" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.address,
                    expression: "address"
                  }
                ],
                staticClass: "input-field",
                attrs: { type: "text", name: "address", readonly: "" },
                domProps: { value: _vm.address },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.address = $event.target.value
                  }
                }
              }),
              _vm._v(" "),
              _c(
                "button",
                {
                  directives: [
                    {
                      name: "clipboard",
                      rawName: "v-clipboard:copy",
                      value: _vm.address,
                      expression: "address",
                      arg: "copy"
                    }
                  ],
                  staticClass: "button",
                  attrs: { title: "Copy to clipboard" }
                },
                [
                  _c(
                    "svg",
                    {
                      staticClass: "icon",
                      attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20"
                      }
                    },
                    [
                      _c("path", {
                        attrs: {
                          d:
                            "M6 6V2c0-1.1.9-2 2-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-4v4a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V8c0-1.1.9-2 2-2h4zm2 0h4a2 2 0 0 1 2 2v4h4V2H8v4zM2 8v10h10V8H2z"
                        }
                      })
                    ]
                  )
                ]
              )
            ]),
            _vm._v(" "),
            _c("qrcode-vue", {
              attrs: { value: _vm.address, size: 336, level: "H" }
            })
          ],
          1
        )
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-81557ae8", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 652:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PrivateKey_vue__ = __webpack_require__(259);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PrivateKey_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PrivateKey_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PrivateKey_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PrivateKey_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_236fb643_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_PrivateKey_vue__ = __webpack_require__(653);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PrivateKey_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_236fb643_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_PrivateKey_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_236fb643_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_PrivateKey_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/PrivateKey.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-236fb643", Component.options)
  } else {
    hotAPI.reload("data-v-236fb643", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 653:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("app-header", { attrs: { subtitle: "Export Private Key" } }),
      _vm._v(" "),
      _c("main", { staticClass: "main" }, [
        _vm.wallet
          ? _c(
              "div",
              [
                _c("div", { staticClass: "form-info" }, [
                  _vm._v(
                    "\n                This is your private key.\n            "
                  )
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "input-group" }, [
                  _c("textarea", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.wallet.privateKey,
                        expression: "wallet.privateKey"
                      }
                    ],
                    staticClass: "input-field special",
                    attrs: { type: "text", readonly: "" },
                    domProps: { value: _vm.wallet.privateKey },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.wallet, "privateKey", $event.target.value)
                      }
                    }
                  }),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      directives: [
                        {
                          name: "clipboard",
                          rawName: "v-clipboard:copy",
                          value: _vm.wallet.privateKey,
                          expression: "wallet.privateKey",
                          arg: "copy"
                        }
                      ],
                      staticClass: "button",
                      attrs: { title: "Copy to clipboard" }
                    },
                    [
                      _c(
                        "svg",
                        {
                          staticClass: "icon",
                          attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 20 20"
                          }
                        },
                        [
                          _c("path", {
                            attrs: {
                              d:
                                "M6 6V2c0-1.1.9-2 2-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-4v4a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V8c0-1.1.9-2 2-2h4zm2 0h4a2 2 0 0 1 2 2v4h4V2H8v4zM2 8v10h10V8H2z"
                            }
                          })
                        ]
                      )
                    ]
                  )
                ]),
                _vm._v(" "),
                _vm._m(0),
                _vm._v(" "),
                _c(
                  "router-link",
                  { staticClass: "button brand", attrs: { to: "/" } },
                  [_vm._v("I've copied it somewhere safe")]
                )
              ],
              1
            )
          : _c("div", [
              _c(
                "form",
                {
                  staticClass: "auth-form",
                  attrs: { action: "", method: "post", autocomplete: "off" },
                  on: {
                    submit: function($event) {
                      $event.preventDefault()
                      return _vm.submitForm($event)
                    }
                  }
                },
                [
                  _c("div", { staticClass: "form-info" }, [
                    _vm._v(
                      "\n                    Please enter your password to export the private key.\n                "
                    )
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.error.show,
                          expression: "error.show"
                        }
                      ],
                      staticClass: "message error"
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.error.message) +
                          "\n                "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.password,
                        expression: "password"
                      }
                    ],
                    staticClass: "input-field",
                    attrs: {
                      type: "password",
                      name: "password",
                      placeholder: "Password"
                    },
                    domProps: { value: _vm.password },
                    on: {
                      input: function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.password = $event.target.value
                      }
                    }
                  }),
                  _vm._v(" "),
                  _c(
                    "button",
                    { staticClass: "button brand", attrs: { type: "submit" } },
                    [_vm._v("Submit")]
                  )
                ]
              )
            ])
      ])
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "form-info" }, [
      _c("p", [
        _c("strong", [_vm._v("Do not lose it!")]),
        _vm._v(" It can't be recovered if you lose it.")
      ]),
      _vm._v(" "),
      _c("p", [
        _c("strong", [_vm._v("Do not share it!")]),
        _vm._v(" Your funds will be stolen if you use it on a malicious site.")
      ]),
      _vm._v(" "),
      _c("p", [
        _c("strong", [_vm._v("Make a backup!")]),
        _vm._v(" Just in case your laptop is set on fire.")
      ])
    ])
  }
]
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-236fb643", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 654:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_About_vue__ = __webpack_require__(260);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_About_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_About_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_About_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_About_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_dfa40314_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_About_vue__ = __webpack_require__(657);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__ = __webpack_require__(10);
var disposed = false
function injectStyle (context) {
  if (disposed) return
  __webpack_require__(655)
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(__WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_lib_runtime_component_normalizer__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_About_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_dfa40314_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_About_vue__["a" /* render */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_dfa40314_hasScoped_false_optionsId_0_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_About_vue__["b" /* staticRenderFns */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src/popup/pages/About.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-dfa40314", Component.options)
  } else {
    hotAPI.reload("data-v-dfa40314", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ 655:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(656);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(22).default
var update = add("d4c397cc", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./About.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js?{\"minimize\":false}!../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"optionsId\":\"0\",\"vue\":true,\"scoped\":false,\"sourceMap\":true}!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./About.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 656:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(18)(false);
// imports


// module
exports.push([module.i, "\n.about {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-direction: column;\n        flex-direction: column;\n    -ms-flex-pack: justify;\n        justify-content: space-between;\n    min-height: 480px;\n    font-size: 0.875rem;\n}\n.about-content p {\n    color: #616161;\n}\n.about-version {\n    font-size: 0.75rem;\n    text-align: center;\n    color: #9E9E9E;\n}\n.about-socials {\n    padding: 1.5rem 0 0;\n    font-size: 1rem;\n    text-align: center;\n    margin-bottom: 0.75rem;\n}\n.about-socials a {\n    display: inline-block;\n    color: #BDBDBD;\n    margin: 0 0.5rem;\n}\n.about-socials a.medium:hover,\n.about-socials a.github:hover {\n    color: #333;\n}\n.about-socials a.twitter:hover {\n    color: #1da1f2;\n}\n.partners-title {\n    font-size: 0.75rem;\n    text-align: center;\n    text-transform: uppercase;\n    margin-top: 2rem;\n    margin-bottom: 0.75rem;\n}\n.partners {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-pack: center;\n        justify-content: center;\n    -ms-flex-wrap: wrap;\n        flex-wrap: wrap;\n}\n.partners a {\n    display: block;\n    width:60%;\n}\n.partners img {\n    max-width: 100%;\n}\n", ""]);

// exports


/***/ }),

/***/ 657:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("app-header", { attrs: { subtitle: "About MooMask" } }),
      _vm._v(" "),
      _c("main", { staticClass: "main" }, [
        _c("div", { staticClass: "about" }, [
          _c("div", { staticClass: "about-content" }, [
            _c("p", [
              _vm._v(
                "MooMask is a browser extension wallet for Binance Smart Chain. MooMask enables you to access BSC Blockchain directly from your favorite browser."
              )
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "We never hold / have access to your private key. The private key is encrypted and only stored on your browser. For safety, always logout your wallet after using it."
              )
            ]),
            _vm._v(" "),
            _c("h2", { staticClass: "partners-title" }, [_vm._v("Partner")]),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "partners" },
              [
                _c(
                  "external-link",
                  { attrs: { url: "https://moopay.live/" } },
                  [
                    _c("img", {
                      attrs: { src: "images/moopay.png", alt: "MooPay" }
                    })
                  ]
                )
              ],
              1
            )
          ]),
          _vm._v(" "),
          _vm._m(0)
        ])
      ])
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "about-footer" }, [
      _c("div", { staticClass: "about-socials" }),
      _vm._v(" "),
      _c("div", { staticClass: "about-version" }, [_vm._v("v0.0.1")])
    ])
  }
]
render._withStripped = true

if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-hot-reload-api")      .rerender("data-v-dfa40314", { render: render, staticRenderFns: staticRenderFns })
  }
}

/***/ }),

/***/ 75:
/***/ (function(module, exports) {

module.exports = {"identity":0,"ip4":4,"tcp":6,"sha1":17,"sha2-256":18,"sha2-512":19,"sha3-512":20,"sha3-384":21,"sha3-256":22,"sha3-224":23,"shake-128":24,"shake-256":25,"keccak-224":26,"keccak-256":27,"keccak-384":28,"keccak-512":29,"dccp":33,"murmur3-128":34,"murmur3-32":35,"ip6":41,"ip6zone":42,"path":47,"multicodec":48,"multihash":49,"multiaddr":50,"multibase":51,"dns":53,"dns4":54,"dns6":55,"dnsaddr":56,"protobuf":80,"cbor":81,"raw":85,"dbl-sha2-256":86,"rlp":96,"bencode":99,"dag-pb":112,"dag-cbor":113,"libp2p-key":114,"git-raw":120,"torrent-info":123,"torrent-file":124,"leofcoin-block":129,"leofcoin-tx":130,"leofcoin-pr":131,"sctp":132,"eth-block":144,"eth-block-list":145,"eth-tx-trie":146,"eth-tx":147,"eth-tx-receipt-trie":148,"eth-tx-receipt":149,"eth-state-trie":150,"eth-account-snapshot":151,"eth-storage-trie":152,"bitcoin-block":176,"bitcoin-tx":177,"zcash-block":192,"zcash-tx":193,"stellar-block":208,"stellar-tx":209,"md4":212,"md5":213,"bmt":214,"decred-block":224,"decred-tx":225,"ipld-ns":226,"ipfs-ns":227,"swarm-ns":228,"ipns-ns":229,"zeronet":230,"ed25519-pub":237,"dash-block":240,"dash-tx":241,"swarm-manifest":250,"swarm-feed":251,"udp":273,"p2p-webrtc-star":275,"p2p-webrtc-direct":276,"p2p-stardust":277,"p2p-circuit":290,"dag-json":297,"udt":301,"utp":302,"unix":400,"p2p":421,"ipfs":421,"https":443,"onion":444,"onion3":445,"garlic64":446,"garlic32":447,"tls":448,"quic":460,"ws":477,"wss":478,"p2p-websocket-star":479,"http":480,"json":512,"messagepack":513,"x11":4352,"blake2b-8":45569,"blake2b-16":45570,"blake2b-24":45571,"blake2b-32":45572,"blake2b-40":45573,"blake2b-48":45574,"blake2b-56":45575,"blake2b-64":45576,"blake2b-72":45577,"blake2b-80":45578,"blake2b-88":45579,"blake2b-96":45580,"blake2b-104":45581,"blake2b-112":45582,"blake2b-120":45583,"blake2b-128":45584,"blake2b-136":45585,"blake2b-144":45586,"blake2b-152":45587,"blake2b-160":45588,"blake2b-168":45589,"blake2b-176":45590,"blake2b-184":45591,"blake2b-192":45592,"blake2b-200":45593,"blake2b-208":45594,"blake2b-216":45595,"blake2b-224":45596,"blake2b-232":45597,"blake2b-240":45598,"blake2b-248":45599,"blake2b-256":45600,"blake2b-264":45601,"blake2b-272":45602,"blake2b-280":45603,"blake2b-288":45604,"blake2b-296":45605,"blake2b-304":45606,"blake2b-312":45607,"blake2b-320":45608,"blake2b-328":45609,"blake2b-336":45610,"blake2b-344":45611,"blake2b-352":45612,"blake2b-360":45613,"blake2b-368":45614,"blake2b-376":45615,"blake2b-384":45616,"blake2b-392":45617,"blake2b-400":45618,"blake2b-408":45619,"blake2b-416":45620,"blake2b-424":45621,"blake2b-432":45622,"blake2b-440":45623,"blake2b-448":45624,"blake2b-456":45625,"blake2b-464":45626,"blake2b-472":45627,"blake2b-480":45628,"blake2b-488":45629,"blake2b-496":45630,"blake2b-504":45631,"blake2b-512":45632,"blake2s-8":45633,"blake2s-16":45634,"blake2s-24":45635,"blake2s-32":45636,"blake2s-40":45637,"blake2s-48":45638,"blake2s-56":45639,"blake2s-64":45640,"blake2s-72":45641,"blake2s-80":45642,"blake2s-88":45643,"blake2s-96":45644,"blake2s-104":45645,"blake2s-112":45646,"blake2s-120":45647,"blake2s-128":45648,"blake2s-136":45649,"blake2s-144":45650,"blake2s-152":45651,"blake2s-160":45652,"blake2s-168":45653,"blake2s-176":45654,"blake2s-184":45655,"blake2s-192":45656,"blake2s-200":45657,"blake2s-208":45658,"blake2s-216":45659,"blake2s-224":45660,"blake2s-232":45661,"blake2s-240":45662,"blake2s-248":45663,"blake2s-256":45664,"skein256-8":45825,"skein256-16":45826,"skein256-24":45827,"skein256-32":45828,"skein256-40":45829,"skein256-48":45830,"skein256-56":45831,"skein256-64":45832,"skein256-72":45833,"skein256-80":45834,"skein256-88":45835,"skein256-96":45836,"skein256-104":45837,"skein256-112":45838,"skein256-120":45839,"skein256-128":45840,"skein256-136":45841,"skein256-144":45842,"skein256-152":45843,"skein256-160":45844,"skein256-168":45845,"skein256-176":45846,"skein256-184":45847,"skein256-192":45848,"skein256-200":45849,"skein256-208":45850,"skein256-216":45851,"skein256-224":45852,"skein256-232":45853,"skein256-240":45854,"skein256-248":45855,"skein256-256":45856,"skein512-8":45857,"skein512-16":45858,"skein512-24":45859,"skein512-32":45860,"skein512-40":45861,"skein512-48":45862,"skein512-56":45863,"skein512-64":45864,"skein512-72":45865,"skein512-80":45866,"skein512-88":45867,"skein512-96":45868,"skein512-104":45869,"skein512-112":45870,"skein512-120":45871,"skein512-128":45872,"skein512-136":45873,"skein512-144":45874,"skein512-152":45875,"skein512-160":45876,"skein512-168":45877,"skein512-176":45878,"skein512-184":45879,"skein512-192":45880,"skein512-200":45881,"skein512-208":45882,"skein512-216":45883,"skein512-224":45884,"skein512-232":45885,"skein512-240":45886,"skein512-248":45887,"skein512-256":45888,"skein512-264":45889,"skein512-272":45890,"skein512-280":45891,"skein512-288":45892,"skein512-296":45893,"skein512-304":45894,"skein512-312":45895,"skein512-320":45896,"skein512-328":45897,"skein512-336":45898,"skein512-344":45899,"skein512-352":45900,"skein512-360":45901,"skein512-368":45902,"skein512-376":45903,"skein512-384":45904,"skein512-392":45905,"skein512-400":45906,"skein512-408":45907,"skein512-416":45908,"skein512-424":45909,"skein512-432":45910,"skein512-440":45911,"skein512-448":45912,"skein512-456":45913,"skein512-464":45914,"skein512-472":45915,"skein512-480":45916,"skein512-488":45917,"skein512-496":45918,"skein512-504":45919,"skein512-512":45920,"skein1024-8":45921,"skein1024-16":45922,"skein1024-24":45923,"skein1024-32":45924,"skein1024-40":45925,"skein1024-48":45926,"skein1024-56":45927,"skein1024-64":45928,"skein1024-72":45929,"skein1024-80":45930,"skein1024-88":45931,"skein1024-96":45932,"skein1024-104":45933,"skein1024-112":45934,"skein1024-120":45935,"skein1024-128":45936,"skein1024-136":45937,"skein1024-144":45938,"skein1024-152":45939,"skein1024-160":45940,"skein1024-168":45941,"skein1024-176":45942,"skein1024-184":45943,"skein1024-192":45944,"skein1024-200":45945,"skein1024-208":45946,"skein1024-216":45947,"skein1024-224":45948,"skein1024-232":45949,"skein1024-240":45950,"skein1024-248":45951,"skein1024-256":45952,"skein1024-264":45953,"skein1024-272":45954,"skein1024-280":45955,"skein1024-288":45956,"skein1024-296":45957,"skein1024-304":45958,"skein1024-312":45959,"skein1024-320":45960,"skein1024-328":45961,"skein1024-336":45962,"skein1024-344":45963,"skein1024-352":45964,"skein1024-360":45965,"skein1024-368":45966,"skein1024-376":45967,"skein1024-384":45968,"skein1024-392":45969,"skein1024-400":45970,"skein1024-408":45971,"skein1024-416":45972,"skein1024-424":45973,"skein1024-432":45974,"skein1024-440":45975,"skein1024-448":45976,"skein1024-456":45977,"skein1024-464":45978,"skein1024-472":45979,"skein1024-480":45980,"skein1024-488":45981,"skein1024-496":45982,"skein1024-504":45983,"skein1024-512":45984,"skein1024-520":45985,"skein1024-528":45986,"skein1024-536":45987,"skein1024-544":45988,"skein1024-552":45989,"skein1024-560":45990,"skein1024-568":45991,"skein1024-576":45992,"skein1024-584":45993,"skein1024-592":45994,"skein1024-600":45995,"skein1024-608":45996,"skein1024-616":45997,"skein1024-624":45998,"skein1024-632":45999,"skein1024-640":46000,"skein1024-648":46001,"skein1024-656":46002,"skein1024-664":46003,"skein1024-672":46004,"skein1024-680":46005,"skein1024-688":46006,"skein1024-696":46007,"skein1024-704":46008,"skein1024-712":46009,"skein1024-720":46010,"skein1024-728":46011,"skein1024-736":46012,"skein1024-744":46013,"skein1024-752":46014,"skein1024-760":46015,"skein1024-768":46016,"skein1024-776":46017,"skein1024-784":46018,"skein1024-792":46019,"skein1024-800":46020,"skein1024-808":46021,"skein1024-816":46022,"skein1024-824":46023,"skein1024-832":46024,"skein1024-840":46025,"skein1024-848":46026,"skein1024-856":46027,"skein1024-864":46028,"skein1024-872":46029,"skein1024-880":46030,"skein1024-888":46031,"skein1024-896":46032,"skein1024-904":46033,"skein1024-912":46034,"skein1024-920":46035,"skein1024-928":46036,"skein1024-936":46037,"skein1024-944":46038,"skein1024-952":46039,"skein1024-960":46040,"skein1024-968":46041,"skein1024-976":46042,"skein1024-984":46043,"skein1024-992":46044,"skein1024-1000":46045,"skein1024-1008":46046,"skein1024-1016":46047,"skein1024-1024":46048,"holochain-adr-v0":8417572,"holochain-adr-v1":8483108,"holochain-key-v0":9728292,"holochain-key-v1":9793828,"holochain-sig-v0":10645796,"holochain-sig-v1":10711332}

/***/ }),

/***/ 82:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vue = __webpack_require__(81);

var _vue2 = _interopRequireDefault(_vue);

var _vuex = __webpack_require__(11);

var _vuex2 = _interopRequireDefault(_vuex);

var _vuexPersist = __webpack_require__(270);

var _vuexPersist2 = _interopRequireDefault(_vuexPersist);

var _wallet = __webpack_require__(273);

var _wallet2 = _interopRequireDefault(_wallet);

var _network = __webpack_require__(137);

var _network2 = _interopRequireDefault(_network);

var _account = __webpack_require__(274);

var _account2 = _interopRequireDefault(_account);

var _token = __webpack_require__(148);

var _token2 = _interopRequireDefault(_token);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_vue2.default.use(_vuex2.default);

var vuexLocal = new _vuexPersist2.default({
    storage: window.localStorage,
    modules: ['wallet', 'network', 'route']
});

exports.default = new _vuex2.default.Store({
    modules: {
        wallet: _wallet2.default,
        network: _network2.default,
        account: _account2.default,
        token: _token2.default
    },

    state: {
        loading: false
    },

    mutations: {
        loading: function loading(state, _loading) {
            state.loading = _loading;
        }
    },

    plugins: [vuexLocal.plugin]
});

/***/ })

},[261]);
//# sourceMappingURL=popup.js.map